# Profit Margin Calculator

## Per-Income-Source Analysis

| Income Source | Total Income | Related Expenses | Net Profit | Profit Margin |
|---|---|---|---|---|
| Freelance Design | $1,950.00 | $110.00 | $1,840.00 | 94.4% |
| Consulting | $600.00 | $48.00 | $552.00 | 92.0% |
| Upwork/Gig Platform | $150.00 | $0.00 | $150.00 | 100.0% |
| Affiliate Income | $85.00 | $50.00 | $35.00 | 41.2% |
| Freelance Writing | $200.00 | $0.00 | $200.00 | 100.0% |
| YouTube/Content | $45.00 | $0.00 | $45.00 | 100.0% |
| E-commerce Sales | $120.00 | $0.00 | $120.00 | 100.0% |

## How to Use This Calculator

1. Enter your income in the Income Log tab
2. Enter your expenses in the Expense Log tab, noting which income source they relate to
3. This calculator automatically shows:
   - **Total Income** per source
   - **Related Expenses** allocated to each source
   - **Net Profit** after expenses
   - **Profit Margin** = (Net Profit / Total Income) × 100

## Quick Margin Benchmarks

- **90%+ margin**: Excellent — mostly time-based services with low overhead
- **70-90% margin**: Good — healthy business with some costs
- **50-70% margin**: Fair — watch your expenses closely
- **Below 50%**: Needs attention — consider raising prices or cutting costs

## Tips for Improving Margins

1. **Raise rates** on your most-demanded service
2. **Cut unused subscriptions** (check monthly software costs)
3. **Bundle services** to increase per-project revenue
4. **Eliminate low-margin work** — replace with higher-paying clients
5. **Automate** repetitive tasks to reduce time cost per project
