# Weekly money review checklist

Do this once a week. It should take 5–10 minutes.

## Log

- [ ] Add all payments received to `income-log.csv`.
- [ ] Add platform fees, software, subcontractors, ads, and supplies to `expense-log.csv`.
- [ ] Mark deductible expenses with Yes/No.
- [ ] Map every expense to an income source where possible.

## Review

- [ ] Which income source made the most gross revenue this week?
- [ ] Which source made the most profit after direct expenses?
- [ ] Did any source require too much time for the profit?
- [ ] Are taxes set aside before spending?

## Decide

Use this rule monthly:

- Keep: high profit margin, low stress, repeatable.
- Improve: good revenue but weak margin or messy process.
- Drop: low margin, high stress, no strategic value.

## Simple bank-account method

If possible, keep separate buckets/accounts for:

1. operating money
2. tax reserve
3. owner pay
4. reinvestment

Even if the spreadsheet is simple, separating cash prevents surprise tax pain.
