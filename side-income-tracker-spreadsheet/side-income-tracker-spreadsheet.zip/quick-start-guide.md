# Quick Start Guide: Side Income Tracker Spreadsheet

## Getting Started (about 10 minutes)

### Step 1: Set Up Your Income Sources
Open the **Income Sources Setup** tab. Replace the example income sources with your own. Add as many as you need — there's no limit.

### Step 2: Log Income
Every time you get paid, add a row to the **Income Log**:
- Date
- Which income source
- What it was for
- Amount
- How you got paid
- Mark as "Received" or "Pending"

### Step 3: Log Expenses
Log every business expense in the **Expense Log**:
- Mark tax-deductible expenses with "Yes"
- This feeds into your tax estimator automatically

### Step 4: Check Your Dashboard
The **Monthly Dashboard** and **Tax Estimator** update as you log entries. Check them weekly.

### Step 5: Use at Tax Time
At the end of each quarter, use the Tax Estimator to see your estimated quarterly tax payment. At year-end, the Annual Summary gives your accountant everything they need.

---

## Pro Tips

### Weekly Habit (5 min)
Every Friday, log that week's income and expenses. It usually takes a few minutes and makes tax-time review less chaotic.

### Monthly Review (15 min)
At month-end, check:
1. Did I hit my income target?
2. Which income source paid the most?
3. Are my expenses reasonable?
4. What's my estimated tax bill?

### Quarterly
1. Check your estimated quarterly tax payment
2. Make the payment if required
3. Review which income sources are growing vs shrinking

---

## Tax Disclaimer
This spreadsheet helps you estimate taxes but is not tax advice. Consult a tax professional for your specific situation. Tax rules vary by country and income level.

## Support
Questions? Email cleo@cleo.ai
