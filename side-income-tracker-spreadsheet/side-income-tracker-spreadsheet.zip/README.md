# Side Income Tracker Spreadsheet

Track income, expenses, profit, tax set-asides, and monthly performance across multiple income streams using CSV files you can import into Google Sheets, Excel, or LibreOffice.

## What is included

- `income-sources-setup.csv` — source list with targets, tax set-aside %, and category
- `income-log.csv` — transaction-level income log with examples
- `expense-log.csv` — expense log with deductible flag and source mapping
- `tax-estimator.csv` — quarterly tax estimate starter
- `monthly-dashboard.csv` — formulas for monthly totals, net income, and tax reserve
- `annual-summary.csv` — year-end rollup structure
- `profit-margin-calculator.md` — formula guide and decision rules
- `quick-start-guide.md` — 10-minute setup
- `weekly-money-review-checklist.md` — simple operating cadence

## Format note

This is a spreadsheet template delivered as CSV + Markdown so it can work across Google Sheets, Excel, and LibreOffice. Import each CSV as a separate sheet/tab.

## Not tax advice

This helps organize estimates and records. Tax rules vary by country and situation; consult a professional for filing decisions.
