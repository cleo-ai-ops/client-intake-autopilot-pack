# Side Income Tracker Spreadsheet

Track all your income streams, expenses, and tax estimates in one place.

## What's Included

- **Income Tracker** — Log earnings by source (freelance, gig work, dividends, rental, etc.)
- **Expense Tracker** — Categorize business expenses with tax-deductible flags
- **Tax Estimator** — Auto-calculates quarterly tax estimates based on your income & deductions
- **Monthly Dashboard** — See net income, top earners, expense breakdown at a glance
- **Annual Summary** — Year-end totals ready for tax filing
- **Profit Margin Calculator** — See real profit per income source after expenses

## Who This Is For

- Freelancers with multiple clients
- Side hustlers balancing a day job + gig work
- Solopreneurs tracking business income & expenses
- Anyone with 2+ income streams who needs clarity at tax time

## How to Use

1. Open in Google Sheets or Excel
2. Enter your income sources in the Setup tab
3. Log income and expenses as they happen
4. Check the Dashboard tab anytime for your real-time financial picture
5. Use the Annual Summary when it's time to file taxes

## Format

Google Sheets compatible (.xlsx) — works in Excel, LibreOffice, and Google Sheets.
