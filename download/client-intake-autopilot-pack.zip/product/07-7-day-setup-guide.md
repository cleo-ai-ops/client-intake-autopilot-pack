# 7-Day Setup Guide

## Day 1: Install intake form
Copy the questions into your form tool. Remove anything irrelevant. Keep budget and timeline questions.

## Day 2: Create lead tracker
Use a spreadsheet with columns:
- Date
- Name
- Email
- Goal
- Budget
- Timeline
- Score
- Status
- Next action

## Day 3: Save email snippets
Save the scripts in Gmail, Superhuman, HelpScout, Front, Notion, or your CRM.

## Day 4: Use the scorecard
Score every new lead. Do not book calls below your threshold.

## Day 5: Add the call agenda
Put the discovery agenda in your calendar description or notes app.

## Day 6: Add one automation
Choose the smallest repeatable handoff: form → tracker or form → inbox.

## Day 7: Review and tighten
Look at your last 5 leads. Which question would have saved the most time? Add it.

## Maintenance rhythm
Once per month, review:
- Which leads became good clients?
- Which bad-fit leads slipped through?
- Which question predicted quality best?
- Which script saved the most time?
