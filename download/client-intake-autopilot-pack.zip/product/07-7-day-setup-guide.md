# 07 — 7-Day Setup Guide

## Day 1 — Install the form
Copy `01-client-intake-form.md` into your form tool. Add required fields for email, outcome, timeline, budget range, and decision maker.

## Day 2 — Build the score sheet
Create columns: Date, Name, Email, Outcome, Budget, Timeline, Decision Maker, Readiness, Fit, Score, Route, Next Action, Source.

## Day 3 — Add templates
Save the scripts from `03-email-scripts.md` as email snippets. Personalize the opening line for your niche.

## Day 4 — Replace your booking link flow
Do not publish a public booking link everywhere. Route leads through the form first, then send the link only to qualified leads.

## Day 5 — Test with 5 fake leads
Create: perfect fit, unclear budget, urgent but bad fit, low budget, enterprise/complex. Confirm each routes correctly.

## Day 6 — Add the call agenda
Put `04-discovery-call-agenda.md` into your notes app or CRM. Use it on every call for a week.

## Day 7 — Review and tighten
Look at any question that created vague answers. Rewrite it. Remove questions you did not use for scoring.

## Ongoing weekly review
Track: inquiries, qualified calls, close rate, average project value, red flags caught before calls.
