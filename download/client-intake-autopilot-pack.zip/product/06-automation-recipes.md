# 06 — Automation Recipes

Start manual, then automate. These recipes work in Zapier, Make, n8n, Airtable Automations, or most CRMs.

## Recipe 1 — Form → score sheet → notification
Trigger: new intake form response.
Steps:
1. Add row to `Lead Score` spreadsheet.
2. Calculate score from mapped fields.
3. If score >= 80, send Slack/email “Priority lead: [name] — [outcome]”.
4. If 60–79, create task “Ask clarification questions”.
5. If < 40, create draft decline email.

Minimum fields: name, email, outcome, budget, timeline, decision maker, assets ready, score, route.

## Recipe 2 — Priority lead auto-reply
Trigger: score >= 80.
Action: send templated email with booking link.
Guardrail: do not auto-send if form contains angry language, legal/compliance terms, or “NDA before details.” Route to manual review.

## Recipe 3 — Missing info follow-up
Trigger: score 60–79 OR missing budget/timeline.
Action: send clarification script with only the missing questions.
Rule: never ask more than 3 questions in the email.

## Recipe 4 — CRM pipeline
Create stages:
- New inquiry
- Clarification needed
- Call booked
- Proposal sent
- Won
- Lost / not fit

Auto-move rules:
- booking link clicked → Call booked
- proposal link sent → Proposal sent
- no response after 7 days → Lost / dormant

## Recipe 5 — Weekly lead quality report
Every Friday, summarize:
- number of inquiries
- average score
- booked calls
- won projects
- top disqualifier
- best source

Use this to improve landing page copy and qualification questions.
