# Automation Recipes

Start simple. Automate the first handoff only.

## Recipe 1: Form to inbox triage
Trigger: New form submission
Steps:
1. Send submission to your email.
2. Add label: New Lead.
3. Create a task: Review lead.
4. Include scorecard link in the task.

Works with: Zapier, Make, n8n, Gmail, Google Forms, Tally, Typeform.

## Recipe 2: Form to lead tracker
Trigger: New form submission
Steps:
1. Create row in Airtable/Sheets/Notion.
2. Map name, email, goal, budget, timeline, source.
3. Set status to New.
4. Set review due date to next business day.

## Recipe 3: High-budget lead alert
Trigger: New form submission
Condition: Budget is above your threshold
Steps:
1. Send priority email or Slack/Telegram message.
2. Create urgent follow-up task.
3. Add calendar hold for potential discovery call.

## Recipe 4: Auto-decline low-fit leads
Trigger: Scorecard result below threshold
Steps:
1. Wait 10 minutes.
2. Send polite decline script.
3. Add tag: Not a fit.
4. Archive task.

Use carefully. Review manually until you trust the scoring.

## Recipe 5: Post-call recap generator
Trigger: Discovery call notes added
Steps:
1. Send notes to your preferred AI tool with this prompt:

"Turn these discovery notes into a concise client recap with: goal, blocker, constraints, success criteria, recommended next step, and open questions. Keep it professional and direct. Notes: {{notes}}"

2. Save draft, do not auto-send.
