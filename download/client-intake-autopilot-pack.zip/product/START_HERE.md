# Client Intake Autopilot Pack — Start Here

Use this pack to turn a messy “tell me about your project” inquiry into a repeatable qualification flow: intake form → lead score → reply → discovery call → scope boundary.

## The 30-minute setup
1. Copy `01-client-intake-form.md` into Tally, Typeform, Google Forms, or your CRM form builder.
2. Add the scoring columns from `02-lead-scorecard.md` to a spreadsheet or CRM custom fields.
3. Paste the reply scripts from `03-email-scripts.md` into Gmail templates, HelpScout, Notion, or your CRM snippets.
4. Use `04-discovery-call-agenda.md` for every call. Do not improvise from scratch.
5. Keep `05-scope-boundary-checklist.md` open when writing proposals.
6. Optional: wire the automation recipes in `06-automation-recipes.md` once the manual flow works.

## What “good” looks like
- Within 5 minutes of a form submission, the lead receives either a booking link, clarification questions, or a polite decline.
- You know whether a lead is worth a call before you spend calendar time.
- Every proposal includes success criteria, excluded work, revision limits, and a paid change-order path.

## Decision rules
- **80–100:** priority lead. Reply same day and offer 2–3 call slots.
- **60–79:** qualified but needs clarification. Ask the missing questions before a call.
- **40–59:** nurture or async consult. Do not book a full sales call unless calendar is light.
- **0–39:** decline, refer out, or send a paid audit option.

## Files included
- `01-client-intake-form.md` — copy-ready form with conditional follow-ups.
- `02-lead-scorecard.md` — scoring rules, red flags, examples.
- `03-email-scripts.md` — booking, clarification, decline, no-show, and post-call scripts.
- `04-discovery-call-agenda.md` — call plan with notes fields.
- `05-scope-boundary-checklist.md` — proposal/scope guardrails.
- `06-automation-recipes.md` — Zapier/Make/n8n recipes.
- `07-7-day-setup-guide.md` — rollout plan.
- `08-landing-page-copy.md` — copy for selling your service with the new intake flow.
