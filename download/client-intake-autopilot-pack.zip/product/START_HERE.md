# Client Intake Autopilot Pack

You bought this because client intake is probably leaking time, clarity, or money.

This pack gives you a simple operating system:

1. Capture the right information before the first call.
2. Score whether the lead is worth your time.
3. Reply with confidence.
4. Protect your scope before the project starts.
5. Automate the boring handoffs.

You do **not** need a complex CRM. Start with the templates here, then automate only what repeats.

## Recommended setup order

Day 1: Copy the intake questions into your form tool.
Day 2: Add the qualification scorecard to your lead review process.
Day 3: Save the email scripts as snippets.
Day 4: Use the discovery call agenda on your next lead.
Day 5: Add the scope boundary checklist to proposals.
Day 6: Pick one automation recipe and implement it.
Day 7: Review your last 5 leads and tighten the questions.

If you only have 20 minutes, start with `01-client-intake-form.md` and `02-lead-scorecard.md`.
