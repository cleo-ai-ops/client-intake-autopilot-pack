# Discovery Call Agenda

Use this for 20–30 minute calls.

## 0–3 min: Set frame
- Confirm time available.
- Explain that the goal is fit, not a full strategy session.
- Ask permission to interrupt if details get too broad.

Script:
"My goal today is to understand the outcome, constraints, and whether I can help. If there is a fit, I will explain the best next step. If not, I will be direct."

## 3–10 min: Diagnose
- What prompted this now?
- What have you tried?
- Where is the current process breaking?
- What is the cost of not fixing it?

## 10–18 min: Scope and constraints
- What needs to be included?
- What can be excluded?
- Who approves the work?
- What tools/accounts/assets already exist?
- What timeline matters and why?

## 18–24 min: Success criteria
- What would make this obviously worth it?
- What numbers, events, or behaviors would prove success?
- What risks are you worried about?

## 24–30 min: Close
Choose one:
1. Strong fit: explain next step and timeline.
2. Maybe: ask for missing info.
3. No fit: decline kindly and suggest alternative.

Never end with vague "I'll think about it" unless you name exactly what you are checking and when you will reply.
