# 04 — Discovery Call Agenda

Timebox: 25 minutes. The call is to confirm fit and next step, not to solve the entire project for free.

## 0–3 min — Frame the call
“My goal is to understand the outcome, constraints, and decision process. If it fits, I’ll recommend a next step. If not, I’ll say so directly.”

## 3–8 min — Current state
- What is happening today?
- What is the cost of leaving it as-is?
- What have you already tried?
- Why now?

## 8–13 min — Desired outcome
- What should be true 30/60/90 days after completion?
- How will we measure success?
- What would make this project disappointing?

## 13–18 min — Scope and constraints
- Must-have deliverables:
- Nice-to-have deliverables:
- Existing tools/platforms:
- Access/assets ready:
- Legal/brand/compliance constraints:
- Internal reviewers and response time:

## 18–22 min — Commercial fit
- Budget range confirmed:
- Deadline and reason:
- Decision maker:
- Procurement/contract needs:

## 22–25 min — Route
Choose one:
- Proposal for fixed scope
- Paid audit/workshop first
- Retainer exploration
- Referral / not a fit

## After-call notes
- Lead score:
- Biggest risk:
- Boundary to include in proposal:
- Follow-up date:
