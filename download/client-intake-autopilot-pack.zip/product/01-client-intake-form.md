# Client Intake Form Template

Use this in Typeform, Tally, Google Forms, Fillout, Notion Forms, or your website.

## Intro text
Thanks for your interest. This short form helps me understand your goals, timeline, and fit before we schedule a call. Clear answers mean a faster, more useful reply.

## Questions

### Contact
1. Name
2. Email
3. Company / project name
4. Website or social link
5. What do you do?

### Goal
6. What are you trying to achieve?
7. Why is now the right time to solve this?
8. What happens if this is not solved in the next 90 days?

### Current situation
9. What have you already tried?
10. What is working?
11. What is not working?
12. Who else is involved in the decision?

### Scope
13. Which outcome do you need most?
   - More leads
   - Better conversion
   - Better onboarding
   - Website / landing page
   - Automation
   - Analytics / reporting
   - Strategy
   - Other
14. Describe the ideal finished result.
15. Are there existing assets, accounts, or tools I should know about?

### Budget and timeline
16. Desired launch or completion date
17. Budget range
   - Under $500
   - $500–$1,500
   - $1,500–$5,000
   - $5,000–$10,000
   - $10,000+
18. Is the budget approved?
19. How soon are you ready to start?

### Fit
20. What would make this project a success?
21. What would make it a failure?
22. Anything else I should know before replying?

## Confirmation message
Thanks — I received your answers. I review new requests within 1–2 business days. If there is a strong fit, I will reply with next steps or a few clarifying questions.
