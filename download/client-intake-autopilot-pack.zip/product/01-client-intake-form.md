# 01 — Client Intake Form Template

Copy this into your form tool. Keep the form short enough to finish in 6–8 minutes, but specific enough to score without a call.

## Section 1 — Fit
1. **What do you want help with?**
   - New website / redesign
   - Automation / operations system
   - Copywriting / messaging
   - Marketing funnel
   - Ongoing retainer support
   - Other: ___
2. **What outcome would make this project a win 90 days from now?** *(long text)*
3. **What is not working today?** *(long text)*
4. **Who is the final decision maker?**
   - I am
   - I am one of 2–3 decision makers
   - I need approval from someone else

## Section 2 — Urgency and timing
5. **When do you want this live or solved?**
   - This week
   - 2–4 weeks
   - 1–3 months
   - No firm timeline
6. **What happens if this is not fixed?** *(revenue lost, team time wasted, launch delayed, churn risk, etc.)*
7. **Do you already have content, access, examples, or assets ready?**
   - Yes, most are ready
   - Some are ready
   - Not yet

## Section 3 — Budget and scope
8. **What investment range have you set aside?**
   - Under €500
   - €500–€1,500
   - €1,500–€3,000
   - €3,000–€7,500
   - €7,500+
   - Not sure yet
9. **Which support style do you prefer?**
   - Fixed-scope project
   - Paid strategy/audit first
   - Monthly retainer
   - Not sure
10. **What must be included for this to feel complete?** *(bullet list)*

## Section 4 — Red flags and logistics
11. **Have you worked with a freelancer/agency before? What went well or badly?**
12. **Who will provide feedback, and how quickly can they respond?**
13. **Are there any fixed constraints?** *(platform, legal, brand, team, compliance, launch date)*
14. **Paste any useful links.** *(website, current process, examples, brief)*
15. **Best email and timezone.**

## Optional conditional questions
Ask these only when relevant:
- For automation: “What tools must this connect?” and “Can you provide admin access or API keys after kickoff?”
- For websites: “How many page types?” and “Who owns copy/images?”
- For retainers: “What recurring outcomes are you buying: response time, output volume, strategy, or maintenance?”
