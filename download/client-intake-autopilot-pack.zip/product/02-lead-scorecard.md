# Lead Qualification Scorecard

Score each lead from 0–2 per category.

| Category | 0 | 1 | 2 |
|---|---|---|---|
| Problem clarity | Vague | Somewhat clear | Specific and urgent |
| Budget | Unknown / too low | Possible | Approved and realistic |
| Timeline | No urgency | Flexible | Clear deadline |
| Decision maker | Unknown | Influencer | Decision maker involved |
| Scope fit | Poor fit | Partial fit | Strong fit |
| Value potential | Low | Medium | High |
| Communication | Low effort | Adequate | Clear and thoughtful |

## Interpretation

- 0–5: Decline or send self-serve resource.
- 6–9: Ask clarifying questions before a call.
- 10–14: Book discovery call.

## Fast reply rules

If budget is missing but the project sounds strong, ask for budget before booking.
If timeline is urgent but scope is vague, ask for the business deadline and must-have outcome.
If the lead is low effort, do not reward it with a long custom reply.
