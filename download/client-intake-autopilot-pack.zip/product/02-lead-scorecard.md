# 02 — Lead Scorecard

Score each inquiry before booking a call. The goal is not to judge people; it is to protect your calendar and route each lead honestly.

| Category | 0 pts | 5 pts | 10 pts | 15 pts |
|---|---|---|---|---|
| Pain clarity | Vague curiosity | Problem named | Problem + cost described | Problem, cost, and desired outcome clear |
| Budget fit | Below minimum / refuses range | Unsure | Within lower band | Strong fit or above normal range |
| Urgency | No date | 1–3 months | 2–4 weeks | Time-sensitive business reason |
| Decision access | Unknown | Needs approval | Shared decision | Buyer is decision maker |
| Scope readiness | “Need everything” | Some assets | Clear scope | Assets/access/examples ready |
| Strategic fit | Outside niche | Adjacent | Good fit | Repeatable ideal-client work |

## Add/subtract modifiers
- **+10** has used paid specialists before and understands the process.
- **+10** project has measurable business value: revenue, retention, time saved, risk reduced.
- **+5** mentions a realistic constraint early instead of hiding it.
- **-10** asks for unpaid strategy, “quick call to pick your brain,” or spec work.
- **-15** refuses to share budget range after being told it helps recommend a path.
- **-20** abusive tone, impossible deadline, or asks you to copy a competitor exactly.

## Routing
- **80–100: Priority.** Send booking link and reference the outcome they gave.
- **60–79: Clarify.** Ask 2–3 missing questions before booking.
- **40–59: Async.** Offer a paid audit, workshop, or resource. Do not spend a full call.
- **0–39: Decline.** Be kind, concise, and leave the door open if conditions change.

## Example scored lead
Lead: “We need to replace a manual onboarding process in Airtable/Zapier. It takes our ops manager 6 hours/week. Need this working before a June launch. Budget €3k–€5k. I approve vendors.”

Score: Pain 15 + Budget 15 + Urgency 15 + Decision 15 + Readiness 10 + Fit 15 + measurable value 10 = **95**. Reply same day.
