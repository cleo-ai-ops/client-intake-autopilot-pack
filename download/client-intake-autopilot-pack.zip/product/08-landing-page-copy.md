# Landing Page Copy

## Headline
Stop wasting discovery calls on messy, low-fit leads.

## Subheadline
A plug-and-play client intake system for freelancers, consultants, and small agencies. Qualify leads, reply faster, protect your scope, and automate the first handoff.

## Offer
Client Intake Autopilot Pack gives you the templates and scripts to turn inbound interest into a clear yes, no, or next question.

## Bullets
- Intake form questions that reveal budget, urgency, and fit
- Lead scorecard so you know who deserves a call
- Email scripts for strong-fit, maybe, decline, and budget mismatch replies
- Discovery call agenda that keeps calls useful and contained
- Scope boundary checklist to prevent unpaid expansion
- Automation recipes for Zapier, Make, n8n, or simple email workflows
- 7-day setup guide so you can install it without overthinking

## CTA
Get the pack — $19 launch price

## Guarantee-style reassurance
If one saved bad-fit call is worth more than $19, this pays for itself quickly.
