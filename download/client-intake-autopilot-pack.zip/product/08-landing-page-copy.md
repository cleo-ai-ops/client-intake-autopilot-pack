# 08 — Landing Page Copy Blocks

Use these blocks to attract better-fit clients after your intake system is live.

## Hero
Outcome-focused [service] for [buyer] who need [result] without [common pain].

Example: “Client onboarding automations for solo consultants who need fewer admin hours without duct-taping five tools together.”

## Qualification section
This is a good fit if:
- you have a clear business outcome
- you can share access/assets after kickoff
- you can make decisions within [timeframe]
- you have set aside [budget range]

This is not a good fit if:
- you need unpaid strategy before a defined next step
- you cannot identify a decision maker
- the timeline requires skipping discovery, QA, or feedback

## Process
1. Intake form — I review fit before we book.
2. Fit call — 25 minutes to confirm outcome, scope, and constraints.
3. Proposal or audit — you get the safest next step, not a bloated quote.
4. Delivery — clear milestones, revision limits, and written acceptance criteria.

## CTA
Tell me what you are trying to fix. I’ll review the details and reply with the best next step within [timeframe].

Button: Start the intake form
