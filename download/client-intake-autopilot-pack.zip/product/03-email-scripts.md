# 03 — Email Scripts

Use these as templates. Replace bracketed fields; do not send them unchanged if the lead shared specifics you can reference.

## A. Priority lead booking reply
Subject: Next step for [project/outcome]

Hi [Name],

Thanks for the detail — especially the part about [specific pain/cost]. Based on what you shared, this looks like a strong fit for a focused [project/audit/retainer] around [outcome].

The best next step is a 25-minute call where we confirm scope, success criteria, timeline, and whether the budget range matches the work.

You can choose a time here: [booking link]

Before the call, please bring:
- access/examples for [tool/site/process]
- the decision deadline
- any must-have constraints

Best,
[Your name]

## B. Clarification before booking
Subject: Two quick questions before I recommend the next step

Hi [Name],

I can probably help, but I’m missing two details that determine whether this should be a project, paid audit, or referral:

1. [Question tied to scope or outcome]
2. [Question tied to budget, timeline, decision maker, or assets]

Once I have those, I’ll either send a booking link or point you to a better path.

Best,
[Your name]

## C. Decline politely
Subject: Re: [project]

Hi [Name],

Thanks for reaching out. I do not think I’m the right fit for this as described because [reason: timeline/budget/scope/niche].

The cleanest next step would be [referral/resource/smaller paid audit option]. If the scope changes to [your fit criteria], feel free to come back with the updated brief.

Wishing you a smooth project,
[Your name]

## D. Paid audit offer for uncertain scope
Subject: A safer first step for [project]

Hi [Name],

There are enough unknowns here that quoting the full build now would create risk for both of us. I’d recommend a paid diagnostic first.

Audit includes:
- review of [process/site/tools]
- priority fixes and implementation sequence
- estimated scope/budget for the build
- one 45-minute walkthrough

Fee: [€X], delivered in [Y days]. If you move into the build within [time window], I can credit [amount/%] toward the project.

If that works, I’ll send the checkout/contract.

Best,
[Your name]

## E. No-show / no-response follow-up
Subject: Close the loop on [project]

Hi [Name],

I’m going to close the loop for now since I did not hear back. If [problem] is still active and you have [budget/timeline/assets] ready, send the updated details and I’ll re-score it.

Best,
[Your name]

## F. Post-call recap
Subject: Recap + recommended next step

Hi [Name],

Here’s my recap from today:

Goal: [outcome]
Current blocker: [pain]
Success metric: [metric]
Included scope: [3–5 bullets]
Not included: [boundaries]
Timeline: [dates]
Decision owner: [name]

Recommended next step: [proposal/audit/retainer/referral]

I’ll send [proposal/checkout/questions] by [date].

Best,
[Your name]
