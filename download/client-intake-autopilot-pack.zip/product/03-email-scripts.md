# Client Intake Email Scripts

## Strong-fit reply
Subject: Re: Your project request

Hi {{name}},

Thanks for the thoughtful answers — this looks like a strong fit.

Based on what you shared, the main outcome seems to be {{outcome}}, with {{constraint}} as the biggest constraint. I can help you clarify the path and decide what should happen first.

Next step: book a {{call_length}} discovery call here: {{booking_link}}

Before the call, please send any existing assets, examples, or links that would help me understand the current setup.

Best,
{{your_name}}

## Clarifying-question reply
Subject: Quick questions before next steps

Hi {{name}},

Thanks for reaching out. Before I suggest next steps, I need to clarify a few things:

1. What is the business result you need most?
2. Is there an approved budget range for this?
3. Who will make the final decision?
4. What deadline are you working toward?

Once I have those, I can tell you whether this is a fit and what I recommend.

Best,
{{your_name}}

## Polite decline
Subject: Re: Your project request

Hi {{name}},

Thanks for thinking of me. Based on what you shared, I do not think I am the best fit for this project right now.

The main reason is {{reason}}.

If helpful, I would suggest {{alternative_resource_or_next_step}}.

Wishing you luck with it,
{{your_name}}

## Budget mismatch
Subject: Re: Your project request

Hi {{name}},

Thanks for the details. I want to be direct so we do not waste your time: the budget range you shared is below what I would need to deliver this properly.

A realistic range for this type of work is usually {{realistic_range}}, depending on final scope.

If that range becomes possible, I would be happy to revisit it. If not, the best next step may be {{lighter_option}}.

Best,
{{your_name}}

## Post-call recap
Subject: Recap and next steps

Hi {{name}},

Great speaking today. Here is my understanding:

Goal: {{goal}}
Current blocker: {{blocker}}
Important constraints: {{constraints}}
Success looks like: {{success}}

Recommended next step:
{{recommendation}}

If this looks right, I will send {{proposal_or_next_asset}} by {{date}}.

Best,
{{your_name}}
