# Scope Boundary Checklist

Use this before sending a proposal.

## Define the project container
- [ ] Primary outcome is written in one sentence.
- [ ] Deliverables are listed.
- [ ] Non-deliverables are listed.
- [ ] Revision limits are clear.
- [ ] Client responsibilities are clear.
- [ ] Required assets are named.
- [ ] Timeline depends on client response times.
- [ ] Approval process is named.
- [ ] Payment schedule is clear.
- [ ] Change request process is clear.

## Proposal language

### Out of scope
The following are not included unless agreed separately in writing: {{excluded_items}}.

### Client responsibilities
To keep the project on schedule, the client is responsible for providing {{assets_or_access}} by {{date_or_phase}} and responding to review requests within {{response_window}} business days.

### Change requests
Requests outside the agreed scope will be quoted separately before work begins. No additional work is started without written approval.

### Timeline dependency
The timeline assumes timely feedback, access, and approvals. Delays in client-provided materials may shift delivery dates.
