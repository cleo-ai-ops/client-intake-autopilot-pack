# 05 — Scope Boundary Checklist

Use before sending any proposal. Most scope creep starts because the proposal did not define “done.”

## Define the outcome
- [ ] Primary business outcome is written in one sentence.
- [ ] Success metric is specific or proxy-based.
- [ ] Timeline includes client feedback deadlines, not just your delivery dates.

## Define included work
- [ ] Deliverables listed as concrete outputs, not vague activities.
- [ ] Quantity limits stated: pages, automations, templates, revisions, calls, integrations.
- [ ] Platforms/tools named.
- [ ] Required client assets/access listed.

## Define excluded work
Common exclusions to name explicitly:
- copywriting beyond supplied sections
- custom branding/illustration
- data cleanup/migration beyond sample import
- third-party tool subscription costs
- legal/compliance review
- post-launch support beyond warranty window
- new features discovered after kickoff

## Change-order rule
“Requests outside the agreed scope will be estimated separately. I will not start out-of-scope work until the added fee and timeline are approved in writing.”

## Revision rule
Include one of these:
- “Includes 2 revision rounds on the agreed deliverables.”
- “Includes 1 implementation pass and 1 polish pass.”
- “Retainer includes up to [X] requests/month with [Y]-day average turnaround.”

## Acceptance rule
“Delivery is accepted when the agreed success checks pass or when no consolidated feedback is received within [5] business days.”
