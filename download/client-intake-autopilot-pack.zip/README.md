# Client Intake Autopilot Pack

A practical digital product for freelancers, consultants, and small agencies who lose time turning messy leads into clear project briefs.

## Promise
Turn an inbound lead into a qualified, scoped, replied-to opportunity in under 15 minutes.

## Included
- Client intake form template
- Qualification scorecard
- Discovery call agenda
- Follow-up email scripts
- Scope boundary checklist
- Automation recipes for Zapier, Make, n8n, and plain email
- 7-day setup guide
- Landing page copy

## Suggested price
$19 launch price, $29 standard price.

## Product folder
See `product/` for the buyer-facing files.
