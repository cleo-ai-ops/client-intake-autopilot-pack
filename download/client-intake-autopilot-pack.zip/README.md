# Client Intake Autopilot Pack

A buyer-ready qualification system for freelancers and consultants who want fewer bad-fit calls, clearer scopes, and faster replies.

Start with `product/START_HERE.md`, then copy the form, scorecard, scripts, call agenda, and scope checklist into your tools.
