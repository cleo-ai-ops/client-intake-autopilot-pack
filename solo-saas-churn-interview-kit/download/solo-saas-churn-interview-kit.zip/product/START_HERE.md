# Solo SaaS Churn Interview Kit

A practical kit for solo SaaS founders who are losing users and need useful cancellation feedback without running a big research process.

## Use it this week
1. Copy the cancellation survey into your form tool.
2. Send the churn interview email to 10 recent cancelled users.
3. Run 5 short calls with the interview script.
4. Paste answers into the CSV tracker.
5. Use the pattern finder to pick one retention fix.

Goal: turn vague churn anxiety into a ranked list of product, pricing, onboarding, and expectation problems.
