# Solo SaaS Churn Interview Kit — Start Here

Use this kit when cancellations are happening and the reasons in Stripe/Gumroad/app logs are too vague to act on. The goal is not “do research.” The goal is to identify the 1–2 retention fixes most likely to reduce avoidable churn in the next 30 days.

## What is inside

1. `01-cancellation-survey.md` — a 2-minute cancellation survey you can add to Tally, Typeform, Google Forms, or your cancellation flow.
2. `02-churn-interview-script.md` — a 15-minute founder-led interview script with probes and red flags.
3. `03-email-templates.md` — outreach, reminder, incentive, and winback emails.
4. `04-churn-pattern-finder.md` — a coding guide for turning messy feedback into reliable churn patterns.
5. `05-retention-fix-prioritizer.csv` — scoring sheet for picking fixes by impact, confidence, effort, and reversibility.
6. `06-implementation-checklist.md` — a 30-day operating cadence.
7. `07-interview-notes-template.md` — copy-paste notes format for every call.
8. `08-churn-analysis-worked-example.md` — a complete example showing raw quotes → buckets → fixes.
9. `09-retention-experiment-briefs.md` — ready-to-run experiments for onboarding, activation, pricing, and cancellation flow.
10. `10-cancellation-survey-import.csv` — question bank for spreadsheet/form import.

## 30-minute quick win

If you only have half an hour:

1. Copy the cancellation survey into your form tool.
2. Email 10 users who cancelled in the last 60 days using Template 1 in `03-email-templates.md`.
3. Put each reply/call into `07-interview-notes-template.md`.
4. Tag each response with one primary bucket from `04-churn-pattern-finder.md`.
5. Score the top 3 fixes in `05-retention-fix-prioritizer.csv`.

## Decision rule

Do **not** build the loudest feature request. Build the fix that has:

- 5+ independent mentions or 20%+ of cancellers in one churn bucket
- direct connection to activation, repeated use, or perceived value
- low-to-medium engineering/design effort
- a clear before/after metric you can measure within 30 days

## Minimum sample size

- 5 interviews: enough to spot obvious onboarding/confusion issues.
- 10–15 interviews: enough to prioritize one serious retention fix.
- 25+ survey responses: enough to compare churn buckets directionally.

This kit is for founder judgement, not statistically perfect research.
