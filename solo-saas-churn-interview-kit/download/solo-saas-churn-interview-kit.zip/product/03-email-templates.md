# Churn outreach email templates

## Recent cancellation
Subject: quick question about why you cancelled

Hi {{first_name}},

I noticed you cancelled {{product}}. I am not trying to win you back — I am trying to understand what did not work.

Would you be open to a 10-minute call, or just replying with the main reason?

The most useful question is: what were you hoping {{product}} would do that it did not do well enough?

Thanks,
{{your_name}}

## No-call version
Subject: one-question cancellation feedback

Hi {{first_name}},

One quick question: what was the main reason {{product}} was not worth keeping?

A blunt answer is perfect.

Thanks,
{{your_name}}
