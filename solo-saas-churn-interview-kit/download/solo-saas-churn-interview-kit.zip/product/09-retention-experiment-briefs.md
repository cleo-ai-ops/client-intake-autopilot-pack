# Retention experiment briefs

Use these when your interviews point to a bucket but you need a safe first fix.

## Activation gap: “I never got value”

**Hypothesis:** If new users reach a concrete preview/demo before setup, more will complete onboarding.

**Change:** Add a sample project, preview state, or first-result generator before asking for integrations/imports.

**Measure:** Signup → first value action. Compare 14 days before/after.

**Avoid:** Rewriting the whole onboarding. Fix the single step where momentum dies.

## Trust gap: “I was not sure it worked”

**Hypothesis:** If users see proof-of-work and audit trails, fewer will cancel from uncertainty.

**Change:** Add weekly proof email, activity log, “test this automation,” or visible status checks.

**Measure:** % users viewing activity log; churn reason share mentioning trust/uncertainty.

## Price-value gap: “Too expensive”

**Hypothesis:** If value is quantified before renewal/cancellation, price objections drop.

**Change:** Show saved time, avoided cost, revenue protected, or tasks completed. Put it near billing/cancellation.

**Measure:** Cancellation survey price-value bucket; save-rate on cancellation page.

## Missing workflow: “It does not fit how I work”

**Hypothesis:** If you support the highest-value repeated workflow, a profitable segment retains better.

**Change:** Build the smallest workflow bridge: import/export, Zapier/n8n recipe, CSV path, or one native integration.

**Measure:** Retention for accounts using that workflow vs not.

## Poor-fit churn

**Hypothesis:** If acquisition and onboarding filter poor-fit users earlier, support load and avoidable churn improve.

**Change:** Add “best for / not for” copy, qualification questions, templates by segment, or plan guidance.

**Measure:** Refund/cancel rate by acquisition channel and segment.
