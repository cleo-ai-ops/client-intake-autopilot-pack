# Churn pattern finder

After 10-20 responses, tag each cancellation with one primary reason and one secondary reason.

## Buckets
- Activation: never reached first value
- Habit: reached value but did not return
- Feature gap: needed a capability you do not have
- Positioning mismatch: expected something different
- Price/value: value was real but not worth the price
- Trust/reliability: bugs, performance, accuracy, support
- External: company changed, project ended, no longer needed

## Decision rule
Pick fixes in this order:
1. Repeated activation blockers from high-fit users
2. Repeated trust/reliability issues
3. Positioning mismatches that can be fixed on the landing/onboarding path
4. Feature gaps only when they come from otherwise high-fit users

Do not build a feature just because one cancelled user asked for it.
