# Churn interview notes template

Copy this once per customer.

## Customer snapshot

- Customer / account:
- Plan / price:
- Signed up:
- Cancelled:
- Usage level before cancel:
- Original acquisition source:
- Segment:

## Original job-to-be-done

What were they trying to accomplish?

> Quote:

## Expected value

What did they expect the product to do quickly?

> Quote:

## Actual experience

Where did they get value? Where did momentum slow?

> Quote:

## Cancellation trigger

What happened right before cancel?

> Quote:

## Bucket coding

- Primary bucket: Activation / Missing workflow / Price-value / Bugs-trust / Team priority / Poor fit / Competitor / Other
- Secondary bucket:
- Avoidable churn? Yes / No / Unsure
- Confidence: Low / Medium / High

## Retention fix hypothesis

If we did ___, customers like this would be more likely to ___ because ___.

## Evidence strength

- Is this repeated by other customers? Yes / No / Unknown
- Connected to revenue/account quality? Yes / No
- Fix likely measurable in 30 days? Yes / No

## Follow-up promised

- None / Summary / Winback later / Bug update / Feature update
