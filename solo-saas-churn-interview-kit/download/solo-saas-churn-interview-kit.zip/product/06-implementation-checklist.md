# Implementation checklist

- Add cancellation survey to the cancellation flow or confirmation email.
- Export the last 30 cancelled customers.
- Send the recent cancellation email to 10 users.
- Run at least 5 interviews before changing the product.
- Tag every response with a churn bucket.
- Prioritize one retention fix with the CSV.
- Ship the smallest fix.
- Email interviewed users only if the fix directly matches what they described.
