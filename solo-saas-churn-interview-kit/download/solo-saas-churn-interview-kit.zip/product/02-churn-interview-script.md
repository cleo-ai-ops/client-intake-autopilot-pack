# 15-minute churn interview script

## Opening
Thanks for taking the time. This is not a sales call and I will not try to win you back. I just want to understand what broke so I can make the product better.

## Questions
1. What was happening in your work when you first signed up?
2. What did you expect the product to solve?
3. What was the first moment it felt less useful than expected?
4. Was cancellation caused by product, price, timing, trust, onboarding, or something else?
5. What did you try before deciding to cancel?
6. What alternative are you using now? Why that one?
7. What would have made the product obviously worth keeping?
8. If a founder friend had the same problem, would you recommend this product? Why or why not?

## Close
If I shipped the fix you described, would it be okay to send you one short note?
