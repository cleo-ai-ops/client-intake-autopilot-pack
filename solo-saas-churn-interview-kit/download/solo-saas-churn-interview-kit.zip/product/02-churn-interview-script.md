# 15-minute churn interview script

## Setup

Tone: calm, curious, no selling. Your job is to understand the user’s last-mile experience. Do not defend the product.

Opening line:

> Thanks for taking the time. This is not a winback call. I’m trying to understand where the product stopped being useful so I can fix the right thing. I’ll keep it to 15 minutes.

## The interview

### 1. Context before the product (2 min)
- What were you trying to get done when you first signed up?
- What was happening in your work/business at the time?
- What made this problem urgent enough to try a tool?

Listen for: buying trigger, promised outcome, current workflow.

### 2. First value moment (3 min)
- What did you expect to happen in the first session/day/week?
- Did you reach a moment where you thought “this might work”? What was it?
- Where did momentum slow down?

Listen for: activation gaps, missing setup help, confusing UI, delayed value.

### 3. Cancellation trigger (4 min)
- What happened in the week before you cancelled?
- Was cancellation caused by product fit, price/value, timing, trust, onboarding, bugs, missing integrations, or internal priority changes?
- If you had to choose one reason, what was the deciding reason?
- What did you switch to, if anything?

Probe: “What made that the deciding reason rather than just an annoyance?”

### 4. Value and alternatives (3 min)
- What would the product have needed to do for you to keep paying?
- What would have made the price feel obviously worth it?
- Which alternative feels safer/easier/better now?

Listen for: willingness-to-pay, competitive positioning, trust gaps.

### 5. Fix test (2 min)
- If we fixed [summarized issue], would that have changed your decision?
- What would you need to see before trusting that fix?

### 6. Close (1 min)
- Is there anything I did not ask that would help me understand why you left?
- Can I follow up once with a summary to make sure I understood?

## Coding immediately after the call

Fill `07-interview-notes-template.md` while the memory is fresh. Tag:

- Primary churn bucket
- Secondary bucket
- Exact cancellation trigger
- Most painful quote
- Retention fix hypothesis
- Confidence: Low / Medium / High

## Red flags in interpretation

- “Too expensive” often means value was not obvious, not price alone.
- “Missing feature” often means the user had a workflow your product did not support.
- “No time” often means activation required too much effort or the problem was not urgent.
- “Buggy” can mean trust collapsed even if the bug was small.
