# Worked example: raw churn feedback → retention roadmap

## Product context

Micro-SaaS: invoice reminder automation for freelancers. Price: €15/month. Recent churn: 12 cancellations in 45 days.

## Raw feedback snippets

1. “I connected Stripe but did not know if reminders were actually going out.”
2. “The setup asked for too many things before I saw anything useful.”
3. “€15 is fine if it saves chasing clients, but I wasn’t sure it was working.”
4. “I only invoice twice a month, so I forgot to come back.”
5. “I needed QuickBooks, not just Stripe.”
6. “The reminder copy was too robotic, so I did not want to send it.”
7. “I got an error connecting my account and did not have time to debug.”
8. “I switched back to manual follow-up because I trust it.”

## Bucket coding

| Quote | Primary bucket | Secondary bucket | Avoidable? | Notes |
|---|---|---|---:|---|
| Did not know reminders were going out | Trust/visibility | Activation | Yes | No proof of value |
| Too many things before value | Activation | Onboarding effort | Yes | Setup sequence problem |
| Wasn’t sure it was working | Price-value | Trust | Yes | Price objection caused by unclear ROI |
| Forgot to come back | Frequency/timing | Activation | Maybe | Needs lifecycle nudges |
| Needed QuickBooks | Missing workflow | Integration | Maybe | Segment-specific |
| Copy too robotic | Output quality | Trust | Yes | Template issue |
| Error connecting account | Bug/trust | Activation | Yes | Reliability issue |
| Trust manual follow-up | Trust | Habit | Yes | Needs audit trail/demo |

## Pattern summary

The dominant pattern is **trust before value**. Customers are not rejecting the promise; they do not see proof that the automation is safely working.

Secondary pattern: setup asks for integrations before showing a useful preview.

## Fix options

| Fix | Impact | Confidence | Effort | Reversibility | Score |
|---|---:|---:|---:|---:|---:|
| Add “preview reminder sequence” before integration | 5 | 5 | 2 | 5 | 13 |
| Add sent/reminder audit log and weekly proof email | 5 | 4 | 3 | 5 | 11 |
| Rewrite reminder copy with tone options | 4 | 4 | 1 | 5 | 12 |
| Build QuickBooks integration | 3 | 2 | 5 | 2 | 2 |

Formula used: Impact + Confidence + Reversibility - Effort.

## Recommended 30-day roadmap

Week 1: Add preview sequence and human-sounding copy presets.
Week 2: Add “test reminder to myself” step during onboarding.
Week 3: Add weekly proof email: reminders sent, invoices paid, time saved.
Week 4: Re-interview 5 churned users and watch activation-to-first-reminder rate.

## Metrics to watch

- Signup → first preview created
- First preview → integration connected
- Integration connected → first reminder sent
- First reminder sent → retained after 30 days
- Cancellation reason share: “not sure it was working”
