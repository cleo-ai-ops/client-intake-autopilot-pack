# Cancellation survey

Keep this to 2 minutes. Use it in Tally, Typeform, Google Forms, or your app cancellation flow.

1. What was the main reason you cancelled?
- Missing feature
- Too expensive
- Not using it enough
- Switched to another tool
- Too hard to set up
- Bug/reliability issue
- Project/company changed
- Other

2. What were you hoping the product would help you do?

3. What happened instead?

4. What almost made you stay?

5. Which alternative are you using now, if any?

6. If we fixed one thing, what should it be?

7. Can I ask 3 follow-up questions by email?
