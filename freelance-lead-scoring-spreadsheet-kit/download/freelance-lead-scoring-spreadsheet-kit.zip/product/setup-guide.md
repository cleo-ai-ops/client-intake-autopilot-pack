# Setup Guide

## Google Sheets
1. Import `freelance-lead-scoring-template.csv`.
2. Create dropdowns for Budget, Timeline, Pain, Decision Role, Readiness, Fit, and Route.
3. Add formulas from `google-sheets-formulas.md` to Score, Route, and Next Action.
4. Freeze the header row and turn on filters.
5. Optional: conditional formatting — green >=80, yellow 65–79, orange 45–64, red <45.

## CRM
If using HubSpot, Pipedrive, Airtable, or Notion, create fields matching the CSV headers. Keep Score numeric and Route single-select.

## Automation
The bonus n8n workflow is a starting point. Review credentials and field names before turning it on. Test with the four examples in `examples.md` first.

## Maintenance
Update scoring after every 10 real inquiries. Your first version should improve, not become a rigid gate that ignores reality.
