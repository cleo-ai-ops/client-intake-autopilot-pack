# 30-minute setup guide

## Minute 0-5: copy the template
Import `freelance-lead-scoring-template.csv` into Google Sheets.

## Minute 5-10: add the formulas
Paste the formulas from `google-sheets-formulas.md` into columns L, M, and N.

## Minute 10-15: connect your form
Add the questions from `intake-questions.md` to your form tool.

If you use Google Forms, link responses to the scoring sheet.
If you use Tally or Typeform, export/import manually at first. Automate only after the scoring rules work.

## Minute 15-20: set your thresholds
Start with:
- HOT: 80+
- WARM: 55-79
- COLD: under 55

Adjust after 10 real leads.

## Minute 20-25: save reply scripts
Add the scripts to Gmail templates, TextExpander, Notion, or your CRM.

## Minute 25-30: test three fake leads
Use the examples file and make sure each lead gets the right action.

## Operating rule
Do not book calls from unscored leads. The spreadsheet only works if it sits before your calendar.

