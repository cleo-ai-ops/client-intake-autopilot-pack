# Intake questions to score leads

Use these in Tally, Google Forms, Typeform, Airtable Forms, or your website form.

1. What are you trying to achieve?
2. What deliverable do you think you need?
3. What problem happens if this is not solved?
4. What is your target timeline?
5. What budget range have you set aside?
6. Who will approve the project?
7. Have you worked with a freelancer/agency on this before?
8. What assets, access, or content are already ready?
9. What would make this project a success 30 days after delivery?
10. Is there anything that must be included or avoided?

## High-signal budget question

Instead of “what is your budget?”, use:

> To recommend the right scope, which range should I design around?
> - Under $1k
> - $1k-$3k
> - $3k-$7k
> - $7k+
> - Not sure yet

