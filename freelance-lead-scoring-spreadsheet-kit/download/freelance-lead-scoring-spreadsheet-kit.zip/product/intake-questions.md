# Intake Questions for Scoring

Use these in your contact form. The answer options are designed to map cleanly to the spreadsheet.

1. What outcome are you trying to create?
2. What is currently broken, slow, expensive, or risky?
3. Which service do you want help with?
4. Budget range:
   - Above minimum
   - Within range
   - Unclear
   - Below minimum
5. Timeline:
   - Business-critical
   - 2-4 weeks
   - Exploratory
   - No timeline
6. Decision role:
   - Decision maker
   - Shared decision
   - Needs approval
7. Readiness:
   - Ready: assets/access/examples available
   - Partly ready
   - Not ready
8. Fit:
   - Ideal fit
   - Good fit
   - Adjacent
   - Poor fit / not sure
9. Any red flags or constraints? *(deadline, compliance, platform, internal approvals)*
10. Links/examples/context.

## Form note
Tell leads why you ask budget: “Budget range helps me recommend the right next step: full project, paid audit, smaller scope, or referral.”
