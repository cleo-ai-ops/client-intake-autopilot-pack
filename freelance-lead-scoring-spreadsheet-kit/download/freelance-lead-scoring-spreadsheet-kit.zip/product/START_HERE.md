# Freelance Lead Scoring Spreadsheet Kit — Start Here

This kit helps you rank inbound leads before you book calls. It is built for freelancers, consultants, studios, and small agencies that get enough inquiries to waste time on low-fit conversations.

## Fast setup
1. Open `freelance-lead-scoring-template.csv` in Google Sheets or Excel.
2. Add your minimum budget and best-fit service notes in row 2 comments or a separate tab.
3. Copy formulas from `google-sheets-formulas.md` into the Score and Route columns.
4. Paste your intake questions from `intake-questions.md` into a form.
5. Use `reply-scripts.md` to route each lead.

## Core rule
Do not treat every inquiry as a sales call. Treat every inquiry as a routing decision.

## Included
- CSV template with sample leads and scoring columns
- scoring rules and red flags
- Google Sheets formulas
- intake questions
- reply scripts
- examples
- bonus n8n workflow JSON for form-to-score automation
