# Freelance Lead Scoring Spreadsheet Kit

A lightweight qualification system for freelancers who waste time on weak leads, vague projects, unpaid discovery calls, and scope-creep clients.

Use it to score every inquiry before booking a call.

## What is inside

1. `freelance-lead-scoring-template.csv` — import into Google Sheets, Excel, or Airtable.
2. `google-sheets-formulas.md` — copy/paste scoring formulas.
3. `lead-scoring-rules.md` — exact point rules and red/yellow/green thresholds.
4. `intake-questions.md` — questions to put in your form.
5. `reply-scripts.md` — hot/warm/cold lead response templates.
6. `setup-guide.md` — 30-minute setup instructions.
7. `examples.md` — three scored example leads.

## Fast setup

1. Import the CSV into Google Sheets.
2. Add your client intake answers as new rows.
3. Paste the formulas from `google-sheets-formulas.md`.
4. Send HOT leads to booking, WARM leads to clarification, COLD leads to a polite decline or paid audit.

## Recommended thresholds

- 80+ = HOT: book a discovery call.
- 55-79 = WARM: ask clarifying questions before a call.
- Under 55 = COLD: decline, defer, or offer a paid diagnostic.

