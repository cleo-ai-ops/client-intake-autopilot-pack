# Google Sheets Formulas

Assume columns:
A Date, B Name, C Email, D Source, E Budget, F Timeline, G Pain, H Decision Role, I Readiness, J Fit, K Red Flags, L Score, M Route, N Next Action.

## Score formula
Paste into L2 and fill down:

```gs
=MAX(0, MIN(100,
IFS(E2="Above minimum",20,E2="Within range",15,E2="Unclear",8,E2="Below minimum",0,TRUE,0)+
IFS(F2="Business-critical",15,F2="2-4 weeks",10,F2="Exploratory",5,F2="No timeline",0,TRUE,0)+
IFS(G2="Outcome + cost clear",20,G2="Problem clear",14,G2="Vague",5,TRUE,0)+
IFS(H2="Decision maker",15,H2="Shared decision",10,H2="Needs approval",5,TRUE,0)+
IFS(I2="Ready",15,I2="Partly ready",8,I2="Not ready",2,TRUE,0)+
IFS(J2="Ideal fit",15,J2="Good fit",10,J2="Adjacent",5,J2="Poor fit",0,TRUE,0)-
IF(REGEXMATCH(LOWER(K2),"abusive|free strategy|spec work|impossible deadline"),20,0)-
IF(REGEXMATCH(LOWER(K2),"no budget|too many decision makers|quick simple"),10,0)
))
```

## Route formula
Paste into M2:

```gs
=IFS(L2>=80,"Priority booking",L2>=65,"Clarify first",L2>=45,"Paid audit / nurture",TRUE,"Decline / refer")
```

## Next action formula
Paste into N2:

```gs
=IFS(M2="Priority booking","Send booking script",M2="Clarify first","Ask 2-3 missing questions",M2="Paid audit / nurture","Offer diagnostic or resource",TRUE,"Send polite decline")
```

## Simple dashboard formulas
- Average score: `=AVERAGE(L2:L)`
- Priority leads this month: `=COUNTIFS(M2:M,"Priority booking",A2:A,">="&EOMONTH(TODAY(),-1)+1)`
- Top source by lead count: use a pivot table on Source and Route.
