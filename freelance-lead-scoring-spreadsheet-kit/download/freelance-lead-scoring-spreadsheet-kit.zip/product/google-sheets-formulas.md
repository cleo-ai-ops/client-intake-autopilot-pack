# Google Sheets formulas

Assuming your score columns are D through K and penalty is column K:

## Total Score
Paste in `L2` and drag down:

```gs
=SUM(D2:J2)+K2
```

## Tier
Paste in `M2` and drag down:

```gs
=IF(L2>=80,"HOT",IF(L2>=55,"WARM","COLD"))
```

## Next Action
Paste in `N2` and drag down:

```gs
=IF(M2="HOT","Send booking link",IF(M2="WARM","Ask clarification questions","Decline or offer paid diagnostic"))
```

## Optional conditional formatting

- HOT: green background when `M:M` contains `HOT`
- WARM: yellow background when `M:M` contains `WARM`
- COLD: red/grey background when `M:M` contains `COLD`

