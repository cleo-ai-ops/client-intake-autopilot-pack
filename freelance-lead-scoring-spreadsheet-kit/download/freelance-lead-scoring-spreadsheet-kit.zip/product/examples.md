# Scored Examples

## Example 1 — Priority
Automation lead, €4k budget, launch in 3 weeks, decision maker, tools known, clear time-savings goal.
Score: 92. Route: Priority booking.
Why: urgent business reason, budget fit, clear outcome.

## Example 2 — Clarify
Website redesign lead, says “budget is flexible,” wants better conversions, no launch date, shared decision.
Score: 68. Route: Clarify first.
Ask: current conversion baseline, decision owner, target launch window.

## Example 3 — Paid audit
Operations team wants “make everything smoother,” has many tools and stakeholders but no defined scope.
Score: 55. Route: Paid audit.
Why: real pain, but quoting implementation now is risky.

## Example 4 — Decline
Lead wants a full brand, website, ads, and funnel by Friday for €300.
Score: 18. Route: Decline/referral.
Why: impossible deadline and budget mismatch.
