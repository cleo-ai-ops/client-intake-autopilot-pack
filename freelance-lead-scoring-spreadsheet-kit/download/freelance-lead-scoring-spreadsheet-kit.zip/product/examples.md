# Scored examples

## Hot lead — score 86
A SaaS founder wants a landing page rebuild before a funded launch. Budget is $5k-$7k. Founder is the decision maker. Timeline is 5 weeks. Existing copy and analytics are ready.

Decision: send booking link.

## Warm lead — score 64
A small agency needs automation help but has not chosen the form/CRM stack. Budget is likely okay, but decision maker and success metric are unclear.

Decision: ask clarification questions before booking.

## Cold lead — score 21
A founder wants logo, website, ads, analytics, and “maybe SEO” by next week for under $500. They ask for ideas before paying.

Decision: decline or offer paid diagnostic.

