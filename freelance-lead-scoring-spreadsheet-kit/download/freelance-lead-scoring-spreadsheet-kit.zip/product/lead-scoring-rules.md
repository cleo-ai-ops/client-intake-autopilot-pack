# Lead Scoring Rules

Score out of 100. A high score means “worth fast human attention,” not “guaranteed client.”

## Categories
| Category | Max | What to look for |
|---|---:|---|
| Budget fit | 20 | Budget matches your minimum and the likely scope. |
| Urgency | 15 | There is a real business date or cost of delay. |
| Pain clarity | 20 | They explain the problem, impact, and desired outcome. |
| Decision access | 15 | You are speaking with the buyer or clear buying group. |
| Scope readiness | 15 | Assets, access, stakeholders, and constraints are known. |
| Niche/service fit | 15 | The project matches work you can deliver profitably. |

## Budget fit
- 20: comfortably above minimum
- 15: within normal range
- 8: unclear but plausible
- 0: below minimum or “exposure/equity only”

## Urgency
- 15: deadline tied to launch, revenue, compliance, churn, or operational pain
- 10: wants movement in 2–4 weeks
- 5: exploratory
- 0: no timeline or “someday”

## Red flag deductions
- -20: abusive, manipulative, or dismissive tone
- -15: asks for free strategy/spec work before fit
- -15: deadline impossible without cutting quality
- -10: refuses to share budget range after explanation
- -10: too many decision makers with no owner
- -5: “simple/easy/quick” language around complex work

## Routing thresholds
- 80–100: send priority booking link
- 65–79: ask clarification questions
- 45–64: offer paid audit, async consult, or nurture sequence
- 0–44: decline or refer out

## Weekly calibration
Every Friday, review won/lost leads and adjust weights. If many low scores become good clients, your criteria are wrong. If many high scores waste time, your intake questions are too vague.
