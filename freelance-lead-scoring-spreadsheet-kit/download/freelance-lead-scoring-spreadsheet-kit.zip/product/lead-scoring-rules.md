# Lead scoring rules

## Budget Fit — 0 to 20
- 20: budget is stated and fits your minimum.
- 12: budget is close but needs scope control.
- 5: budget is vague or below normal.
- 0: no budget / wants a quote before explaining the work.

## Timeline Fit — 0 to 15
- 15: realistic timeline with room for discovery.
- 10: slightly urgent but manageable.
- 5: rushed and unclear.
- 0: emergency deadline caused by poor planning.

## Decision Maker — 0 to 15
- 15: you are speaking to the buyer/owner.
- 8: contact influences the decision but needs approval.
- 0: no clear decision maker.

## Scope Clarity — 0 to 15
- 15: deliverables, goals, and constraints are clear.
- 8: direction exists but details are missing.
- 0: wants “everything” or cannot define success.

## Urgency — 0 to 10
- 10: timely need with business reason.
- 5: casual exploration.
- 0: no timeline or false urgency.

## Respect / Communication — 0 to 10
- 10: concise, respectful, answers questions.
- 5: scattered but workable.
- 0: rude, evasive, or dismissive.

## Strategic Fit — 0 to 10
- 10: matches your best service and case studies.
- 5: adjacent work.
- 0: outside your positioning.

## Red Flags Penalty — 0 to -25
Subtract for:
- asks for free samples/spec work: -10
- refuses to share budget: -5
- “quick/easy/simple” language for complex work: -5
- too many decision makers: -5
- past freelancer conflict without ownership: -10
- unpaid strategy request before qualification: -10

