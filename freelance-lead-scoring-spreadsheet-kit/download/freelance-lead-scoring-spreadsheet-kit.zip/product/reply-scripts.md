# Reply scripts

## HOT lead: send booking link

Subject: Re: your project

Hi {{name}},

Thanks — this looks like a strong fit. Based on your answers, the scope, timeline, and decision path are clear enough for a focused discovery call.

You can book a time here: {{booking_link}}

Before the call, I’ll review your answers and come prepared with the key scope/risk questions so we can decide quickly whether this should move to proposal.

— {{your_name}}

## WARM lead: clarify before call

Subject: Quick questions before we book

Hi {{name}},

Thanks for sending this through. I can probably help, but I need to clarify a couple of things before booking a call so we do not waste your time.

1. Who will make the final decision on this project?
2. Which budget range should I design the scope around?
3. What is the most important outcome you need from this?

Once I have those, I’ll tell you whether a discovery call makes sense.

— {{your_name}}

## COLD lead: polite decline / paid diagnostic

Subject: Re: your project

Hi {{name}},

Thanks for reaching out. Based on the current scope/timeline/budget, I do not think a standard project call is the best next step.

If you want, I can offer a paid diagnostic where I review the situation and give you a practical scope recommendation. Otherwise, I’d suggest clarifying the budget, decision maker, and must-have deliverables first.

Either way, I appreciate you thinking of me.

— {{your_name}}

