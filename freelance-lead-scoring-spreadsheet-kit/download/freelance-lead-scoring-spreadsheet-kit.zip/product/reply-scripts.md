# Reply Scripts by Route

## Priority booking
Subject: Next step for [outcome]

Hi [Name], your answers point to a strong fit: [specific pain] + [timeline/business reason]. Book a 25-minute fit call here: [link]. We’ll confirm scope, budget, decision process, and the safest next step.

## Clarify first
Subject: Quick clarification before I recommend a path

Hi [Name], I can likely help, but I need two details before suggesting a call:
1. [missing scope/timeline question]
2. [missing budget/decision question]

Once I have those, I’ll either send a booking link or recommend a better next step.

## Paid audit / nurture
Subject: A safer first step

Hi [Name], this looks useful but not ready for a full build quote yet. I recommend a paid diagnostic: [deliverables], [timeline], [fee]. If you proceed to implementation within [window], [credit policy].

## Decline / refer
Subject: Re: [project]

Hi [Name], thanks for reaching out. I’m not the right fit because [reason]. I’d suggest [resource/referral/smaller next step]. If the scope changes to [fit criteria], feel free to send the updated brief.

## Re-engage dormant lead
Subject: Still working on [outcome]?

Hi [Name], checking once before I close this out. If [problem] is still active and you now have [missing requirement], reply with the update and I’ll re-score it.
