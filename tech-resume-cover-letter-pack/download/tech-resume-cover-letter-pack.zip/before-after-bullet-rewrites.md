# Before/after bullet rewrites

## Software engineer

Before: Worked on API performance.

After: Reduced p95 API latency from 1.8s to 420ms by adding Redis caching, optimizing PostgreSQL indexes, and removing duplicate external calls across 6 high-traffic endpoints.

Before: Built frontend features in React.

After: Shipped React onboarding flow used by 18k monthly signups, increasing activation from 31% to 44% through progressive profiling and clearer empty states.

## Product manager

Before: Managed roadmap for mobile app.

After: Led mobile roadmap for a 220k-user app, prioritizing retention experiments that improved week-4 retention by 9% and reduced support tickets by 18%.

Before: Talked to customers and wrote requirements.

After: Conducted 42 customer interviews, translated recurring workflow pain into 6 prioritized PRDs, and launched 3 features that drove €240k expansion pipeline.

## UX/product designer

Before: Redesigned dashboard.

After: Redesigned analytics dashboard after usability testing with 12 account managers, cutting time-to-insight from 6 minutes to 90 seconds and increasing weekly active usage by 27%.

Before: Made wireframes and prototypes.

After: Created low- and high-fidelity prototypes for checkout recovery flow, aligning product, engineering, and lifecycle teams around a design that recovered €1.2M annualized revenue.

## Career changer

Before: Helped with operations reports.

After: Automated weekly operations reporting with SQL and Google Sheets, reducing manual preparation from 5 hours to 35 minutes and creating the analytics foundation for my transition into data/product work.
