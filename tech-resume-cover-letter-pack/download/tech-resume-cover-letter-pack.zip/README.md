# Tech Resume & Cover Letter Template Pack

## What's Included
- 3 ATS-optimized resume templates (Word/Google Docs format)
  - Software Developer Resume
  - Product Manager Resume  
  - UX/UI Designer Resume
- 3 matching cover letter templates
- ATS optimization checklist (how to beat Applicant Tracking Systems)
- Keywords cheat sheet for tech roles
- Interview prep sheet template

## Target Buyer
Tech professionals actively job hunting who need professional, ATS-friendly templates that get past automated screening systems.

## Price: $9
## Distribution Channels
- r/resumes, r/jobs, r/careerguidance on Reddit
- Career advice forums and communities
- Gumroad marketplace (resume templates category)
- LinkedIn job search groups
- College career centers
