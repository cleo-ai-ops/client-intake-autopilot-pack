# Tech Resume & Cover Letter Pack

ATS-safe resume, cover letter, and job-search templates for software engineers, product managers, and UX/product designers.

## Price: €12

## Format note

This pack contains editable Markdown and plain-text templates designed to copy cleanly into Google Docs, Microsoft Word, Notion, or any text editor. It does **not** contain native `.docx` files.

## What's included

- 3 role-specific resume templates: software developer, product manager, UX/product designer
- 3 copy-paste Google Docs / Word-ready plain-text resume versions
- 3 filled sample resumes showing strong bullet depth
- Cover letter templates for referral, cold application, recruiter follow-up, and career pivot
- ATS optimization checklist
- Tech keywords cheat sheet
- Job-description tailoring worksheet
- Before/after bullet rewrite examples
- 30-minute resume upgrade guide
- Interview prep sheet

## Who this is for

- Tech professionals applying to software, product, UX, data, or adjacent roles
- Job seekers getting low callbacks and needing clearer positioning
- Career changers who need to translate experience into measurable impact

## 30-minute path

1. Read `30-minute-resume-upgrade-guide.md`.
2. Pick the role template closest to your target role.
3. Use `job-description-tailoring-worksheet.md` against one real job post.
4. Rewrite 6 bullets using `before-after-bullet-rewrites.md`.
5. Run the ATS checklist before exporting to PDF.
