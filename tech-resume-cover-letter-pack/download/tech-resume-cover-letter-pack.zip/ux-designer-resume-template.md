# UX/UI DESIGNER RESUME TEMPLATE (ATS-Aware)

## Instructions
Replace all [BRACKETED] text with your information. This template is designed for ATS readability while highlighting your design impact.

---

[FIRST NAME] [LAST NAME]
[City, State] | [Phone Number] | [Email Address] | [LinkedIn URL] | [Portfolio URL] | [Dribbble/Behance URL]

## PROFESSIONAL SUMMARY
Creative and data-driven UX/UI Designer with [X] years of experience crafting [user-centered / accessible / conversion-optimized] digital experiences for [web / mobile / SaaS / e-commerce] products. Proven ability to [specific achievement, e.g., "redesigning checkout flow that increased conversions by 35%"]. Skilled in [key skills: user research, interaction design, design systems, prototyping].

## DESIGN SKILLS
- **Design & Prototyping:** Figma, Sketch, Adobe XD, InVision, Framer, Principle
- **Research & Testing:** User interviews, usability testing, A/B testing, survey design, card sorting, heuristic evaluation
- **Visual Design:** Typography, color theory, iconography, illustration, responsive design
- **Design Systems:** Component libraries, design tokens, accessibility standards (WCAG 2.1)
- **Front-end Understanding:** HTML, CSS, basic JavaScript, design-to-code handoff
- **Methodologies:** Design Thinking, Lean UX, Jobs-to-be-Done, Mobile-first, Atomic Design

## PROFESSIONAL EXPERIENCE

### Senior UX/UI Designer | [Company Name] | [Start Date] - [End Date]
- [Action verb] [what you designed] resulting in [measurable impact]
  - Example: Redesigned core product experience for SaaS platform, improving task completion rate from 62% to 89%
  - Example: Led design system initiative creating 150+ reusable components, reducing design-to-development time by 40%
  - Example: Conducted 30+ user research sessions informing product strategy, directly influencing 5 feature launches
  - Example: Designed responsive e-commerce checkout flow that increased mobile conversion rate by 35%

### UX/UI Designer | [Company Name] | [Start Date] - [End Date]
- [Action verb] [what you designed] resulting in [measurable impact]
  - Example: Created end-to-end design for mobile banking app feature used by 100K+ monthly active users
  - Example: Established design system from scratch, including typography scale, color palette, and component library

## FEATURED PROJECTS (link to portfolio)

### [Project Name] | [Company/Personal] | [Link]
- **Challenge:** [What problem were you solving?]
- **Process:** [Research → Design → Testing approach]
- **Outcome:** [Measurable results]
- Example: Redesigned onboarding for B2B SaaS — Conducted 15 user interviews → Created 3 design concepts → Tested with 50 users → 28% increase in activation rate

### [Project Name] | [Company/Personal] | [Link]
- **Challenge:** [What problem?]
- **Process:** [Your approach]
- **Outcome:** [Results]

## EDUCATION

### [Degree] in [Field] | [University Name] | [Graduation Year]
- [Optional: Relevant coursework, thesis, design awards]

## CERTIFICATIONS (Optional)
- Google UX Design Certificate — Google/Coursera — 2024
- Interaction Design Foundation Certificate — [Year]

---

## ATS OPTIMIZATION TIPS FOR THIS TEMPLATE:
1. Include specific design tools by name (ATS scans for Figma, Sketch, etc.)
2. Quantify design impact wherever possible (conversion %, user satisfaction scores, task completion rates)
3. Include both "UX" and "User Experience" — ATS may search for either
4. List accessibility standards (WCAG) — increasingly required in job descriptions
5. Keep the portfolio link prominent but don't rely on it for ATS
6. Use standard section headers
