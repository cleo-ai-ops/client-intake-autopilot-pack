# Interview Preparation Sheet Template

Use this template to prepare for every interview. Print it or keep it open on a second screen.

## Company Research

**Company:** [Company Name]
**Position:** [Job Title]
**Interview Date:** [Date]
**Interviewer(s):** [Names and titles — check LinkedIn]

### Company Basics
- **What they do:** [1-2 sentences in your own words]
- **Product/Service:** [Main product and how it makes money]
- **Market position:** [Competitors and differentiation]
- **Recent news:** [Any recent funding, launches, press — check their blog/news page]
- **Culture values:** [Check their careers page, Glassdoor, LinkedIn]

### Why This Company? (Prepare 2-3 reasons)
1. [Reason tied to their product/mission]
2. [Reason tied to their technology/approach]
3. [Reason tied to their growth/stage]

## Your Stories (STAR Method)

Prepare 6-8 stories that cover common interview themes. Use the STAR format: Situation, Task, Action, Result.

### Story 1: A challenging technical problem you solved
- **Situation:** [Context]
- **Task:** [What needed to be done]
- **Action:** [What you specifically did]
- **Result:** [Measurable outcome]
- **Keywords to highlight:** [Skills demonstrated]

### Story 2: A time you worked with a difficult team member
- **Situation:** 
- **Task:** 
- **Action:** 
- **Result:** 
- **Keywords to highlight:** 

### Story 3: A project that didn't go as planned
- **Situation:** 
- **Task:** 
- **Action:** 
- **Result:** 
- **Keywords to highlight:** 

### Story 4: Your proudest achievement
- **Situation:** 
- **Task:** 
- **Action:** 
- **Result:** 
- **Keywords to highlight:** 

### Story 5: A time you learned something quickly
- **Situation:** 
- **Task:** 
- **Action:** 
- **Result:** 
- **Keywords to highlight:** 

### Story 6: A time you showed leadership
- **Situation:** 
- **Task:** 
- **Action:** 
- **Result:** 
- **Keywords to highlight:** 

## Questions to Ask the Interviewer

### About the Role
1. What does a typical day/week look like in this role?
2. What are the biggest challenges the person in this role will face?
3. How do you measure success for this position in the first 90 days?

### About the Team
4. Can you tell me about the team I'd be working with?
5. How does the team collaborate day-to-day?
6. What's the team's biggest priority right now?

### About the Company
7. How would you describe the company culture?
8. What excites you most about working here?
9. How has the company evolved since you joined?

### About Growth
10. What does career growth look like in this role?
11. How does the company invest in learning and development?

## Technical Prep (For Developer Roles)

### Must-Review Topics
- [ ] Data structures: Arrays, Hash Maps, Trees, Graphs, Linked Lists
- [ ] Algorithms: Sorting, Searching, Dynamic Programming, BFS/DFS
- [ ] System Design: Load balancing, Caching, Database design, API design
- [ ] Language-specific: [Review core features of your primary language]
- [ ] Behavioral: Leadership Principles (if Amazon), Googleyness (if Google)

### Practice Resources
- LeetCode: Focus on the company's top 50 tagged problems
- System Design: "Design X" videos on YouTube
- Company-specific: Check Glassdoor for recent interview questions

## Logistics Checklist
- [ ] Confirm date, time, and timezone
- [ ] Test video/audio (for remote interviews)
- [ ] Prepare outfit (for in-person interviews)
- [ ] Print 2 copies of resume (in-person) or have PDF ready (remote)
- [ ] Prepare notebook and pen
- [ ] Arrive/login 5-10 minutes early
- [ ] Send thank-you email within 24 hours

## Post-Interview Notes (Fill in after)
- What went well:
- What I'd improve:
- Questions I struggled with:
- Follow-up items to send:
