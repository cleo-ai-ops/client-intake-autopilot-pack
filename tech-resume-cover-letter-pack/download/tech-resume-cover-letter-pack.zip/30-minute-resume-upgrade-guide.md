# 30-minute resume upgrade guide

## 0–5 min: choose your target

Write one target role and one target company type. Example: “Backend engineer at B2B SaaS companies, 50–500 employees.” A resume for everyone reads like a resume for no one.

## 5–12 min: pull keywords from one real job description

Highlight:

- hard skills/tools
- domain words
- seniority expectations
- collaboration words
- business outcomes

Add the top 12 to `job-description-tailoring-worksheet.md`.

## 12–22 min: rewrite your strongest bullets

Use this pattern:

> Built/led/improved [thing] for [user/system] using [tools/approach], resulting in [measurable outcome].

If you do not have metrics, use scope:

- number of users/customers
- team size
- data volume
- response time
- frequency
- before/after process time

## 22–27 min: tighten top third

The top third should answer:

- What role are you credible for?
- What environments have you worked in?
- What outcomes do you repeatedly create?

## 27–30 min: ATS-safe export

- one column
- standard headings
- no icons/tables/text boxes
- PDF unless the job asks for DOCX
- filename: `FirstLast_TargetRole_Resume.pdf`
