# COVER LETTER TEMPLATES (ATS-Optimized)

## Template 1: Software Developer Cover Letter

[FIRST NAME] [LAST NAME]
[Your Address]
[City, State, ZIP]
[Phone] | [Email] | [LinkedIn] | [GitHub]

[Date]

[Hiring Manager Name] (or "Hiring Manager" if name unknown)
[Company Name]
[Company Address]
[City, State, ZIP]

Dear [Hiring Manager Name],

I'm writing to express my strong interest in the [Job Title] position at [Company Name]. With [X] years of experience building [type of applications] and a deep focus on [relevant skill, e.g., "scalable backend systems" or "performant front-end experiences"], I'm excited about the opportunity to contribute to [specific thing about the company that excites you — reference their product, mission, or recent news].

In my current role at [Current Company], I [your most impressive achievement relevant to this job]. Specifically, I [quantified result]. This experience taught me how to [relevant lesson that connects to the new role].

What draws me to [Company Name] is [specific reason that shows you've researched them]. I believe my experience with [relevant technology/methodology that matches their stack] would allow me to hit the ground running and contribute meaningfully to [specific team or project mentioned in the job description].

Key highlights of my background:
- [Achievement 1 with metrics]
- [Achievement 2 with metrics]  
- [Achievement 3 with metrics]

I'd welcome the opportunity to discuss how my skills and experience align with your team's needs. I'm available for an interview at your convenience and can start [timeline].

Thank you for your consideration.

Best regards,
[Your Name]

---

## Template 2: Product Manager Cover Letter

[FIRST NAME] [LAST NAME]
[Contact Information]

[Date]

[Hiring Manager]
[Company Name]

Dear [Hiring Manager Name],

I'm applying for the [Job Title] role at [Company Name] because [genuine reason — their product, market, mission]. As a Product Manager with [X] years of experience [specific focus area], I've developed a track record of [key strength: launching products, growing metrics, solving complex problems].

At [Current/Previous Company], I led [specific product initiative] that [measurable result]. I achieved this by [brief methodology — e.g., "conducting extensive customer research, defining clear success metrics, and aligning cross-functional teams around a shared roadmap"].

I'm particularly excited about [Company Name] because [specific observation about their product or market position]. I see an opportunity to [how you'd contribute — specific, not generic]. My experience with [relevant PM skill: data analysis, go-to-market strategy, technical product management] would be directly applicable to [specific challenge the company faces].

Highlights:
- [Product launch with quantified business impact]
- [Growth metric you drove]
- [Cross-functional leadership achievement]

I'd love to discuss how my product sense and execution skills can contribute to [Company Name]'s next chapter. I'm available for a conversation at your convenience.

Best regards,
[Your Name]

---

## Template 3: UX Designer Cover Letter

[FIRST NAME] [LAST NAME]
[Contact Information] | [Portfolio URL]

[Date]

[Hiring Manager]
[Company Name]

Dear [Hiring Manager Name],

I'm writing to apply for the [Job Title] position at [Company Name]. As a UX Designer with [X] years of experience creating [type of experiences: user-centered, accessible, data-informed] designs, I'm drawn to [Company Name]'s commitment to [something genuine about their design culture or product].

My design process is grounded in [your approach: research-first, data-informed, collaborative]. At [Current/Previous Company], I [key project] which resulted in [measurable outcome — e.g., "a 40% improvement in task completion rate" or "a 25% increase in user satisfaction scores"]. You can see this work in my portfolio at [link].

What excites me about [Company Name] is [specific detail]. I believe my experience with [specific skill: design systems, user research, accessibility] would complement your team's work on [specific product area mentioned in the job posting].

My portfolio ( [URL] ) showcases:
- [Project 1 with brief description and results]
- [Project 2 with brief description and results]
- [Project 3 with brief description and results]

I'd welcome the chance to discuss how my design skills and user-centric approach can contribute to [Company Name]'s product experience. I'm available for an interview and portfolio review at your convenience.

Best regards,
[Your Name]

---

## COVER LETTER WRITING TIPS:
1. **Customize every letter** — Hiring managers can spot templates instantly
2. **Lead with impact, not "I'm writing to..."** — Open with what excites you about the role
3. **Show, don't tell** — Use specific examples and metrics, not adjectives
4. **Research the company** — Reference a specific product, feature, blog post, or recent news
5. **Connect your experience to their needs** — Don't just list your background
6. **Keep it under 400 words** — Hiring managers skim cover letters
7. **Address the hiring manager by name** when possible (check LinkedIn)
8. **Don't repeat your resume** — Add context and story that the resume can't convey
