# ATS Optimization Checklist

## What is ATS?
Applicant Tracking Systems (ATS) are software tools used by 98% of Fortune 500 companies and most mid-size companies to screen resumes before a human ever sees them. If a resume is hard for an ATS to parse, important details can be missed before a recruiter reviews it.

## Pre-Writing Checklist
- [ ] Read the job description carefully and highlight key skills, technologies, and qualifications
- [ ] Identify the top 10 keywords from the job posting
- [ ] Note the required vs. preferred qualifications
- [ ] Research the company's tech stack (check their engineering blog, job postings, LinkedIn)

## Formatting Rules (Critical for ATS)
- [ ] Use standard section headers: "Professional Summary," "Experience," "Education," "Skills"
- [ ] No tables, columns, text boxes, or nested formatting
- [ ] No headers/footers (ATS may not parse them)
- [ ] No images, icons, or graphics
- [ ] Standard fonts only (Arial, Calibri, Times New Roman, Helvetica)
- [ ] Font size 10-12pt for body, 12-14pt for headers
- [ ] Standard margins (0.5-1 inch)
- [ ] Save as .docx (best) or .pdf (acceptable)
- [ ] File name: FirstName_LastName_Resume.docx
- [ ] Keep to 1-2 pages maximum

## Content Optimization
- [ ] Include exact keywords from the job description
- [ ] Use both abbreviated and full forms: "JavaScript" AND "JS," "User Experience" AND "UX"
- [ ] Place critical keywords in the Professional Summary and Skills sections
- [ ] Use standard job titles that match the posting (not creative alternatives)
- [ ] Include specific technologies by name: "React" not just "JavaScript framework"
- [ ] Quantify achievements with numbers, percentages, dollar amounts
- [ ] Use strong action verbs: Built, Led, Designed, Implemented, Optimized, Reduced, Increased

## Keyword Density
- [ ] Each major keyword appears at least 2-3 times naturally throughout the resume
- [ ] Keywords appear in context, not just listed (ATS checks surrounding text)
- [ ] Include variations: "project management" AND "managed projects"
- [ ] Don't keyword stuff — ATS detect this and humans will notice

## Contact Information
- [ ] Name on first line, large font
- [ ] Phone number with area code
- [ ] Professional email address
- [ ] LinkedIn URL (customized, not the default with random characters)
- [ ] GitHub/portfolio URL (for tech roles)
- [ ] City and state (don't need full address)

## Common ATS Failures to Avoid
- [ ] No photos or headshots
- [ ] No colored text (black only)
- [ ] No special characters or symbols (✓, ★, ● → use standard bullets)
- [ ] No abbreviations without spelling out first time
- [ ] No uncommon section names like "My Journey" or "What I Do"
- [ ] No links embedded in text (type full URLs)
- [ ] No password-protected PDFs

## Before Submitting
- [ ] Export in the format requested by the job post; when unsure, simple .docx or PDF versions are common choices
- [ ] Test with a free ATS scanner (jobscan.co, resymatch.io)
- [ ] Check that all text is selectable (copy-paste test)
- [ ] Verify the file size is under 5MB
- [ ] Name the file professionally (FirstName_LastName_JobTitle.docx)

## The Numbers
- Many employers use ATS tools before recruiter review
- Quantified achievements make impact clearer to both recruiters and screening systems
- Matching the job title and core keywords truthfully can improve relevance
- Using standard section headers increases parsing accuracy by 50%
