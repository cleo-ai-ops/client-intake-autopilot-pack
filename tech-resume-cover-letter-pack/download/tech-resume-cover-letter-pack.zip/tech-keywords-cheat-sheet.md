# Tech Keywords Cheat Sheet by Role

Use this sheet to match your resume keywords to job descriptions. ATS systems score resumes higher when they contain matching keywords.

## Software Developer Keywords

### Languages
JavaScript, TypeScript, Python, Java, Go, Rust, C++, C#, Ruby, PHP, Swift, Kotlin, Scala, R, MATLAB, SQL, HTML, CSS, Shell/Bash, PowerShell

### Frameworks & Libraries
React, Angular, Vue.js, Next.js, Nuxt.js, Svelte, Node.js, Express, Fastify, Django, Flask, FastAPI, Spring Boot, .NET, Rails, Laravel, Symfony, jQuery, Redux, GraphQL, REST, gRPC

### Databases
PostgreSQL, MySQL, MongoDB, Redis, Elasticsearch, DynamoDB, Cassandra, SQLite, Oracle, Microsoft SQL Server, Neo4j, Firebase, Supabase

### Cloud & Infrastructure
AWS (EC2, S3, Lambda, ECS, EKS, RDS, CloudFront, DynamoDB), Google Cloud Platform (GCP), Microsoft Azure, Docker, Kubernetes, Terraform, Ansible, Jenkins, GitHub Actions, GitLab CI, CircleCI, Nginx, Apache, Linux

### Practices
Agile, Scrum, Kanban, CI/CD, TDD (Test-Driven Development), BDD, DevOps, Microservices, Serverless, Event-Driven Architecture, Domain-Driven Design, SOLID, Design Patterns, Code Review, Pair Programming

### Soft Skills (Important for ATS)
Problem-solving, Communication, Team collaboration, Mentoring, Technical leadership, Cross-functional collaboration, Stakeholder management, Time management

## Product Manager Keywords

### Strategy & Planning
Product roadmap, Product strategy, Go-to-market (GTM), Market research, Competitive analysis, Customer development, Product-market fit, Business model, Value proposition, Pricing strategy

### Data & Analytics
A/B testing, Funnel analysis, Cohort analysis, SQL, Data-driven decision making, KPIs, OKRs, Metrics, Analytics, User analytics, Conversion optimization, Retention, Churn analysis, LTV (Lifetime Value), CAC (Customer Acquisition Cost)

### Methodologies
Agile, Scrum, Lean Startup, Jobs-to-be-Done (JTBD), Design Thinking, Sprint planning, User stories, Backlog management, Prioritization (RICE, MoSCoW, ICE), MVP (Minimum Viable Product)

### Technical
API, SaaS, B2B, B2C, Platform, Integration, Technical specifications, System design, Architecture, SDK, Webhooks

### Tools
Jira, Confluence, Notion, Figma, Amplitude, Mixpanel, Google Analytics, Tableau, Looker, Productboard, Aha!, Miro, Mural

## UX/UI Designer Keywords

### Design Skills
User experience (UX), User interface (UI), Interaction design, Visual design, Information architecture, Wireframing, Prototyping, Responsive design, Mobile-first, Accessibility, Inclusive design, Design systems, Component libraries, Design tokens, Typography, Color theory, Iconography

### Research & Testing
User research, Usability testing, A/B testing, User interviews, Surveys, Card sorting, Tree testing, Heuristic evaluation, Persona development, Journey mapping, Affinity mapping, Contextual inquiry, Eye tracking

### Tools
Figma, Sketch, Adobe XD, Adobe Creative Suite (Photoshop, Illustrator, InDesign), InVision, Framer, Principle, ProtoPie, Axure, Balsamiq, Zeplin, Abstract, Miro, FigJam

### Standards
WCAG 2.1, ADA compliance, Section 508, iOS Human Interface Guidelines, Material Design, Atomic Design, DesignOps

### Methodologies
Design Thinking, Lean UX, Double Diamond, Human-Centered Design (HCD), Jobs-to-be-Done, User-Centered Design (UCD)

## Data Scientist / ML Engineer Keywords

### Core Skills
Machine Learning, Deep Learning, Natural Language Processing (NLP), Computer Vision, Statistical modeling, Predictive modeling, Data mining, Feature engineering, Model deployment, MLOps

### Tools & Frameworks
Python, R, TensorFlow, PyTorch, scikit-learn, pandas, NumPy, Jupyter, Apache Spark, Hadoop, SQL, Tableau, Power BI

### Techniques
Supervised learning, Unsupervised learning, Reinforcement learning, Neural networks, Random forest, Gradient boosting, NLP, LLM, GPT, Transformers, A/B testing, Time series analysis

## DevOps / SRE Keywords

### Core Skills
CI/CD, Infrastructure as Code (IaC), Configuration management, Monitoring, Observability, Incident response, Capacity planning, Performance optimization, Security automation, Container orchestration

### Tools
Docker, Kubernetes, Terraform, Ansible, Puppet, Chef, Jenkins, GitHub Actions, GitLab CI, Prometheus, Grafana, Datadog, ELK Stack (Elasticsearch, Logstash, Kibana), PagerDuty, CloudFormation

### Cloud
AWS, GCP, Azure, Multi-cloud, Hybrid cloud, Serverless, Edge computing

### Practices
Site Reliability Engineering (SRE), DevOps, GitOps, Blue-green deployment, Canary deployment, Feature flags, Chaos engineering, SLA/SLO/SLI

## How to Use This Cheat Sheet

1. **Find your target role** — Copy the relevant keywords section
2. **Cross-reference with the job description** — Which keywords appear in both?
3. **Prioritize exact matches** — If the JD says "React," don't just say "JavaScript framework"
4. **Weave keywords naturally** — Don't just list them; use them in bullet points about your experience
5. **Use full terms + abbreviations** — "Continuous Integration/Continuous Deployment (CI/CD)"
6. **Don't fabricate** — Only include skills you actually have
