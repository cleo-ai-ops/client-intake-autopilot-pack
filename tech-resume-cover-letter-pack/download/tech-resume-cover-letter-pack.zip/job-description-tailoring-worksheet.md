# Job-description tailoring worksheet

Use this for each important application.

## Target role

- Company:
- Role title:
- Link:
- Why this role is a fit:

## Keywords from the job post

| Keyword / phrase | Must-have or nice-to-have? | Where it appears in my resume | Need to add? |
|---|---|---|---|
|  |  |  |  |

## Responsibilities match

| Job responsibility | Matching experience | Resume bullet to update |
|---|---|---|
|  |  |  |

## Proof points to emphasize

- Revenue / cost / growth impact:
- Scale / users / systems:
- Collaboration / leadership:
- Technical depth:
- Domain knowledge:

## Summary rewrite

Before:

After:

## Final check

- [ ] The exact target role appears naturally in the resume.
- [ ] Top 10 keywords appear honestly and naturally.
- [ ] First 5 bullets are the strongest, not merely the most recent.
- [ ] Every bullet has outcome, scope, or technical depth.
