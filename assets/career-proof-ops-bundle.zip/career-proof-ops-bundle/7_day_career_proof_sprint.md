# 7-Day Career Proof Sprint

Day 1: Pick one target role/buyer.
Day 2: Rewrite 5 resume bullets for relevance and proof.
Day 3: Update LinkedIn headline/About.
Day 4: Draft one case study from a real project.
Day 5: Prepare interview follow-up and recruiter check-in scripts.
Day 6: Create one public proof artifact or CFP abstract.
Day 7: Send 5 targeted applications/outreach messages and log replies.
