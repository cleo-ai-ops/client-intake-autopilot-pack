# Career Proof Gap Checker

Score each proof surface from 0-2.

- Resume: target role is obvious; bullets show action + context + result.
- LinkedIn: headline/About explain who you help and what proof you have.
- Portfolio: at least one case study names constraints, decisions, and outcome.
- Follow-up: interview/recruiter messages are specific to the conversation.
- Public proof: talk proposal, writing sample, GitHub repo, or artifact shows judgment.

Prioritize the first surface scoring 0. Do not polish everything at once.
