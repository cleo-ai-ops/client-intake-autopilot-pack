# Boundary Reset Scripts

## When you already said yes too often
Hi [client],

I want to keep the project organized and avoid surprise delays. A few recent requests are beyond the original scope, so from here I’ll group additional items into small change orders before starting them.

For the current extras, I can either [finish already promised item] or bundle the remaining requests into a paid add-on.

## When the client says “just a quick tweak”
Totally understand. Quick tweaks still need review and QA, so I track them against scope. I can add it as a small change order or save it for the post-launch improvement list.
