# Change-Order Decision Checklist

Use this before replying to a new client request.

1. Is the request in the original written scope?
2. Does it change deliverables, timeline, platform, audience, or approval rounds?
3. Does it require new research, implementation, meetings, QA, or coordination?
4. Is there a dependency or risk the client needs to understand?
5. Can it wait until the current milestone is complete?
6. What is the smallest paid option you can offer?
7. What changes if they decline or defer it?

If two or more answers add time/risk, use a change order instead of doing it informally.
