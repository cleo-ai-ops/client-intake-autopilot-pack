# Change-Order Approval Form

Client:
Project:
Date:

## Requested change
[Describe the change in plain language.]

## Why it is outside current scope
[Deliverable/timeline/platform/rounds/complexity difference.]

## Fee and timeline
Fee: [amount]
Timeline impact: [days/date]
Payment terms: [before work / next invoice / milestone]

## Approval
Approved by: [name]
Approval method: [email/signature/payment]
Date approved:
