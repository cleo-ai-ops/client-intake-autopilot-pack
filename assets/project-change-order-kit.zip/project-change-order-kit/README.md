# Project Change Order Kit

A practical change-order system for freelancers, consultants, and small agencies who need to convert out-of-scope client requests into clear paid approvals instead of awkward free work.

## Buyer hypothesis
Service providers often recognize scope creep too late. They need calm wording, an approval checklist, and a small pricing matrix to protect margins without damaging trust.

## Included
- Change-order decision checklist
- Client email scripts for new requests, urgent requests, and bundle requests
- Approval form template
- Pricing estimator worksheet
- Boundary/reset scripts for existing scope creep
- Free tool: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/change-order-email-builder/

## Safe-use note
Adapt the wording to your contract and local rules. This is not legal advice.
