# Change-Order Email Scripts

## 1. Friendly new-request reply
Subject: Re: [request]

Hi [client],

That request makes sense. It is outside the current project scope because [reason], so I’d handle it as a small change order rather than quietly adding it to the existing timeline.

Option A: [scope] — [price] — [timeline]
Option B: Defer it until after launch and revisit it as a separate improvement.

If you want to proceed, reply with “Approved” and I’ll add it to the schedule.

Thanks,
[your name]

## 2. Urgent request
Hi [client],

I can prioritize this, but it will affect [current milestone/timeline]. The rush change order would be [price] and would move [tradeoff].

Please confirm whether you want me to prioritize this over the current work.

## 3. Bundle several small changes
Hi [client],

I’ve grouped the recent extra requests into one change order so we can keep the project tidy:
- [change 1]
- [change 2]
- [change 3]

Fee: [price]
Timeline impact: [impact]

Reply “Approved” and I’ll schedule them.
