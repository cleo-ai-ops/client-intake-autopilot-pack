# Web / Design / Development Change-Order Examples

Use these as concrete models when a client says “can we also…” during an active project.

## Example 1 — Extra landing page
**Original scope:** five-page marketing site.
**New request:** additional campaign landing page.
**Why it is a change order:** new layout, copy placement, responsive QA, analytics/event setup, and review cycle.

Suggested reply:
> That page makes sense for the campaign. Because it adds a new deliverable beyond the five scoped pages, I’d handle it as a small change order: one landing page using the existing design system, one revision round, and responsive QA. Fee: [amount]. Timeline impact: [X days].

## Example 2 — New integration after build starts
**Original scope:** brochure website with contact form.
**New request:** sync leads to HubSpot/Pipedrive/Airtable.
**Why it is a change order:** third-party setup, field mapping, test submissions, failure handling, and credentials coordination.

Approval scope:
- Connect [form] to [tool]
- Map fields: name, email, company, message, source
- Run 3 test submissions
- Document where failed submissions appear
- Excludes CRM cleanup, automation strategy, or duplicate handling unless added

## Example 3 — “Small” copy rewrite across pages
**Original scope:** implementation only; client supplied copy.
**New request:** rewrite headlines and service descriptions.
**Why it is a change order:** copywriting adds strategic decisions and approval cycles.

Suggested boundary:
> I can either place the supplied copy as planned, or quote a copy pass as a separate add-on. That keeps the implementation timeline clean and avoids mixing two scopes.

## Example 4 — Extra revision round
**Original scope:** two revision rounds.
**New request:** third round after approval.
**Why it is a change order:** additional coordination and rework after sign-off.

Suggested reply:
> We’ve used the included revision rounds, so I can handle this as an extra revision round at [amount]. If you prefer, we can save the items for a post-launch improvement batch.
