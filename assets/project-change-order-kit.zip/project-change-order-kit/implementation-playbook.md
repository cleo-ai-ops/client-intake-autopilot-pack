# Implementation Playbook

## 1. Put the rule in writing before you need it
Add a simple line to proposals and kickoff emails:

> Requests that change deliverables, timeline, platforms, integrations, approval rounds, or project assumptions will be quoted as change orders before work begins.

## 2. Pause before replying
Do not answer scope-changing requests in the same emotion as the client’s urgency. Use this 5-minute check:
- Is the request necessary for the original outcome?
- Is it caused by an error I made or by new client preference?
- Does it require new decisions, assets, meetings, QA, or deployment?
- Will saying yes delay another milestone?
- What is the smallest clear paid option?

## 3. Offer choices, not resistance
Good change-order replies give the client control:
- Approve the paid add-on now
- Defer it to a later improvement list
- Trade it against another scoped item, if appropriate

## 4. Keep approvals lightweight
For small changes, an email “Approved” can be enough if your contract allows it. For larger changes, use the approval form and invoice/deposit before starting.

## 5. Protect the relationship
Use neutral language. Avoid “you are asking for too much.” Say:
- “This changes the agreed deliverables.”
- “This adds a new QA pass.”
- “This affects the current milestone.”
- “I can quote it separately so the project stays tidy.”

## 6. Track every change
Maintain a small log so final invoices and timelines are easy to explain.
