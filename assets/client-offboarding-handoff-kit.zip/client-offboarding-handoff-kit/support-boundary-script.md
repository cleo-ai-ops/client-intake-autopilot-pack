# Support Boundary Script

Use this wording to reduce awkwardness after delivery.

## Included support
For the next [X days], I’ll answer questions and fix small issues directly related to the delivered scope.

## Not included
New features, content changes, third-party changes, platform migrations, and strategy requests are outside the delivery support window. I’m happy to quote those separately.

## Maintenance offer
If you want ongoing help, I can set up a monthly support option that covers [defined tasks]. That keeps small requests predictable and avoids one-off emergency work.
