# Client Handoff Checklist

## Before final delivery
- Confirm the final scope items are complete.
- Export/source all agreed files.
- List accounts, ownership, and access changes.
- Document recurring tools, renewal dates, and who owns payment.
- Prepare a short "how to use this" guide.
- Confirm outstanding invoices or payment milestones.

## Final delivery packet
- Final files or repository links.
- Login/access transfer notes.
- Key decisions and assumptions.
- Known limitations or future recommendations.
- Support window and what is/is not included.
- Maintenance option, if relevant.

## After delivery
- Ask for testimonial/referral while value is fresh.
- Schedule a check-in reminder for 30 days later.
- Archive the project folder and evidence.
