# Final Delivery Email Templates

## 1. Simple final handoff
Subject: Final handoff for [project]

Hi [client],

The final [project] files are ready here: [link].

I included:
- [deliverable 1]
- [deliverable 2]
- [access/instructions]
- [notes/recommendations]

The included support window covers small fixes/questions related to the delivered scope until [date]. New requests or additions can be scoped separately.

Thanks again — I enjoyed working on this.
[your name]

## 2. Handoff with maintenance offer
Subject: [project] delivered + next-step option

Hi [client],

The final handoff is ready here: [link]. I also added a short notes file with ownership/access details and recommended next steps.

If you want help keeping this updated, I can offer a lightweight monthly maintenance option covering [updates/checks/support]. The fee would be [price] per month and can start after the support window ends.

No pressure — the project is fully delivered either way.

Thanks,
[your name]

## 3. Boundary-friendly follow-up
Subject: Re: [request]

Hi [client],

Happy to help. This looks like a new request beyond the original handoff/support window, so I’d scope it separately before starting.

A good next step would be [small diagnostic / estimate / call].

Thanks,
[your name]
