# Referral & Testimonial Sequence

## Testimonial ask
Hi [client],

I’m glad we were able to complete [outcome]. Would you be open to sharing 2-3 sentences about what changed after the project and what the process felt like?

I’ll only publish it with your approval.

## Referral ask
Hi [client],

If you know another [type of business/person] dealing with [problem solved], I’d appreciate an introduction. The best fit is someone who needs [specific outcome].

No pressure — just asking while the project is fresh.

## 30-day check-in
Hi [client],

Checking in now that [project] has been live for about a month. Is anything unclear, broken, or worth improving next?

If everything is working well, I’d also be grateful for a short testimonial or referral.
