# Reproduction Checklist

1. Confirm environment: browser, device, account role, app version.
2. Capture the exact starting state.
3. Write the shortest step sequence.
4. Remove assumptions: permissions, feature flags, data state.
5. Try a clean session/incognito or test account.
6. Check logs around the reported timestamp.
7. Decide status: reproduced, likely reproduced, not reproduced, needs info.
8. Record evidence: screenshot, video, logs, request ID, commit/build.
9. Create the engineering ticket only after the failing condition is specific.
