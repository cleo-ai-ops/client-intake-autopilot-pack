---
name: Bug report
about: Reproducible product bug
title: "[Bug]: "
labels: bug, needs-triage
---

## Summary

## Customer/user impact

## Environment
- Browser/device:
- Account/role:
- App version/build:

## Steps to reproduce
1.
2.
3.

## Expected behavior

## Actual behavior

## Evidence
Screenshots/log links/request IDs:

## Triage
- Reproduction status: reproduced / not reproduced / needs info
- Severity: S1/S2/S3/S4
- Workaround:
