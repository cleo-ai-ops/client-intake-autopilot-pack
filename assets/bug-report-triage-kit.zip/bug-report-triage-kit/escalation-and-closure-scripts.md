# Escalation and Closure Scripts

## Escalate to engineering
Context: [customer/account/feature]
Impact: [who is blocked and how]
Repro status: [status]
Evidence: [links/log IDs]
Requested decision: [confirm cause / estimate risk / advise workaround]

## Escalate as incident
This may need incident handling because [data/security/outage/many users]. I recommend moving to the incident update path before sending fix promises.

## Close as insufficient info
Closing for now because we could not reproduce it and we are missing [detail]. If the customer provides [specific evidence], reopen with the original report attached.
