# Severity and Priority Matrix

## Severity
- S1 Critical: security/data loss/outage or core workflow blocked for many users.
- S2 High: important workflow broken, no reasonable workaround, limited blast radius.
- S3 Medium: workflow impaired, workaround exists, isolated users.
- S4 Low: cosmetic, copy, confusing edge case, enhancement-like bug.

## Priority
Priority combines severity, customer value, recurrence, and release risk.

| Severity | Default target | Notes |
|---|---:|---|
| S1 | Immediate | Start incident/update path |
| S2 | This sprint | Customer-facing status updates |
| S3 | Backlog/next sprint | Batch with related fixes |
| S4 | Backlog | Fix opportunistically |

Do not promise fix dates until engineering confirms cause and scope.
