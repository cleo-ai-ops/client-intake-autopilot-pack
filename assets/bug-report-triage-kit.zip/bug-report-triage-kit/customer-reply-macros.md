# Customer Reply Macros

## Ask for reproduction details
Hi [name],

Thanks for flagging this. I want to reproduce it accurately before guessing at the cause. Could you send:
- the exact steps you took,
- the page/feature affected,
- browser/device,
- any screenshot or error message,
- approximate time it happened?

Once I have that, I’ll check the logs and confirm the next step.

## Reproduced and logged
Hi [name],

I reproduced the issue and logged it for a fix. Current status: [status].

Impact: [impact]
Workaround, if useful: [workaround]

I’ll update you when there is a confirmed change or if I need more detail.

## Not reproduced yet
Hi [name],

I tested the steps and couldn’t reproduce it yet. That doesn’t mean the issue isn’t real — it means I need one more clue. Could you confirm [specific missing detail]?

## Closure
Hi [name],

This should now be resolved in [version/date]. Please try [step] when you have a moment. If it still happens, reply with a screenshot and I’ll reopen the ticket.
