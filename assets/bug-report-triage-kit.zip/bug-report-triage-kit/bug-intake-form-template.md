# Bug Intake Form Template

Use this when a customer or teammate reports a bug.

## Required
- What were you trying to do?
- What happened instead?
- What did you expect to happen?
- Exact page/feature affected
- Account/workspace ID if relevant
- Browser/device/app version
- Approximate time and timezone
- Screenshot/video/error message

## Optional but useful
- Does it happen every time?
- Steps already tried
- Impact: blocked, workaround available, cosmetic, confusion
- Affected users/accounts count
