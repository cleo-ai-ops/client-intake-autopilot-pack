# Bug Report Triage Kit

A lightweight system for solo SaaS founders, indie developers, and small product teams who receive vague bug reports and need to convert them into reproducible tickets, clear customer replies, and sane severity decisions.

## Buyer hypothesis
Small SaaS teams lose hours on ambiguous bug reports like "it doesn't work". They need a repeatable triage flow that asks the right questions, protects engineering time, and keeps customers informed.

## Included
- Bug intake form template
- Reproduction checklist
- Severity and priority matrix
- Customer reply macros
- GitHub issue template
- Triage log spreadsheet
- Escalation and closure scripts
- Free tool: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/bug-report-repro-checklist-generator/

## Safe-use note
Adapt severity names and SLA wording to your own product. This kit is operational guidance, not legal/SLA advice.
