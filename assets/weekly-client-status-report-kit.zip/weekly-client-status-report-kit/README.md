# Weekly Client Status Report Kit

A practical reporting pack for freelancers, consultants, agencies, fractional operators, and PMs who need to keep clients confident between meetings.

## Included
- Weekly client status email scripts
- Green/yellow/red project-health update templates
- Risk and blocker escalation notes
- Scope/budget/timeline variance language
- Client-facing status report Markdown template
- Internal prep checklist
- Before/after examples

Free generator: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/weekly-status-report-generator/
