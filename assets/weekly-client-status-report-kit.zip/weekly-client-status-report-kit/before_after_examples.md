# Before / After Examples

Before: "Things are moving. Waiting on some assets."

After: "Status is Yellow. Design work is ready, but implementation is waiting on final product images. If images arrive by Thursday, launch stays on track. If not, launch likely moves by 3 business days. Recommendation: approve placeholder images today and swap final assets later."
