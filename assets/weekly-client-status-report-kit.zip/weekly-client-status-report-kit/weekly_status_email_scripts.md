# Weekly Status Email Scripts

## Green week
Subject: Weekly status — [Project] on track

Hi [Name],

Quick weekly update for [Project].

Status: Green — on track.

Completed this week:
- [Outcome]
- [Outcome]

Next week:
- [Next step]
- [Next step]

Decisions / inputs needed:
- [Client decision, if any]

No major risks this week. I’ll flag anything that changes.

Best,
[You]

## Yellow week
Subject: Weekly status — [Project] needs one decision

Hi [Name],

Status: Yellow — moving, with one item that needs attention.

Progress:
- [Progress]

Risk/blocker:
- [Risk and impact]

Decision needed by [date]:
- [Decision]

Recommended path:
- [Recommendation]
