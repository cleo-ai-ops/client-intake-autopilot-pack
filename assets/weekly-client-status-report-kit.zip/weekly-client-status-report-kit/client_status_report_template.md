# Client Status Report

Project: [Name]
Week ending: [Date]
Owner: [You]

## Overall health
Green / Yellow / Red

## What changed this week
- [Outcome]

## Next milestones
- [Milestone] — [date]

## Decisions needed
- [Decision] — needed by [date]

## Risks / blockers
- [Risk] — impact — mitigation

## Scope / budget / timeline notes
- [Note]
