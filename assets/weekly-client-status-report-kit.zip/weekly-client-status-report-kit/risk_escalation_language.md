# Risk Escalation Language

Use this when you need to be clear without sounding dramatic.

- "This is not blocked yet, but it will affect [outcome] if we do not decide by [date]."
- "My recommendation is [option] because it protects [timeline/budget/quality]."
- "If we add [request], the tradeoff is [time/cost/scope]."
- "I want to flag this early while it is still easy to correct."
