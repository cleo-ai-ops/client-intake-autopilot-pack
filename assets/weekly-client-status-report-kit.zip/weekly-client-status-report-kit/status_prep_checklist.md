# Status Prep Checklist

- What got shipped, approved, or decided?
- What did not move and why?
- What does the client need to decide?
- Is timeline, scope, or budget changing?
- What is the honest project-health color?
- What should the client feel confident about?
