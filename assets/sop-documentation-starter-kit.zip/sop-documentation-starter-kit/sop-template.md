# SOP Template

Process name:
Owner:
Backup owner:
When this runs:
Outcome this process creates:

## Inputs
- Access / files / links needed

## Steps
1. Trigger the process when [condition].
2. Check [source of truth].
3. Do [action].
4. Record [evidence].
5. Notify [person/channel].

## Quality check
- What must be true before this is done?

## Edge cases
- If [problem], then [decision path].

## Rollback / recovery
- If this goes wrong, restore by [step].
