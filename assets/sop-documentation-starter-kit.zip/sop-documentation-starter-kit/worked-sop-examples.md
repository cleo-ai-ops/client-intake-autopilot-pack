# Worked SOP Examples

## Client onboarding SOP
Trigger: signed proposal and first payment received.
Outcome: client has access, kickoff booked, and project tracker created.
Steps: create project folder, send welcome email, request assets, create tracker, schedule kickoff, log handoff.
QA: client has next step, owner, deadline, and shared workspace link.

## Invoice follow-up SOP
Trigger: invoice 3 days overdue.
Outcome: polite reminder sent and payment tracker updated.
Steps: verify invoice status, check client context, send reminder, log next follow-up date, escalate at 14 days.

## Bug triage SOP
Trigger: customer reports product issue.
Outcome: reproducible ticket or polite clarification request.
Steps: capture environment, reproduce, classify severity, create issue, reply to customer, set follow-up date.

## Content publishing SOP
Trigger: draft approved.
Outcome: post is published and promoted.
Steps: final edit, metadata, publish, test links, schedule share, archive source.

## Monthly reporting SOP
Trigger: first workday of month.
Outcome: client receives concise performance report and next actions.
Steps: pull metrics, explain changes, list decisions, recommend next step, send report.
