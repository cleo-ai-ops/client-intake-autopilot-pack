# Delegation Handoff Script

Hi [Name],

I documented the [process] SOP here: [link].

The outcome is [outcome]. The process starts when [trigger]. The important quality check is [QA].

Please run it once using the SOP and leave comments where anything is unclear. If something breaks, use the rollback section and tag me with the step number.
