# Automation Readiness Checklist

A process is ready for automation only when:
- Inputs are structured or predictable.
- Exceptions are known.
- The human decision points are separated from mechanical steps.
- Success/failure can be observed.
- Credentials and permissions are explicit.
- There is a manual fallback.
