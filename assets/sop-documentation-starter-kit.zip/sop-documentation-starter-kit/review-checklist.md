# SOP Review Checklist

- The trigger is clear.
- The expected outcome is concrete.
- Each step has one action.
- Required inputs and access are listed.
- Edge cases are not hidden in someone's head.
- QA evidence is defined.
- A new teammate could run this without a meeting.
- Review date and owner are recorded.
