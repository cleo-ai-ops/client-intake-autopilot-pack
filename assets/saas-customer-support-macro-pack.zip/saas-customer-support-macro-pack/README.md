# SaaS Customer Support Macro Pack

A copy-paste support system for solo SaaS founders and tiny teams who need faster, calmer customer replies without hiring support.

## What's inside
- 54 ready-to-send support macros across billing, bugs, feature requests, refunds, onboarding, cancellations, angry customers, and outages
- Triage labels and priority rules for Gmail, HelpScout, Zendesk, Intercom, Linear, GitHub Issues, or plain email
- Refund/save/cancellation response scripts
- Bug report intake templates that produce developer-ready reproduction steps
- Customer tone guide so support stays human while moving fast
- AI prompt pack for adapting every macro to your product voice

## Buyer hypothesis
Solo SaaS founders, indie hackers, micro-SaaS teams, and bootstrapped founders who answer support themselves and lose time rewriting the same replies.

## Quick setup
1. Copy the macro library into your helpdesk or notes app.
2. Replace placeholders like `[product]`, `[plan]`, `[refund policy]`, and `[next step]`.
3. Add triage labels from `support-triage-system.csv`.
4. Use `bug-report-intake.md` whenever a report is vague.
5. Review the refund/cancellation scripts before your next save conversation.


## New premium operating docs
- `30-minute-setup-guide.md` — install the system quickly in a helpdesk or inbox.
- `tone-variants.md` — warm/direct/apology/boundary/save variants.
- `helpdesk-import-notes.md` — HelpScout, Zendesk, Intercom, and Gmail setup notes.
- `scenario-playbooks.md` — outage, billing dispute, enterprise lead, churn save, and bug escalation flows.

## Promise boundary
These macros speed up support and improve consistency. They are not legal advice and should be adapted to your refund policy, privacy obligations, and product facts.
