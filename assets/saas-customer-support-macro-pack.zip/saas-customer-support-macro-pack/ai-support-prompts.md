# AI Prompt Pack

## Rewrite a macro in our voice
Rewrite this customer support macro for a SaaS product called [product]. Voice: calm, concise, accountable, no corporate fluff. Keep it under 140 words. Macro: [paste].

## Turn an angry email into a calm reply
Draft a reply to this customer. Start with acknowledgement, avoid blame, state the next action and timeline, and do not promise anything we cannot do. Customer email: [paste].

## Extract bug details
From this customer message, extract reproduction steps, expected behavior, actual behavior, environment, severity, and missing questions. Message: [paste].
