# Refund and Cancellation Scripts

## Refund approved
Hi [name], thanks for giving [product] a try. I’ve approved the refund and you should see it from the payment processor within [timeline]. If you’re open to it, one sentence on what was missing would help us improve.

## Refund outside policy
Hi [name], I understand. I checked the purchase and it is outside our refund window, so I can’t issue a refund here. I can still help you get value from it — the fastest path is [specific help].

## Save conversation
Hi [name], sorry it hasn’t been useful enough yet. Before you cancel, the most common blocker is [blocker]. If you want, send me [detail] and I’ll point you to the quickest setup path. If you’d rather cancel, no pressure — here’s the link: [link].
