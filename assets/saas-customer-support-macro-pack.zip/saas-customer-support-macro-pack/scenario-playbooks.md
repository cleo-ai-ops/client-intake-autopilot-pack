# SaaS support scenario playbooks

## 1. Outage report
Acknowledge impact, confirm investigation, link status page if available, avoid guessing ETA, update every 30-60 minutes, and send resolution summary.

## 2. Billing dispute
Verify plan, invoice, payment date, and policy. Offer clear options: refund if eligible, credit if appropriate, or explanation with cancellation path.

## 3. Enterprise lead in support inbox
Answer the immediate question, then route to sales/founder with account size, use case, timeline, and requested procurement/security docs.

## 4. Churn save conversation
Ask the primary reason, classify as price/fit/missing feature/support issue, offer one concrete fix, and make cancellation easy if they still want it.

## 5. Bug escalation
Collect reproduction steps, account ID, browser/device, expected vs actual behavior, severity, and workaround. Create engineering ticket with evidence, not emotion.
