# SaaS Customer Support Macro Library

Use these as starting points. Keep the first sentence human, then move the customer to the next useful step.

## Billing and invoices

### Invoice request
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: invoice request].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Card failed
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: card failed].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Plan downgrade
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: plan downgrade].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Tax/VAT question
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: tax/vat question].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Duplicate charge
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: duplicate charge].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Payment succeeded but access missing
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: payment succeeded but access missing].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Annual plan question
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: annual plan question].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

## Bugs and technical issues

### Bug acknowledged
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: bug acknowledged].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Need reproduction steps
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: need reproduction steps].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Known bug workaround
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: known bug workaround].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Bug fixed follow-up
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: bug fixed follow-up].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Browser/cache issue
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: browser/cache issue].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Integration broken
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: integration broken].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Data import issue
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: data import issue].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Mobile display issue
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: mobile display issue].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

## Onboarding and activation

### Welcome after signup
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: welcome after signup].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Trial nudge day 2
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: trial nudge day 2].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Trial ending soon
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: trial ending soon].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Setup blocked
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: setup blocked].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Invite teammate
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: invite teammate].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Migration help
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: migration help].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### First success celebration
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: first success celebration].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

## Cancellations and refunds

### Cancellation acknowledged
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: cancellation acknowledged].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Save offer
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: save offer].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Refund approved
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: refund approved].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Refund declined politely
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: refund declined politely].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Pause instead of cancel
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: pause instead of cancel].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Feedback request after cancel
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: feedback request after cancel].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

## Feature requests

### Feature request captured
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: feature request captured].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Existing workaround
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: existing workaround].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Roadmap no-promise reply
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: roadmap no-promise reply].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Beta invite
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: beta invite].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Not a fit response
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: not a fit response].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Vote logged
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: vote logged].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

## Angry or urgent customers

### Angry customer de-escalation
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: angry customer de-escalation].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Service outage acknowledgement
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: service outage acknowledgement].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### SLA expectation reset
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: sla expectation reset].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Escalation to founder
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: escalation to founder].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Compensation without overpromising
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: compensation without overpromising].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Post-incident follow-up
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: post-incident follow-up].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

## Sales/support crossover

### Pre-sale question
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: pre-sale question].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Enterprise not supported
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: enterprise not supported].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Security questionnaire lightweight reply
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: security questionnaire lightweight reply].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Data export question
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: data export question].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Competitor comparison
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: competitor comparison].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Custom feature boundary
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: custom feature boundary].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

## Account and access

### Password reset guidance
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: password reset guidance].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Email change
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: email change].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Workspace ownership transfer
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: workspace ownership transfer].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Delete account confirmation
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: delete account confirmation].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### GDPR/data deletion
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: gdpr/data deletion].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

### Login magic link issue
Hi [name],

Thanks for reaching out — I can help with this. [One-sentence acknowledgement specific to: login magic link issue].

Here’s the fastest next step: [clear action / link / expected timeline].

If anything still looks off after that, reply with [specific detail needed] and I’ll take another look.

— [your name]

