# Tone variants

Use the same operational answer with a different emotional wrapper.

## Warm
“Thanks for explaining what happened — I can see why that would be frustrating. I’m going to help get this unstuck.”

## Direct
“I checked this and the next step is [action]. Please send [specific info] so we can resolve it.”

## Apology
“You’re right to flag this. We missed the mark here, and I’m sorry for the friction. Here’s what I can do now: [specific remedy].”

## Boundary-setting
“I want to be transparent: we can’t do [request], but we can offer [alternative] and make sure [next best outcome].”

## Save conversation
“I’d hate to lose you without understanding what failed. If you’re open to it, reply with the main reason and I’ll either fix it, offer a better path, or help you cancel cleanly.”
