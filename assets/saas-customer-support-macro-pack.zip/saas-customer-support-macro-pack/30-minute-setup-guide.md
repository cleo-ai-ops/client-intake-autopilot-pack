# 30-minute setup guide

## 0-5 minutes: choose labels
Import or copy labels from `support-triage-system.csv`: Billing, Bug, Feature, Onboarding, Cancellation, Outage, Account, Security.

## 5-15 minutes: install core macros
Copy the top 10 macros you answer weekly into your helpdesk. Replace `[product]`, `[plan]`, `[policy]`, and `[next step]`.

## 15-25 minutes: add routing rules
- Billing/refunds → founder or support owner
- Bugs with reproduction steps → engineering queue
- Outage/security/payment access → urgent channel
- Feature requests → product feedback list

## 25-30 minutes: test with five old tickets
Paste five real historical messages, pick a macro, personalize first sentence, and check that the response would have saved time without sounding robotic.
