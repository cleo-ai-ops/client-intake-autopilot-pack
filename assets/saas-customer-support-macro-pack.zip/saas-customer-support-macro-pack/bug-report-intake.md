# Bug Report Intake Template

Ask for exactly this when a report is too vague:

1. What were you trying to do?
2. What happened instead?
3. What did you expect to happen?
4. URL/screen where it happened:
5. Browser/device:
6. Screenshot or screen recording if possible:
7. Can we access the affected workspace/account?

## Developer-ready bug summary
- Impact:
- Reproduction steps:
- Expected:
- Actual:
- Workaround:
- Priority: P0 / P1 / P2 / P3
