# Helpdesk import notes

## HelpScout
Create folders by category, then paste each macro as a Saved Reply. Use tags matching `support-triage-system.csv`.

## Zendesk
Use Admin Center → Workspaces → Macros. Convert placeholders like `[product]` into Zendesk placeholders only after testing.

## Intercom
Use Inbox → Settings → Saved replies. Keep macros short; add internal notes for refund/security escalation.

## Gmail/plain email
Store macros as templates or snippets. Prefix names with category: `Billing — failed payment`, `Bug — need repro`, `Cancellation — save attempt`.

## Quality rule
Do not send a macro unchanged when the customer is angry, blocked from paid access, or reporting data/security/payment issues. Personalize the first line and state the next action clearly.
