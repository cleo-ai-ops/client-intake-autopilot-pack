# Experience Bullet Rewrite Prompts

Weak: Responsible for dashboards.
Better: Built weekly KPI dashboard used by 6 team leads to spot onboarding drop-offs and prioritize fixes.

Weak: Worked on customer support.
Better: Rewrote support macros for billing and onboarding issues, reducing repeated manual replies and making escalation criteria clearer.

Rewrite rule: action + object + context + credible result or operational use.
