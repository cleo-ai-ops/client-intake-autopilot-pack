# LinkedIn Headline Formulas

1. [Role] helping [audience] with [specific outcome]
2. [Target role] | [domain proof] | [tool/industry keywords]
3. [Consultant/freelancer] for [audience] who need [pain solved]
4. [Transitioning from X to Y] with [relevant proof]

Avoid: guru, ninja, visionary, results-driven, passionate professional without proof.
