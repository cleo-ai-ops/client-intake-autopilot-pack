# Profile QA Checklist

- Headline says role/audience/outcome, not just adjectives.
- About section explains who you help and what proof supports it.
- First 220 characters work before the “see more” cut.
- Experience bullets include context and artifacts.
- Keywords are honest and connected to real work.
- Featured section points to proof, portfolio, writing, or products.
- Contact/action path is clear.
