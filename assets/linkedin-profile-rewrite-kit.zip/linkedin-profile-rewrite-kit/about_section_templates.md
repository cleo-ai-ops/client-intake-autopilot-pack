# About Section Templates

## Job seeker
I am a [role] focused on [domain/problem]. Recently, I have [specific proof]. I am strongest at [3 skills], especially when [context]. I am looking for [target roles] where I can help [audience/company] improve [outcome].

## Consultant
I help [audience] solve [specific business pain] through [service]. My work is useful when [trigger/context]. Recent proof includes [examples]. If you are dealing with [pain], I can help with [clear first step].
