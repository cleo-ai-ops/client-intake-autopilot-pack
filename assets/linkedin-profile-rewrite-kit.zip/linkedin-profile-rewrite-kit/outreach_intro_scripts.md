# Outreach Intro Scripts

## Recruiter reply
Thanks for reaching out. The best match for me is [role/context], especially where the team needs [strength]. Recent relevant work: [proof]. Happy to compare fit if that lines up.

## Client intro
Thanks for connecting. I help [audience] with [pain/outcome]. If [trigger] is on your roadmap, I can share a simple first-step checklist.
