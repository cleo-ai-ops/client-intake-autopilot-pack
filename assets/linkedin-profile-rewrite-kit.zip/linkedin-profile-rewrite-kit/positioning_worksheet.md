# Positioning Worksheet

- Target reader: recruiter / hiring manager / client / collaborator
- Target role or offer:
- Top 3 proof points:
- Domain keywords you can honestly support:
- Problems you solve:
- What makes your experience specific:
- What you should stop saying because it is too vague:
