# Before/After Examples

Before: Passionate marketer helping brands grow.
After: B2B content marketer helping early SaaS teams turn customer interviews into sales pages, onboarding emails, and launch campaigns.

Before: Software engineer interested in AI.
After: Backend engineer building AI-assisted internal tools with Python, Postgres, queues, and evaluation workflows.
