# LinkedIn Profile Rewrite Kit

A focused kit for job seekers, consultants, and founders who need a clearer LinkedIn profile without sounding like generic AI copy.

## Included
- Positioning worksheet
- Headline formulas by goal
- About-section rewrite templates
- Experience bullet rewrite prompts
- Recruiter/client proof checklist
- Before/after examples
- Profile QA checklist
- Outreach intro scripts

Free tool: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/linkedin-headline-generator/
