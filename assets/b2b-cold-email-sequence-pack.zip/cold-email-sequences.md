# B2B Cold Email Sequence Pack

## 7 Proven Cold Email Sequences for B2B Sales

Each sequence includes 3–5 emails with subject lines, body copy, and timing rules. Customize the brackets with your details and send.

---

## Sequence 1: The Problem-Agitate-Solve (PAS) Sequence
**Best for:** Selling a solution to a known pain point
**Target:** Decision-makers at mid-market companies

### Email 1 — Identify the Pain (Day 1)
**Subject:** [First Name], quick question about [their pain point]

Hi [First Name],

I noticed [Company] is [specific observation — e.g., "expanding into European markets" / "hiring 3 new sales reps" / "using HubSpot"].

Most [role/title] I talk to in that situation struggle with [specific pain point — e.g., "pipeline visibility across regions" / "onboarding reps fast enough" / "data silos between tools"].

Is that something you're dealing with right now?

[Your Name]
[Your Title], [Your Company]
[Link — your website or calendar]

---

### Email 2 — Agitate the Cost (Day 4)
**Subject:** The cost of [pain point] at [Company]

Hi [First Name],

Following up on my last note.

When [pain point] goes unaddressed, I typically see:
- [Cost 1 — e.g., "30% of reps miss quota in their first quarter"]
- [Cost 2 — e.g., "deals stall in the pipeline for 2+ extra weeks"]
- [Cost 3 — e.g., "managers spend 10+ hours/week on manual reporting"]

[Your Company] helps teams like [similar company] solve exactly this. Happy to share a quick case study if useful.

[Your Name]

---

### Email 3 — Show the Fix (Day 8)
**Subject:** How [similar company] fixed [pain point]

Hi [First Name],

[Similar Company] had the same challenge. After implementing [your solution]:
- [Result 1 — e.g., "Reduced onboarding time from 6 weeks to 2"]
- [Result 2 — e.g., "Increased pipeline velocity by 40%"]

Here's a 2-minute overview: [link to case study or demo video]

Would a 15-minute call this week make sense to see if this fits your situation?

[Your Name]

---

### Email 4 — Low-friction CTA (Day 12)
**Subject:** One last thing, [First Name]

Hi [First Name],

I don't want to clutter your inbox. Last note:

If [pain point] is still on your radar, I'd be happy to send over a short breakdown of how we'd approach it at [Company] — no call needed.

Just reply "yes" and I'll send it over.

[Your Name]

---

## Sequence 2: The Referral Warm-In
**Best for:** When you have a mutual connection or shared context
**Target:** Anyone referred by a mutual contact

### Email 1 — Name Drop (Day 1)
**Subject:** [Mutual Contact] suggested I reach out

Hi [First Name],

[Mutual Contact] mentioned you might be dealing with [specific challenge].

I help [target audience] with [your solution]. [Mutual Contact] thought it could be relevant for [Company].

Would you be open to a quick 10-minute chat this week?

[Your Name]

---

### Email 2 — Value First (Day 5)
**Subject:** Something for you, [First Name]

Hi [First Name],

I know you're busy, so instead of another meeting pitch, here's a [resource type — e.g., "spreadsheet template" / "benchmark report" / "checklist"] that [Mutual Contact] also found useful: [link]

No strings attached. If it sparks any questions, I'm here.

[Your Name]

---

### Email 3 — Soft Close (Day 10)
**Subject:** Worth exploring?

Hi [First Name],

Just checking — is [challenge area] still a priority for you this quarter?

If so, I can put together a custom 1-pager on how [your solution] would work for [Company]. Takes me 10 minutes, no commitment from your end.

[Your Name]

---

## Sequence 3: The Competitor Switch
**Best for:** When you know the prospect uses a competitor
**Target:** Users of [Competitor Product]

### Email 1 — Plant the Seed (Day 1)
**Subject:** Switching from [Competitor]?

Hi [First Name],

I saw [Company] is using [Competitor Product]. 

A few teams who switched from [Competitor] to [Your Product] told us:
- [Advantage 1 — e.g., "They were paying for features nobody used"]
- [Advantage 2 — e.g., "Setup took 3 months instead of 3 days"]

Not saying it's the same for you — but worth a look?

[Your Name]

---

### Email 2 — Side-by-Side (Day 5)
**Subject:** [Your Product] vs [Competitor]: what's different

Hi [First Name],

Here's a quick comparison of where [Your Product] differs from [Competitor]:

| Feature | [Competitor] | [Your Product] |
|---------|-------------|----------------|
| [Feature 1] | [Competitor status] | [Your advantage] |
| [Feature 2] | [Competitor status] | [Your advantage] |
| Pricing | [Competitor pricing model] | [Your pricing model] |

Full breakdown here: [link]

Curious if any of these gaps are relevant to [Company].

[Your Name]

---

### Email 3 — Migration Offer (Day 9)
**Subject:** Easy migration from [Competitor]

Hi [First Name],

One thing that holds teams back from switching is migration headache.

We've built a dedicated migration tool for [Competitor] users. Average switch time: [X hours/days].

If you're curious, I can run a free migration assessment — I'll tell you exactly what it would take, and you decide.

[Your Name]

---

### Email 4 — Breakup (Day 14)
**Subject:** Closing the loop

Hi [First Name],

I'll assume [Competitor] is working well enough for now and won't follow up again.

If things change or you'd like to explore alternatives later, my calendar is always open: [calendar link]

Best of luck with [something relevant to their company].

[Your Name]

---

## Sequence 4: The Content-Led Nurture
**Best for:** After a prospect downloads content or visits your site
**Target:** Inbound leads, content downloaders

### Email 1 — Deliver + Context (Day 1)
**Subject:** Here's your [content title]

Hi [First Name],

Thanks for downloading [content title]. Here's the link again in case you need it: [link]

One thing I wanted to highlight: on page [X], we cover [specific insight]. Most [role] find that section the most actionable.

If you have questions about applying it at [Company], I'm happy to chat.

[Your Name]

---

### Email 2 — Related Insight (Day 4)
**Subject:** Related to [content topic]

Hi [First Name],

Building on [content title], here's a follow-up insight:

[Short insight — 2-3 sentences with a surprising data point or lesson]

[Your Company] helps teams implement this directly. Here's how [similar company] did it: [case study link]

[Your Name]

---

### Email 3 — Direct Offer (Day 8)
**Subject:** Ready to see it in action?

Hi [First Name],

You've seen the research. Would it help to see how [Your Product] actually works for a team like yours?

I can do a focused 15-minute walkthrough tailored to [Company]'s setup.

Pick a time here: [calendar link]

[Your Name]

---

### Email 4 — Value + Soft Ask (Day 14)
**Subject:** Quick win for [Company]

Hi [First Name],

Before I go — here's something actionable you can use right now, no tools needed:

[Quick tip or template]

If this is the kind of thing you'd want automated, that's exactly what [Your Product] does.

[Your Name]

---

## Sequence 5: The Event/Webinar Follow-Up
**Best for:** After a prospect attends or registers for an event
**Target:** Event attendees, webinar registrants

### Email 1 — Recap + Resources (Day 1)
**Subject:** Resources from [Event Name]

Hi [First Name],

Thanks for [attending / registering for] [Event Name].

Here are the resources we mentioned:
- [Resource 1 link]
- [Resource 2 link]
- [Slide deck link]

Any questions about the [specific topic] discussion? I'd be happy to dive deeper.

[Your Name]

---

### Email 2 — Missed You (Day 3) — for no-shows only
**Subject:** You missed [Event Name] — here's the recording

Hi [First Name],

We noticed you couldn't make it to [Event Name]. No worries — here's the recording: [link]

The [specific segment — e.g., "Q&A on pricing strategy"] starts at [timestamp].

Worth a catch-up call to discuss how this applies to [Company]?

[Your Name]

---

### Email 3 — Next Step Offer (Day 7)
**Subject:** What [similar company] did after [Event Name]

Hi [First Name],

After [Event Name], [similar company] reached out and we helped them [specific result].

If you're thinking about [topic] for [Company], I can put together a quick assessment. No pitch — just a practical look at where you stand.

Reply here and I'll send it over.

[Your Name]

---

## Sequence 6: The Re-Engagement
**Best for:** Reviving cold or stalled conversations
**Target:** Prospects who went dark after initial interest

### Email 1 — Check-In (Day 1)
**Subject:** Still thinking about [topic], [First Name]?

Hi [First Name],

We last talked about [topic/opportunity] back in [month]. Curious if that's still on your radar.

If priorities shifted, no worries at all — just wanted to check before I close the loop.

[Your Name]

---

### Email 2 — New Angle (Day 5)
**Subject:** Something new since we last spoke

Hi [First Name],

Since we last chatted, we've [launched a new feature / published new data / helped a company in their space].

Here's what's new: [brief description with link]

If anything changed on your end, I'd love to reconnect.

[Your Name]

---

### Email 3 — Breakup (Day 10)
**Subject:** Closing your file

Hi [First Name],

I don't want to keep following up if the timing isn't right. I'll close the loop for now.

If [topic] comes back up, you know where to find me: [calendar link] or just reply here.

Cheers,
[Your Name]

---

## Sequence 7: The Founder-to-Founder
**Best for:** Solo founders reaching out to other founders directly
**Target:** Startup founders, indie makers, small business owners

### Email 1 — Peer to Peer (Day 1)
**Subject:** Fellow founder here — [one thing you noticed about their company]

Hi [First Name],

I'm [Your Name], founder of [Your Company]. I've been following [Company] and really liked [specific thing — e.g., "your recent launch on Product Hunt" / "the way you handle onboarding"].

I built [Your Product] because I had the exact same problem: [specific pain point]. 

Not pitching — just curious if you've run into this too?

[Your Name]
Founder, [Your Company]

---

### Email 2 — Quick Win (Day 4)
**Subject:** Something that helped us

Hi [First Name],

When I was dealing with [pain point] at [Your Company], here's what actually worked:

[2-3 specific, actionable tips — not generic advice]

Feel free to steal any of these. If you want the playbook I put together (with templates), it's here: [link — free or paid resource]

[Your Name]

---

### Email 3 — Honest Offer (Day 8)
**Subject:** If you ever want to compare notes

Hi [First Name],

No pressure, but if you want to jump on a 15-minute call to trade notes on [topic], I'm game.

I learn a lot from these conversations too. Here's my calendar: [link]

[Your Name]

---

## Customization Checklist

Before sending any sequence, customize:
- [ ] All bracketed fields with real prospect data
- [ ] Subject lines to match your tone
- [ ] Pain points and results with your actual customer data
- [ ] Links to your real content and calendar
- [ ] Timing rules to match your sales cycle speed
- [ ] "Similar company" references to real customers (with permission)

## Timing Rules
- **Fast cycle** (SMB/transactional): Days 1, 3, 5, 8
- **Standard cycle** (mid-market): Days 1, 4, 8, 12
- **Slow cycle** (enterprise): Days 1, 7, 14, 21

## Compliance Notes
- Always include a clear unsubscribe option
- Honor opt-outs within 24 hours
- Check local regulations (CAN-SPAM, GDPR, etc.)
- Don't mislead with subject lines or sender information
- Keep accurate records of consent

---

*Built by Cleo — autonomous digital products for real business problems.*
