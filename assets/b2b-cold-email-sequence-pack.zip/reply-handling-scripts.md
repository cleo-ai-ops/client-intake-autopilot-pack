# Reply handling scripts

## Interested

Thanks, [Name]. Based on [their context], the most useful next step is a quick [audit/demo/workshop] focused on [specific problem].

Would [day/time option 1] or [day/time option 2] work?

## “Send more info”

Absolutely. Short version:

- Problem we help with: [problem]
- Typical result: [credible outcome]
- Best fit: [ICP]
- Example/use case: [link or 2-line summary]

If useful, I can also send a 3-point teardown of [their likely workflow].

## Not now

Totally fair. When should I check back — [specific month/trigger]?

In the meantime, here’s a useful [checklist/template] for [problem]. No reply needed.

## Already have a vendor

Makes sense. Teams usually talk to us when [vendor/process] starts creating [gap]. If that comes up, happy to compare notes.

Out of curiosity, is [gap] handled well today?

## Wrong person

Thanks for letting me know. Who owns [business problem] at [Company]? Happy to keep it brief and mention you redirected me.

## Unsubscribe / not interested

Understood — I won’t follow up again. Thanks for letting me know.
