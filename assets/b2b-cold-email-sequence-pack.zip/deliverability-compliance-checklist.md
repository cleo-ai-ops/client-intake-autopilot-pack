# Deliverability and compliance checklist

This is operational guidance, not legal advice. Check laws that apply to your country and recipient markets.

## Before sending

- [ ] Use a real business identity and valid reply-to address.
- [ ] Authenticate domain: SPF, DKIM, DMARC.
- [ ] Warm up a new domain/inbox gradually.
- [ ] Send to relevant business contacts only.
- [ ] Keep a suppression list for unsubscribes and bounces.
- [ ] Include a simple opt-out line.
- [ ] Avoid deceptive subject lines.
- [ ] Do not use scraped sensitive personal data.

## Copy rules

- Plain text beats image-heavy emails.
- One CTA per email.
- Keep first email under 120 words when possible.
- Mention why the recipient is relevant.
- Do not overclaim results.

## Stop rules

Stop emailing when:

- they unsubscribe
- they say no clearly
- you receive a hard bounce
- you complete the planned sequence with no engagement

## Risky phrases

Avoid spammy language like “guaranteed,” “risk-free,” “act now,” “limited offer,” or exaggerated income claims.
