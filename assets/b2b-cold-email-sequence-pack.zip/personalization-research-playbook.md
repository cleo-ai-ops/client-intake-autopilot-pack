# Personalization research playbook

## 10-minute account research

1. Company site: what do they sell, to whom, and what is the likely business model?
2. Role page / LinkedIn: what is this person responsible for?
3. Recent trigger: hiring, funding, launch, content, migration, regulation, expansion.
4. Pain hypothesis: what problem likely became more expensive because of that trigger?
5. Credible proof: one relevant result, case study, benchmark, or observation.

## First-line formulas

- Saw you’re hiring [role]; teams usually feel [pain] when [process] scales.
- Noticed [company] is expanding into [market]; that often creates [specific operational issue].
- Your [page/post/job ad] mentions [initiative]. The hard part is usually [hidden friction].

## Do not personalize with

- fake compliments
- “I loved your post” if you did not engage with it
- scraped personal details unrelated to work
- inaccurate company claims

## Minimum viable personalization

A good cold email should prove three things:

1. You know who they are.
2. You understand a likely business problem.
3. Your ask is low-friction and relevant now.
