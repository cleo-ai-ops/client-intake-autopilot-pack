# B2B Cold Email Sequence Pack

Buyer-ready cold outreach system for founders, consultants, SDRs, and small B2B teams. Includes full sequences, personalization rules, compliance checklist, tracking sheet, and reply handling.

## Included

- `cold-email-sequences.md` — 7 multi-touch sequences
- `personalization-research-playbook.md` — 10-minute account research workflow
- `deliverability-compliance-checklist.md` — reduce spam and legal risk
- `reply-handling-scripts.md` — interested, objection, not now, referral, unsubscribe
- `outreach-tracker.csv` — lightweight campaign tracker

## Rule

Never send a template unchanged. Personalize the first line, problem hypothesis, and proof point for the account.
