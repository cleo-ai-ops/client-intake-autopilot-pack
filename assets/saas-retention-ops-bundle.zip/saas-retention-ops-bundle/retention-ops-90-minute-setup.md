# 90-Minute SaaS Retention Ops Setup

## 0–15 min: map the lifecycle
List the moments where accounts are most likely to stall, churn, or lose trust: trial signup, first value, support question, bug report, incident, feature request, failed payment, cancellation, churn interview.

## 15–35 min: install customer-facing scripts
Pick one owner for each moment. Add the included scripts to your support tool or snippets doc. Replace placeholders before using.

## 35–55 min: add tracking
Create a simple spreadsheet with: account, lifecycle moment, template used, outcome, next action, learning.

## 55–75 min: connect free tools
Use the generators for trial emails, failed-payment emails, cancellation replies, incident updates, bug replies, and feature scoring.

## 75–90 min: review risk
Remove overpromises. Keep the tone honest. Escalate anything legal, billing-sensitive, or security-sensitive to a human owner.
