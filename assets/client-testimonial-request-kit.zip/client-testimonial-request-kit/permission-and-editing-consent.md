# Permission & Editing Consent

## Short permission line
Are you comfortable with me using your quote publicly on my website/proposals with your name and company?

## Anonymized option
If you prefer, I can publish it as “[role] at [industry/company size]” instead of using your name.

## Light editing line
I may lightly edit for grammar or length, but I’ll send the final version for approval before publishing.

## Final approval note
Here is the final version I’d like to use:

“[quote]”

Can you reply “approved” if this looks good?
