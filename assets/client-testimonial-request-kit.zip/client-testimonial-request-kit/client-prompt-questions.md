# Client Prompt Questions

Use 2-4 at a time, not all of them.

- What problem were you trying to solve before working with us?
- What made you choose us instead of another option?
- What changed after the project/product?
- Was there a measurable result, time saving, revenue lift, or stress reduction?
- What part of the process felt easiest?
- What would you tell someone considering hiring/buying from us?
- Who is this a good fit for?

Stronger testimonial shape:
Before: [pain]
Decision: [why you]
After: [specific result]
Trust: [what felt good about the process]
