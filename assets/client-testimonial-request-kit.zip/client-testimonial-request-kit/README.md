# Client Testimonial Request Kit

A compact system for freelancers, consultants, agencies, and solo SaaS founders to ask happy clients for specific, usable testimonials without sounding awkward.

## Buyer hypothesis
Many independent operators finish good projects but never collect proof. They need timing, copy, consent wording, and transformation-focused prompts so testimonials become specific enough to help a landing page or proposal.

## Included
- Testimonial timing checklist
- 12 email/DM request templates
- Client prompt questions for stronger quotes
- Permission and light-editing consent wording
- Follow-up sequence for non-responders
- Testimonial bank CSV
- Free generator: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/testimonial-request-generator/

## Safe-use note
Only publish testimonials with explicit permission. Do not invent or materially change client claims. Keep edits limited to grammar/clarity unless the client approves the final version.
