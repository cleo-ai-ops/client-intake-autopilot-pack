# Testimonial Request Templates

## 1. Simple post-project ask
Subject: Quick testimonial request

Hi [name],

I’m glad we were able to [specific outcome]. Would you be open to sharing 2-3 sentences I can use as a testimonial?

A useful quote could mention:
- what problem you had before,
- what changed after the project, and
- what it was like working together.

If helpful, I can draft a short version for your approval.

Thanks,
[your name]

## 2. Draft-for-approval ask
Subject: Can I quote this?

Hi [name],

Based on your feedback about [result], I drafted this short testimonial:

“[draft quote]”

Would you be comfortable with me using this on my site/proposals? I’m happy to edit or not use it if it doesn’t feel right.

Thanks,
[your name]

## 3. SaaS customer ask
Subject: Could we feature your result?

Hi [name],

I noticed [account/company] has been using [product/feature] for [time period]. Would you be open to sharing a short quote about what it helped you do?

Three prompts if useful:
1. What were you trying to solve?
2. What changed after using it?
3. Who would you recommend it to?

Thanks,
[your name]

## 4. Follow-up
Subject: Re: quick testimonial request

Hi [name],

Just bumping this once in case it got buried. No pressure if now is not a good time. If easier, you can reply to just one prompt: what changed after [project/product]?

Thanks,
[your name]
