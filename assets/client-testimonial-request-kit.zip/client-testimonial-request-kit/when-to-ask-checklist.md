# When To Ask For Testimonials

Best moments:
- Right after measurable delivery or positive feedback.
- After a client renews, refers someone, or says thank you.
- When a support/customer success issue is resolved well.

Avoid asking when:
- The client is still waiting on open work.
- There is unresolved billing or scope tension.
- You cannot explain what kind of testimonial would help.

Request formula:
1. Name the outcome.
2. Make the ask small.
3. Offer prompts.
4. Ask permission to quote publicly.
5. Let them approve edited wording.
