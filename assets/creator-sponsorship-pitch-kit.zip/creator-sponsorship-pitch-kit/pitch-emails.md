# Sponsor Pitch Emails

## Short first pitch
Subject: Sponsorship idea for [creator/channel]

Hi [Name],

I run [channel/newsletter/podcast], where [audience] comes for [topic/outcome]. I noticed [brand/product] is relevant because [specific audience fit].

Would you be open to a small sponsorship test in [month]? I can offer [placement], reaching roughly [audience size/engagement], with a concise post-campaign recap.

If useful, I can send a one-page media kit and two placement options.

Best,
[Your name]

## Follow-up 1
Subject: Re: Sponsorship idea

Hi [Name], just checking whether a small [topic] audience sponsorship test is worth exploring. If now is not a fit, no problem — I can circle back later.

## Follow-up 2
Subject: Closing the loop

Hi [Name], I will close this out for now. If [brand] tests creator/newsletter partnerships later, I would be happy to share the audience details.
