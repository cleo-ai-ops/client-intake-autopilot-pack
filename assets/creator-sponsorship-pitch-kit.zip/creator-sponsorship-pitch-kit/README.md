# Creator Sponsorship Pitch Kit

A lightweight sponsorship outreach system for newsletter writers, podcasters, YouTubers, and niche creators who want to pitch sponsors without sounding vague or inflated.

## Buyer hypothesis
Small creators often have an audience but no clean sponsor pitch, rate rationale, or follow-up system. A practical pack saves them time when turning audience trust into sponsorship revenue.

## Included
- sponsor-fit checklist
- media-kit question sheet
- first sponsor pitch emails
- follow-up sequence
- objection replies
- rate-card worksheet
- outreach tracker CSV

Free calculator: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/sponsorship-rate-card-calculator/
