# Sponsor-Fit Checklist

Use this before pitching. Do not pitch brands that will be irrelevant or unsafe for your audience.

## Audience fit
- Who exactly reads/watches/listens?
- What do they buy for work/life?
- Which tools/products already show up in comments, replies, or community threads?

## Sponsor fit
- Product genuinely solves a problem for the audience.
- Clear landing page and offer.
- No obvious trust/safety mismatch.
- You can explain the relevance in one sentence.

## Offer fit
- One placement type to start.
- Clear deliverables.
- Clear dates.
- Simple reporting promise: clicks, views, replies, or qualitative feedback you can actually provide.
