# Sponsor Objection Replies

## “Your audience is too small”
Totally fair. The reason I thought it may still be useful is that the audience is narrow: [niche]. A small test could validate fit before larger spend.

## “Send your media kit”
Absolutely — attached/linked here: [media kit]. The most relevant parts are [audience] and [placement option].

## “What results can you guarantee?”
I do not want to overpromise. I can guarantee the agreed placement, timing, and a clear recap. Performance depends on audience/offer fit, so I recommend a small test first.

## “Too expensive”
Understood. I can either reduce scope to [smaller placement] or keep this rate for a future campaign when budget is available.
