# Partner Pitch Templates

## Newsletter ad-swap / mention swap
Subject: Small cross-promo idea for [Audience]

Hi [Name],

I liked your recent piece on [specific topic]. Our audiences seem adjacent: you help [their audience], and I help [your audience].

A simple collaboration idea: we each share one useful resource with our audience next week — no hard sell, just a short practical mention.

What I can offer: [specific asset/audience/context].
What your audience gets: [clear benefit].

If useful, I can send a 3-line blurb and UTM link for review.

Best,
[Name]

## Creator content collaboration
Subject: Collaboration idea: [specific outcome]

Hi [Name],

Your [video/post/newsletter] about [specific detail] made me think there is a useful joint angle: [collab idea].

I can handle [your part]. You would only need to [small ask]. The audience takeaway would be [takeaway].

Open to a short outline?
