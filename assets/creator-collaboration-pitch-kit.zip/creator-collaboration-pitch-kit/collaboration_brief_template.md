# Collaboration Brief Template

**Partner:**
**Shared audience:**
**Collaboration type:**
**Goal:**
**Deliverables:**
**Copy/assets needed:**
**Timeline:**
**Approval process:**
**Tracking links / UTM:**
**Success measure:**
**Follow-up date:**
