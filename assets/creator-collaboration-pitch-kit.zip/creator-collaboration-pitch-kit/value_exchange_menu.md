# Value-Exchange Menu

Use this to avoid vague asks. Pick one primary exchange.

- Newsletter mention swap
- Podcast/interview swap
- Joint checklist or template
- Guest post or expert quote exchange
- Webinar/live workshop
- Community AMA
- Bundle/freebie exchange
- Case study collaboration

For each offer, define: audience, deliverable, deadline, approval step, CTA, and tracking link.
