# Creator Collaboration Pitch Kit

A compact outreach system for creators, newsletter writers, podcasters, YouTubers, community builders, and indie founders who want useful cross-promotions without awkward “let’s collab” messages.

## Buyer situation
You have an audience or useful asset, but you need to find good-fit partners, pitch a clear exchange, define deliverables, and follow up without sounding vague.

## Included
- Collaboration fit scoring worksheet
- Partner outreach pitch templates
- Value-exchange menu and deliverable checklist
- Follow-up scripts
- Collaboration brief template
- Outreach tracker CSV

Free tool: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/creator-collab-pitch-generator/
