# Collaboration Fit Scoring Worksheet

Score each potential partner before outreach. Pitch only if the total is 15+.

| Factor | Score 0-3 | Notes |
|---|---:|---|
| Audience overlap without being a direct competitor | | |
| Similar audience size or clear asymmetric value | | |
| Their content quality matches your standards | | |
| You can name a specific win for their audience | | |
| The collaboration can be delivered in under 2 weeks | | |
| You have a measurable CTA or next step | | |

Decision: Pitch / Nurture / Skip.
