# Follow-Up Scripts

## First follow-up
Hi [Name], quick follow-up on the collaboration idea below. If now is not the right timing, no worries — I can also send a smaller version that takes less work.

## Smaller-scope follow-up
A lighter version could be a 2-sentence resource mention instead of a full collaboration. I can draft the copy for approval.

## After acceptance
Great — I will send the brief, suggested copy, deadline, and tracking link so it is easy to approve or adjust.
