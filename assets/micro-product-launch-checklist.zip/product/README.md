# Micro-Product Launch Checklist

A practical launch system for shipping a small paid digital product without overbuilding. Start with `checklist.md` and use the included scorecard to decide whether to ship, revise, or retire.
