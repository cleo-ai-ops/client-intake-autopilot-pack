# Micro-Product Launch Checklist

Use this for guides, templates, checklists, spreadsheets, prompt packs, and small tools. The goal is a product that creates value in under 30 minutes.

## 1. Buyer and pain
- [ ] Buyer is specific: “freelance web designers,” not “creators.”
- [ ] Pain is urgent or repeated.
- [ ] Buyer already spends time/money solving it.
- [ ] Product promises a concrete job, not vague improvement.

### One-sentence offer
For [buyer] who need [outcome], this [format] helps them [job] without [pain].

## 2. Asset quality
- [ ] Includes a Start Here file.
- [ ] Includes examples or filled samples, not only blanks.
- [ ] Includes decision rules: when to use, skip, escalate, or change path.
- [ ] Includes setup steps for the likely tool/workflow.
- [ ] Can deliver first value in under 30 minutes.
- [ ] ZIP opens and files have clear names.

## 3. Not-generic test
If a buyer pasted the product title into ChatGPT, what would your product include that the generic answer would miss?
- real scenarios
- formulas/templates/workflows
- pitfalls and edge cases
- opinionated thresholds
- examples from actual use
- copy-paste assets that save time immediately

## 4. Landing page minimum
- [ ] Clear headline with buyer + outcome.
- [ ] 3–5 bullets describing exact files/assets.
- [ ] Screenshot or sample excerpt.
- [ ] Honest “who this is for / not for.”
- [ ] Price matches checkout.
- [ ] Download path tested.

## 5. Pricing sanity
- €5–€9: single checklist/template, narrow problem.
- €10–€19: multiple templates/examples, immediate business use.
- €20–€49: bundle/system with workflows, spreadsheets, scripts.

Do not charge for a thin outline. Charge when the buyer saves time or avoids a costly mistake.

## 6. Pre-launch QA
- [ ] Spellcheck filenames and headings.
- [ ] Open every file from the ZIP, not just source folder.
- [ ] Test CSV in Google Sheets/Excel.
- [ ] Test JSON/YAML imports where relevant.
- [ ] Confirm checkout download points to latest ZIP.
- [ ] Remove claims you cannot prove.

## 7. Launch sequence
Day 1: publish landing page and checkout.
Day 2: post one useful free excerpt.
Day 3: share a before/after or example.
Day 4: ask one community for feedback if allowed.
Day 5: improve product based on objections.
Day 6: publish a comparison/decision guide.
Day 7: review visits, checkout clicks, sales, refunds, questions.

## Ship / Hold / Retire scorecard
Score each 0–2.
- Buyer clarity
- Pain urgency
- Asset usefulness
- Specificity / non-generic value
- Setup clarity
- Checkout/download correctness
- Landing page honesty

12–14: Ship. 8–11: Hold and improve. 0–7: Retire or rebuild from scratch.

## Post-launch review
After 7 days, write:
- What promise got clicks?
- What questions or objections appeared?
- What file did buyers likely use first?
- What should be added, removed, or bundled?
