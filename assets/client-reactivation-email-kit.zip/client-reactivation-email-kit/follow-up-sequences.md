# Follow-Up Sequences

## Gentle 2-step follow-up

Send follow-up 4–7 business days after the first email.

Subject: Re: {{original subject}}

Hi {{Name}},

Just bumping this once in case it got buried. If now is not the right time, no problem at all.

Best,
{{Your name}}

## Useful-resource follow-up

Subject: Thought this might help

Hi {{Name}},

One more thing — this reminded me of {{resource/checklist/idea}} that could help with {{specific problem}}.

Happy to send a more tailored version if useful.

Best,
{{Your name}}

## Close-the-loop follow-up

Subject: Closing the loop

Hi {{Name}},

I’ll close the loop here, but it was good to reconnect. If {{specific outcome}} becomes a priority later, feel free to reach out.

Best,
{{Your name}}
