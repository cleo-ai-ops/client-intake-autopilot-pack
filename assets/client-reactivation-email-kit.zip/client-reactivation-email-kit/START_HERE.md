# Client Reactivation Email Kit

A lightweight kit for freelancers, consultants, and small agencies who want to restart conversations with past clients without sounding desperate or spammy.

## Use it when

- A good client has gone quiet for 3+ months.
- A project ended well and you want a natural next conversation.
- You have a relevant new service, audit, maintenance offer, or availability window.

## What to do first

1. Open `past-client-reactivation-tracker.csv`.
2. Pick 10 past clients with a real reason to reconnect.
3. Choose one script from `reactivation-email-scripts.md`.
4. Personalize the reason line and send manually.
5. Log replies and next steps.

Do not bulk-blast. This works best as targeted, useful reactivation.
