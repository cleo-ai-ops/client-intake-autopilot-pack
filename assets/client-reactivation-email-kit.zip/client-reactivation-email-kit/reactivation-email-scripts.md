# Reactivation Email Scripts

## 1. Quiet past client check-in

Subject: Quick check-in

Hi {{Name}},

I was looking back at the {{Project/Work}} we did together and thought of you. How are things going with {{specific area}} now?

If it would be useful, I can take a quick look and send over 2–3 practical suggestions. No pressure either way — just wanted to reconnect.

Best,
{{Your name}}

## 2. Relevant improvement idea

Subject: Idea for {{Company}}

Hi {{Name}},

I noticed {{specific observation}} and had a small idea that might help with {{business outcome}}.

Would it be useful if I wrote up the quick version? If it looks worth doing, we can talk about a small implementation sprint.

Best,
{{Your name}}

## 3. Availability window

Subject: Opening a small client slot

Hi {{Name}},

I have room for one small project/audit in the next couple of weeks and thought of {{Company}} because {{specific reason}}.

If {{pain/outcome}} is still on your radar, I can send over a simple scope. If not, no worries — hope everything is going well.

Best,
{{Your name}}

## 4. Post-project follow-up

Subject: How did {{Project}} settle in?

Hi {{Name}},

Now that {{Project}} has had time to settle, I wanted to ask how it is working in practice. Anything annoying, unclear, or underused?

If you want, I can do a quick cleanup pass or suggest next improvements.

Best,
{{Your name}}

## 5. Referral-friendly reconnect

Subject: Good to reconnect

Hi {{Name}},

Hope you’re doing well. I’m doing more work around {{specialty/outcome}} now and remembered how much I enjoyed working with {{Company}}.

If you or someone in your network is dealing with {{specific problem}}, I’d be happy to point them in the right direction.

Best,
{{Your name}}
