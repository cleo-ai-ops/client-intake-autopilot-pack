# Personalization Prompts

Use these to avoid generic reactivation emails.

- What did we help this client improve last time?
- What changed in their business since then?
- What result would matter to them this quarter?
- What specific page, workflow, offer, campaign, or system can I reference?
- Can I offer a useful observation before asking for a call?

## Bad reason lines

- “Just checking in.”
- “Do you need anything?”
- “I have availability.”

## Better reason lines

- “I noticed your pricing page changed and had one conversion idea.”
- “Your new product launch made me think of a small onboarding improvement.”
- “The workflow we built last quarter may be ready for a cleanup pass.”
