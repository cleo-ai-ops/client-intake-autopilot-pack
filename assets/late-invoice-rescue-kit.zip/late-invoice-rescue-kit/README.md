# Late Invoice Rescue Kit

A practical, polite overdue-invoice follow-up system for freelancers, consultants, and small agencies.

## Buyer hypothesis
Freelancers and consultants often delay chasing overdue invoices because they do not want to sound aggressive. They need clear wording, escalation timing, and a lightweight tracker so they can recover cash without damaging client trust.

## What is inside
- 9 staged overdue invoice email templates from gentle check-in to final notice.
- SMS/DM nudges for clients who respond faster outside email.
- A copy-paste payment-plan offer for good clients with temporary cash-flow problems.
- A small CSV tracker for due dates, follow-up dates, amounts, and status.
- A decision tree: when to pause work, when to escalate, and when to write off or hand off.
- A free browser generator you can use first: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/late-invoice-email-generator/

## Safe-use notes
This is business copy, not legal advice. Keep records, follow your contract, and use a local professional for legal escalation. The templates are intentionally calm and evidence-based, not threatening.

## Quick start
1. Add invoice number, amount, due date, and payment link to the tracker.
2. Pick the template matching how late the invoice is.
3. Keep the first message short and assume good intent.
4. Move to firmer language only if there is no response.
5. Pause new work only after you have warned clearly and documented the timeline.
