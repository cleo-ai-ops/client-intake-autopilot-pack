# Late Invoice Decision Tree

## 0-2 days late
Assume admin delay. Send a short check-in. Do not threaten or over-explain.

## 3-7 days late
Ask for confirmation and a specific payment date. Resend invoice/payment details.

## 8-14 days late
Use firmer language. Ask for either payment or a concrete blocker. Avoid doing additional unbilled work.

## 15-21 days late
Warn that new work may pause. Keep the message calm and documented.

## 21+ days late
Pause work if your agreement allows it. Consider a payment plan if the relationship is worth preserving. If there is no response, escalate according to your contract and local rules.

## Red flags
- Repeated vague promises with no date.
- New work requests while old invoices remain unpaid.
- Requests to change invoice details after due date without explanation.
- A new stakeholder claims they never approved the work.

## Good-client exceptions
If a reliable client has a temporary issue, offer a short payment plan in writing. Keep it specific and dated.
