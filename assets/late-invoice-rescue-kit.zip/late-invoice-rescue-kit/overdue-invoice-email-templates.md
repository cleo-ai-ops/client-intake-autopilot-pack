# Overdue Invoice Email Templates

Replace bracketed fields before sending. Keep the invoice PDF/payment link attached.

## 1. Due-today reminder
Subject: Invoice [invoice number] due today

Hi [client name],

Quick reminder that invoice [invoice number] for [project/service] is due today.

Amount: [amount]
Payment link / details: [payment link]

Thanks,
[your name]

## 2. 2 days late — assume good intent
Subject: Quick check on invoice [invoice number]

Hi [client name],

I wanted to check whether invoice [invoice number] reached the right person. It was due on [due date] and I have not seen the payment come through yet.

Could you confirm it is queued, or let me know if anything is missing from my side?

Thanks,
[your name]

## 3. 7 days late — ask for a specific date
Subject: Payment date for invoice [invoice number]

Hi [client name],

Invoice [invoice number] for [amount] is now one week overdue. Could you confirm the payment date by [date]?

If the invoice needs to be resent or submitted somewhere else, send me the details and I will handle it today.

Thanks,
[your name]

## 4. 14 days late — firmer but calm
Subject: Overdue invoice [invoice number] — action needed

Hi [client name],

I am following up again on invoice [invoice number], due [due date]. It is now 14 days overdue.

Please either:
1. pay the invoice here: [payment link], or
2. reply with the exact payment date and any blockers.

I need to resolve this before scheduling additional work.

Thanks,
[your name]

## 5. 21+ days late — pause work notice
Subject: Work pause notice for overdue invoice [invoice number]

Hi [client name],

Invoice [invoice number] remains unpaid after my reminders on [dates]. Unless payment is received by [date], I will need to pause active work until the balance is cleared.

This is just to keep the project/account current. Once payment is received, I can resume the next agreed step.

Payment link/details: [payment link]

Thanks,
[your name]

## 6. Payment plan option
Subject: Payment plan option for invoice [invoice number]

Hi [client name],

If paying the full [amount] immediately is difficult, I can offer a simple payment plan:

- [amount 1] by [date 1]
- [amount 2] by [date 2]

Please reply by [date] to confirm whether that works.

Thanks,
[your name]

## 7. Accounts payable contact request
Subject: Correct AP contact for invoice [invoice number]

Hi [client name],

Could you send me the correct accounts payable contact or invoice portal for invoice [invoice number]? It is currently overdue, and I want to make sure I am following your process correctly.

Thanks,
[your name]

## 8. Final internal escalation notice
Subject: Final follow-up before escalation — invoice [invoice number]

Hi [client name],

I have followed up on invoice [invoice number] on [dates]. It remains unpaid and I have not received a confirmed payment date.

If payment is not received by [date], I will escalate this according to the terms in our agreement.

Payment details: [payment link]

Thanks,
[your name]

## 9. Friendly relationship-preserving close
Subject: Closing the loop on invoice [invoice number]

Hi [client name],

I value the work we have done together and would prefer to resolve this directly. Please send payment or a confirmed plan by [date] so we can close the loop cleanly.

Thanks,
[your name]
