# Prioritization Rubric

Score each from 1-5.

- Reach: how many target customers feel this?
- Evidence: how strong is the proof beyond one loud request?
- Revenue/retention: could this unlock sales, expansion, or churn reduction?
- Strategic fit: does this strengthen the product direction?
- Effort: how expensive/risky is it? Reverse this score in the total.

Suggested score: Reach + Evidence + Revenue + Strategic Fit - Effort.

Decision bands:
- 14+ investigate/build candidate
- 10-13 validate with more customers
- 6-9 park in backlog
- <=5 say no or ignore unless strategy changes
