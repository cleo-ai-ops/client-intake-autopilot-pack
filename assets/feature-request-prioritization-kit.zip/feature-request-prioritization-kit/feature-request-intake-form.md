# Feature Request Intake Form

## Request
- Customer/account:
- Requested feature:
- Problem they are trying to solve:
- Current workaround:
- How often does this happen?
- Revenue/plan/context:
- Evidence link: support ticket, call note, screenshot, quote

## Internal notes
- Existing related feature?
- Segment fit: ideal customer / edge case / custom ask
- Risk if ignored:
- Fastest validation step:
