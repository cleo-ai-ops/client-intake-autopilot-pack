# Weekly Feature Request Triage Agenda

1. Review new requests from support, sales, churn calls, and founder inbox.
2. Merge duplicates and attach evidence.
3. Score only requests with enough context.
4. Pick validation actions for high-score unknowns.
5. Update customers on requests with a decision.
6. Move one item to build candidate only if it has evidence and strategic fit.
