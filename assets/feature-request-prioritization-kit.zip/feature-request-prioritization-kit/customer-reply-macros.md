# Customer Reply Macros

## Acknowledge + capture
Thanks for the suggestion. To understand the underlying need, could you share what you are trying to accomplish and what you do today as a workaround?

## Not now
Thanks for explaining this. I am not adding it to the near-term roadmap because [reason]. I logged the request, and if I see the same pattern from more customers I will revisit it.

## Needs more evidence
This is useful context. Before prioritizing it, I need to confirm whether it affects more customers in the same segment. If you have examples of when this blocks your workflow, send them over.

## Committed / shipped
Good news — this is now available in [feature/version]. The original request was [request]. If you try it and it does not solve the workflow, reply with what is still missing.
