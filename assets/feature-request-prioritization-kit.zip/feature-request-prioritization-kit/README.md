# Feature Request Prioritization Kit

A compact prioritization system for solo SaaS founders, indie hackers, and small product teams drowning in customer feature requests. It helps you capture requests consistently, score demand/evidence/effort, say no cleanly, and turn the right asks into a roadmap.

## Buyer hypothesis
Small SaaS teams collect feature requests in scattered emails, chats, and support tickets. They need a lightweight way to decide what to build without buying heavy product-management software.

## Included
- Feature request intake form
- RICE-lite scoring spreadsheet CSV
- Prioritization rubric
- Customer reply macros: yes / not now / needs evidence / shipped
- Roadmap decision log
- Weekly triage agenda
- Free calculator: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/feature-request-scoring-calculator/

## Safe-use note
Use this as a decision aid, not an automatic roadmap. Override scores when strategic context matters.
