# Proposal Value Recap Template

Hi [Name],

The proposal is built around three outcomes:

1. [Outcome 1]
2. [Outcome 2]
3. [Outcome 3]

The first milestone is [milestone], so you can validate progress before committing deeper. The main things not included yet are [exclusions], which keeps the starting scope controlled.

The decision to make now is: do we start with [recommended option], adjust scope, or pause until [future date]?
