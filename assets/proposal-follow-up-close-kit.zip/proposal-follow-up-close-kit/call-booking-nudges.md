# Call Booking Nudges

## Low-pressure clarification call
Would a 15-minute call help clarify scope and timing before you decide? If yes, I can walk through the proposal and trim anything that is not essential.

## Stakeholder call
If another stakeholder needs context, I am happy to join a short call and answer questions directly.

## Decision call
If the proposal is close but not quite right, a short call may be faster than more email. I can bring a leaner option and a phased option.
