# Proposal Decision-Risk Diagnostic

Use this before sending a follow-up.

## If the buyer is quiet, ask which risk is most likely
- Price risk: they like the work but are unsure about budget.
- Timing risk: the project matters but is not urgent yet.
- Trust risk: they are unsure you can deliver the outcome.
- Stakeholder risk: someone else must approve.
- Scope risk: the proposal feels too broad or unclear.

## Matching move
- Price: offer a smaller first phase, not a random discount.
- Timing: ask whether to revisit at a specific date.
- Trust: send a relevant proof point or process detail.
- Stakeholder: offer a forwardable decision summary.
- Scope: recap the first milestone and what is intentionally excluded.
