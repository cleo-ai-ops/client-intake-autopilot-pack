# Objection Reply Scripts

## “It is too expensive”
Totally understood. Rather than cutting the same scope thin, I can suggest a smaller first phase focused on [highest-value outcome]. That would reduce the commitment while still creating a useful result.

## “We need to think about it”
Of course. What would be most useful for the decision: a simpler option, a forwardable summary, or a quick call to clarify risk and timeline?

## “Can you send examples?”
Yes — I can send a relevant example/process snapshot. The closest comparison is [example], where the main constraint was [constraint] and the first milestone was [milestone].

## “We are not ready yet”
Makes sense. Would it be helpful if I check back around [date], or should I wait until you reach out?
