# Proposal Follow-Up Sequences

## 2 days after proposal
Subject: Quick check on [project]

Hi [Name],

Just checking that the proposal came through clearly. The main decision point is whether [outcome] is still the priority for [timeframe].

If useful, I can also send a shorter option with the same first milestone and a smaller starting scope.

Best,
[Your name]

## 5 days after proposal
Subject: Should I adjust the [project] plan?

Hi [Name],

I wanted to follow up on the proposal for [project]. If the scope, timing, or budget needs adjusting, I can reshape the first phase around the most urgent outcome: [specific outcome].

Would you prefer I send a leaner first-step version, or should we keep the original plan as-is?

## 10 days after proposal
Subject: Keep this open?

Hi [Name],

I know priorities move quickly. Should I keep the [project] proposal open for this month, or is this better to revisit later?

If the blocker is internal approval, I can send a one-page summary you can forward.

## 21 days after proposal
Subject: Closing the loop on [project]

Hi [Name],

I am going to close the loop on this proposal for now so I do not keep nudging you. If [pain/outcome] becomes urgent again, I would be glad to revisit it with a fresh scope.

Thanks again for the conversation,
[Your name]
