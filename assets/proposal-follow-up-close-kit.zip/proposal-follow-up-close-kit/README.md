# Proposal Follow-Up & Close Kit

A practical close-the-loop kit for freelancers, consultants, and small agencies with sent proposals that have gone quiet.

## Included
- Proposal follow-up email sequences for 2, 5, 10, and 21 days after send
- Decision-risk diagnostic: price, timing, trust, missing stakeholder, unclear scope
- Objection reply scripts
- Scope/value recap template
- Proposal tracker CSV
- Call booking nudge scripts
- Polite close-lost message that preserves future opportunity

Free tool: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/proposal-follow-up-email-generator/
