# Polite Close-Lost Message

Hi [Name],

I am going to close this proposal on my side for now so I do not keep following up. I appreciated learning about [project/problem].

If this becomes a priority again, I would be glad to revisit it and adjust the scope to match the timing and budget at that point.

Wishing you well,
[Your name]
