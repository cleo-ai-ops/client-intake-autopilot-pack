# In-App / Banner Copy

## Soft banner
We could not complete your latest payment. Update billing to keep your account active. [Update billing]

## Modal copy
Your account is active, but payment needs attention. This usually takes under a minute if you have the right card available. [Update billing]

## Account page notice
Billing status: action required. Reason: [decline/expired/authentication]. Next retry: [date].
