# Support Replies

## Customer says they already paid
Thanks for flagging this. I will check the latest billing event now. Sometimes a bank authorization and a completed invoice look similar in the statement. I will confirm what happened and follow up.

## Customer is upset about access risk
I understand the frustration. The note is not meant as a threat — it is a heads-up so you have time to update billing before anything changes. Here is the secure billing link: [link].

## Customer wants to cancel instead
Understood. Before I close it out, is the main reason payment/admin friction, price, missing value, or something else? I can route you to the cleanest next step.
