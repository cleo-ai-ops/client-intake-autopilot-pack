# Payment Failed Recovery Map

1. Trigger: invoice payment failed, card expired, bank declined, or SCA/authentication needed.
2. Goal: help the customer update payment details before access is interrupted.
3. Tone: calm, specific, non-accusatory.
4. Sequence:
   - Day 0: helpful heads-up
   - Day 2: simple reminder and exact action
   - Day 5: access-risk reminder
   - Day 7: final notice before downgrade/pause
5. Track: account, failure reason, emails sent, support replies, recovered date, churn reason if unrecovered.
