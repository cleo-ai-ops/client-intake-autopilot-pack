# SaaS Payment Failed Recovery Kit

A practical retention kit for solo SaaS founders and small teams who need to handle failed-card events without sounding robotic or aggressive.

## Buyer hypothesis
Small SaaS teams often lose revenue to failed payments because the recovery emails are either too generic, too late, or too harsh. A calm sequence plus a simple tracking process can help them recover accounts while preserving trust.

## Included
- Failed-payment recovery map
- Day 0, Day 2, Day 5, and Day 7 email scripts
- In-app/banner copy
- Support replies for angry/confused customers
- Payment recovery tracker CSV
- Stripe/Billing-system implementation checklist
- Free generator: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/payment-failed-email-generator/

## Safe-use note
Use these templates with customers who already have a billing relationship with you. Keep normal unsubscribe/compliance requirements and avoid threatening language.
