# Failed Payment Email Sequence

## Day 0 — Helpful heads-up
Subject: Payment issue on your [product] account

Hi [name],

We could not complete the latest payment for [product]. This is often caused by an expired card, a bank decline, or an authentication step.

You can update payment details here: [billing link]

Your account is still active right now. If you have questions, just reply to this email.

## Day 2 — Reminder
Subject: Quick reminder: update payment details

Hi [name], quick reminder that the payment for [product] still needs attention.

Update billing here: [billing link]

If you are changing plans or need help, reply and I will help route it.

## Day 5 — Access-risk reminder
Subject: Action needed to keep [product] active

Hi [name],

We still could not complete payment for your [product] account. If nothing changes, access may be paused on [date].

Update payment details here: [billing link]

## Day 7 — Final pause notice
Subject: Your [product] account may be paused

Hi [name],

This is the final reminder before your [product] account is paused for unresolved payment.

You can keep the account active by updating payment details here: [billing link].

If this is not the right time to continue, reply and we can help with next steps.
