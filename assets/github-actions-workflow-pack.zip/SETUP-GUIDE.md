# GitHub Actions Workflow Pack - Setup Guide

## Quick Start

1. Copy the workflow file you need into your repo's `.github/workflows/` directory
2. Update environment variables and paths to match your project
3. Add required secrets to your GitHub repository settings
4. Push to trigger the workflow

## Setting Up Secrets

Go to your repository → Settings → Secrets and variables → Actions → New repository secret

### Common Secrets You'll Need

| Workflow | Secret | Description |
|----------|--------|-------------|
| Docker Build | `GITHUB_TOKEN` | Auto-provided by GitHub |
| Vercel Deploy | `VERCEL_TOKEN` | From Vercel dashboard |
| Vercel Deploy | `VERCEL_ORG_ID` | From Vercel project settings |
| Vercel Deploy | `VERCEL_PROJECT_ID` | From Vercel project settings |
| SSH Deploy | `SSH_PRIVATE_KEY` | Your server's SSH private key |
| SSH Deploy | `SSH_HOST` | Server IP or hostname |
| SSH Deploy | `SSH_USER` | SSH username |
| DB Backup | `DB_HOST` | Database hostname |
| DB Backup | `DB_PASSWORD` | Database password |
| DB Backup | `AWS_ACCESS_KEY_ID` | AWS credentials for S3 |
| Security | `GITHUB_TOKEN` | Auto-provided by GitHub |

## Customization Tips

### Node.js CI
- Add/remove versions from the matrix
- Add `npm run lint` step if you have linting configured
- Add Playwright/Cypress step for E2E tests

### Docker Build
- Change `REGISTRY` to `docker.io` for Docker Hub
- Add `DOCKERHUB_USERNAME` and `DOCKERHUB_TOKEN` secrets
- Modify platforms list if you don't need ARM64

### Vercel Deploy
- Add `VERCEL_TEAM_ID` if using a team account
- Remove preview deploy job if not needed

### SSH Deploy
- Update deploy scripts to match your server setup
- Add database migration step before deployment
- Add Slack/Discord notification after deploy

## Troubleshooting

### Workflows not triggering
- Ensure the YAML file is in `.github/workflows/`
- Check that the `on:` trigger matches your branch names
- Verify YAML syntax with a linter

### Permission errors
- Check that `permissions:` block grants necessary access
- Verify secrets are set correctly (no trailing whitespace)
- For packages, ensure `GITHUB_TOKEN` has `packages: write`

### Build failures
- Run the build command locally first
- Check that all dependencies are in `package.json`
- Verify Node.js/Python version compatibility
