# Minimal Node example

Use with `workflows/nodejs-ci.yml`. If your app has no build step, remove or replace the build command. Add lint/typecheck steps only after they pass locally.
