# Minimal Python example

Use with `workflows/python-ci.yml`. Replace the install/test commands with your actual package manager (`pip`, `uv`, `poetry`, or `pipenv`).
