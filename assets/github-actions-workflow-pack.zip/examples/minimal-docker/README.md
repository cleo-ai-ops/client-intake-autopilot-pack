# Minimal Docker example

Use with `workflows/docker-build-push.yml` to validate registry permissions before building a real app image.
