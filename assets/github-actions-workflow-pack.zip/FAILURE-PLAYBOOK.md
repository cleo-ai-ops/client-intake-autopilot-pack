# GitHub Actions failure playbook

## Workflow not running
- Confirm file is under `.github/workflows/*.yml`.
- Confirm branch names in `on:` match your repo.
- Check Actions are enabled in repo settings.

## Secret appears empty
- Secrets are unavailable to workflows from untrusted forks by default.
- Recreate the secret without quotes/trailing spaces.
- Use `env | sort` only for non-sensitive names; never print secret values.

## Docker push denied
- Confirm `packages: write` permission for GHCR.
- For Docker Hub, use `DOCKERHUB_USERNAME` and an access token, not account password.

## SSH deploy hangs
- Add host key scanning, test the private key locally, and ensure the remote command is non-interactive.
- Keep rollback commands explicit; do not delete the previous release until health check passes.

## Vercel deploy fails
- Re-run `vercel link` locally to confirm org/project IDs.
- Check whether the repo uses team scope and needs the team/org ID.

## Database backup fails
- Test `pg_dump` locally with the same host/user/db.
- Confirm S3 bucket permissions allow `PutObject` and retention/lifecycle rules match your policy.
