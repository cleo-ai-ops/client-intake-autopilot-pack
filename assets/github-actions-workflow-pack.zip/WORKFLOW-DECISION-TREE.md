# Workflow decision tree

## Start here
- JavaScript/TypeScript app → `workflows/nodejs-ci.yml`
- Python package/API → `workflows/python-ci.yml`
- Container image → `workflows/docker-build-push.yml`
- Vercel site/app → `workflows/vercel-deploy.yml`
- Static site to GitHub Pages → `workflows/static-site-deploy.yml`
- Server deploy over SSH → `workflows/ssh-deploy.yml`
- Scheduled PostgreSQL backup → `workflows/database-backup.yml`
- Release tags/changelog → `workflows/auto-release.yml`
- Dependency/security checks → `workflows/security-scan.yml`
- Multiple packages/apps → `workflows/monorepo-ci.yml`

## Safe rollout
1. Add workflow on a branch.
2. Keep required secrets empty until YAML validates.
3. Trigger on a test branch first.
4. Add branch protection only after the workflow passes twice.
