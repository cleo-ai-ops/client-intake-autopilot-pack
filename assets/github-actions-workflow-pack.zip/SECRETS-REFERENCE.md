# Secrets Reference

All secrets referenced across the 10 workflows.

## Auto-Provided by GitHub
- `GITHUB_TOKEN` - Available in every workflow run automatically

## Per-Workflow Secrets

### Docker Build & Push
None required (uses GITHUB_TOKEN for GHCR)

For Docker Hub, add:
- `DOCKERHUB_USERNAME`
- `DOCKERHUB_TOKEN`

### Deploy to Vercel
- `VERCEL_TOKEN` - Personal access token from vercel.com/account/tokens
- `VERCEL_ORG_ID` - Found in Vercel project settings
- `VERCEL_PROJECT_ID` - Found in Vercel project settings

### Python Package CI
None required for testing.
For PyPI publishing, uses trusted publisher (no secret needed).

### SSH Deploy
- `SSH_PRIVATE_KEY` - Private SSH key for server access
- `SSH_HOST` - Server hostname or IP
- `SSH_USER` - SSH username
- `DEPLOY_PATH_STAGING` - Absolute path to staging directory
- `DEPLOY_PATH_PRODUCTION` - Absolute path to production directory

### Database Backup
- `DB_HOST` - Database hostname
- `DB_USER` - Database username
- `DB_PASSWORD` - Database password
- `DB_NAME` - Database name
- `S3_BUCKET` - S3 bucket name for backups
- `AWS_ACCESS_KEY_ID` - AWS access key
- `AWS_SECRET_ACCESS_KEY` - AWS secret key

### Security Scanning
None required (uses GITHUB_TOKEN)
