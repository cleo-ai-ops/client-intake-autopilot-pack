# GitHub Actions Workflow Templates Pack

10 production-ready GitHub Actions workflows for modern CI/CD pipelines. Copy, customize, deploy.

## Included Workflows

### 1. Node.js CI Pipeline
Complete Node.js testing workflow with matrix builds, caching, and artifact upload.
- Multi-version Node.js testing (18, 20, 22)
- npm/yarn/pnpm support
- Test coverage reporting
- Build artifact caching

### 2. Docker Build & Push
Build, tag, and push Docker images to Docker Hub or GHCR.
- Multi-platform builds (amd64, arm64)
- Automatic tagging (branch, SHA, semantic version)
- GitHub Container Registry support
- Build layer caching

### 3. Deploy to Vercel
Automated Vercel deployments with preview URLs.
- Production deployment on main
- Preview deployments on PRs
- Comment PR with deployment URL
- Environment variable management

### 4. Python Package CI
Complete Python testing and publishing workflow.
- Multi-version Python testing (3.10, 3.11, 3.12)
- tox/nox integration
- PyPI publishing on release
- Linting with ruff/mypy

### 5. Static Site Deploy to GitHub Pages
Deploy any static site (Hugo, Next.js, Astro, plain HTML) to GitHub Pages.
- Custom domain support
- Automatic cache invalidation
- 404 page handling
- Deployment confirmation

### 6. Automated Release & Changelog
Create GitHub releases with auto-generated changelogs.
- Conventional commit parsing
- Automatic semantic versioning
- Changelog generation
- Release asset uploads

### 7. Security Scanning
Comprehensive security scanning workflow.
- Dependabot-style vulnerability scanning
- CodeQL analysis
- Secret detection
- License compliance checking

### 8. Staging + Production Deploy (SSH)
Deploy to your own servers via SSH.
- Staging deploy on develop branch
- Production deploy on main branch
- Zero-downtime deployment script
- Rollback capability

### 9. Database Backup
Automated database backup to cloud storage.
- PostgreSQL backup with pg_dump
- MySQL backup with mysqldump
- Upload to S3/GCS/Azure
- Retention policy (keep last 30 days)
- Backup verification

### 10. Monorepo Pipeline
Smart CI/CD for monorepos.
- Path-based change detection
- Only run workflows for changed packages
- Parallel job execution
- Shared cache management

## Each Workflow Includes
- Complete YAML file ready to copy into `.github/workflows/`
- Inline comments explaining each step
- Environment variable templates
- Required secrets list
- Customization guide

## Who This Is For
- Solo developers who want CI/CD without spending hours on config
- Teams standardizing their GitHub Actions workflows
- Anyone tired of copy-pasting from scattered blog posts
- DevOps engineers who want a starting point for custom pipelines

## Requirements
- GitHub account (free or paid)
- Basic familiarity with YAML
- Repository admin access (for secrets configuration)

## Format
- 10 YAML workflow files
- 1 setup guide (Markdown)
- 1 secrets reference (Markdown)
- 1 customization guide (Markdown)

## License
Personal use license. Use in unlimited personal and commercial projects.
