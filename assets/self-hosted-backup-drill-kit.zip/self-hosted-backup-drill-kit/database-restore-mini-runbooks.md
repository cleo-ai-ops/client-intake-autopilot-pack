# Database Restore Mini-Runbooks

## Postgres
1. Start a clean postgres container with a disposable volume.
2. Create the target database/user if needed.
3. Run `psql < backup.sql` or `pg_restore` depending on dump format.
4. Start app against the test database.
5. Verify record counts and one known workflow/login.

## MySQL / MariaDB
1. Start a disposable database container.
2. Import with `mysql database < backup.sql`.
3. Check character set warnings and failed statements.
4. Start app against test DB.

## SQLite
1. Copy database file to sandbox.
2. Run `sqlite3 file.db "pragma integrity_check;"`.
3. Start app read-only if possible first.

## File-only apps
1. Restore files to sandbox path.
2. Fix UID/GID ownership.
3. Mount sandbox path into app.
4. Check thumbnails, uploads, and newest files.
