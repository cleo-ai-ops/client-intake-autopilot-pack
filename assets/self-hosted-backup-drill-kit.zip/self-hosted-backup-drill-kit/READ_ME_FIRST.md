# Self-Hosted Backup Drill Kit

A practical restore-test system for homelab and small self-hosting operators. It helps you prove backups work before a disk dies, a volume gets corrupted, or a bad upgrade destroys data.

## Buyer hypothesis
Self-hosters often set up backups once, then never run a realistic restore drill. They need a short, repeatable checklist and evidence log that fits Docker Compose services, databases, and home-server files.

## What is inside
- A 45-minute restore drill plan for Docker Compose stacks.
- Pre-flight checklist: secrets, volume locations, database dumps, object/media storage, DNS and reverse proxy notes.
- App-specific mini-runbooks for Postgres, MySQL/MariaDB, SQLite, file shares, photo/media apps, and n8n-like workflow apps.
- CSV evidence log for every restore test.
- Failure triage sheet: what to fix when a restore fails.
- Free browser checklist generator: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/backup-drill-checklist-generator/

## Safety notes
Run drills in a sandbox path or spare VM/VPS when possible. Do not overwrite production volumes. This is an operations template, not a managed backup service.
