# Restore Failure Triage

## Missing secret
Fix: document where the secret is stored and add it to backup inventory. Do not put raw secrets in the inventory.

## Permission error
Fix: record expected UID/GID and test `chown` command in the runbook.

## Database import fails
Fix: capture exact database version and dump command. Test a fresh dump.

## Backup is stale
Fix: add monitoring or a simple cron heartbeat that writes last successful backup time.

## App starts but data is missing
Fix: find all volumes and external storage paths; update compose/runbook.
