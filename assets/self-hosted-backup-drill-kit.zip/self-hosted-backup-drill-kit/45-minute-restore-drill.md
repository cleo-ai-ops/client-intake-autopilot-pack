# 45-Minute Restore Drill

## Goal
Prove that one important service can be restored from backup into a safe test location.

## 0-5 min: choose the target
Pick one service with real value: password manager, photos, documents, n8n, CRM, notes, or finance tracker.

Record:
- service name
- compose file path
- volume paths
- database type
- latest backup location
- restore destination

## 5-15 min: pre-flight
- Confirm backup timestamp.
- Confirm encryption key / password is available.
- Copy backup to a sandbox path.
- Disable public ports or use localhost-only binding.
- Create a restore note before touching anything.

## 15-35 min: restore
- Restore files/volumes into sandbox path.
- Restore database dump if applicable.
- Start only the target service and dependencies.
- Login locally.
- Check 3 pieces of known data.

## 35-45 min: evidence and cleanup
- Screenshot or write proof of successful login/data access.
- Record commands and duration.
- Mark gaps: missing secrets, stale docs, corrupted dump, wrong permissions.
- Stop sandbox containers and remove test-only ports.
