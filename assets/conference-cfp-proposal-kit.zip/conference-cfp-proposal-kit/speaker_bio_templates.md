# Speaker Bio Templates

## Short bio
[Name] is a [role] working on [domain]. They have helped [audience/company/team] with [specific work] and care about making [topic] more practical for [audience].

## Credibility without bragging
Focus on relevant proof: shipped systems, supported teams, researched users, taught workshops, maintained projects, or lived the problem.
