# Reviewer-Friendly Outline Builder

- Opening problem: 2 minutes
- Context and audience promise: 2 minutes
- Main section 1: [concept/example]
- Main section 2: [tradeoff/demo]
- Main section 3: [framework/checklist]
- Recap: what attendees can do Monday
- Q&A seed: one useful question to invite

Reviewer signal: make scope obvious so the talk feels deliverable in the available time.
