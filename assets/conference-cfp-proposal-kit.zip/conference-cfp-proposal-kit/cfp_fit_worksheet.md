# CFP Fit Worksheet

Before drafting, answer:

- Event name and audience:
- Audience level: beginner / intermediate / advanced / mixed
- CFP theme or track:
- What attendees are trying to do better:
- Your real experience/proof:
- One useful takeaway attendees can use Monday:
- What this talk is NOT about:
- Why now?

A good proposal is audience-fit first, speaker-promotion second.
