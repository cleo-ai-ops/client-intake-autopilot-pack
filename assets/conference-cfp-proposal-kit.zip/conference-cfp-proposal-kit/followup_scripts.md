# CFP Follow-Up Scripts

## After submitting
Hi [Organizer],

Thanks for reviewing my proposal, [Talk Title]. If helpful, I can adjust the scope for a [length] slot or make it more focused on [audience/track].

Best,
[Name]

## If rejected
Hi [Organizer],

Thanks for letting me know. If you have any quick feedback on fit, scope, or audience relevance, I would appreciate it for future submissions. Either way, wishing you a great event.
