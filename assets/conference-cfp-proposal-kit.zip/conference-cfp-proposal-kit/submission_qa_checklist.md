# Submission QA Checklist

- Title says who/what, not just a buzzword.
- Abstract names the audience.
- Takeaways are concrete and not “learn about X.”
- Scope fits the time slot.
- Evidence is real but not confidential.
- Bio supports the topic.
- No sales pitch language.
- One sentence explains why this event’s audience should care.
