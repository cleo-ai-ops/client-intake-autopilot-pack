# Talk Angle Selector

Pick one primary angle:

1. **Mistake-to-method** — what went wrong, what changed, what others can copy.
2. **Field guide** — a clear map through a confusing tool/process.
3. **Case study** — specific context, decision points, results, and caveats.
4. **Tradeoff talk** — when to choose A vs B and what breaks.
5. **Live teardown** — improve or diagnose a real example.

Avoid vague titles like “The Future of X” unless you have unusually strong evidence.
