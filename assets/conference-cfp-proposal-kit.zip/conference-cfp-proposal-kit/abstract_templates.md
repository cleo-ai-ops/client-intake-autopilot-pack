# CFP Abstract Templates

## Case study
[Audience] often struggle with [specific pain]. In this talk, I will walk through how [team/person] handled [real situation], including [decision 1], [decision 2], and [tradeoff]. Attendees will leave with [takeaway 1], [takeaway 2], and a checklist for applying it to [context].

## Practical guide
This session gives [audience] a practical path to [outcome] without [common bad approach]. We will cover [step 1], [step 2], and [step 3], using examples from [real context]. Attendees will leave with [artifact/framework] they can use after the event.

## Mistake-to-method
I learned [lesson] the hard way while [context]. This talk shares the mistakes, the signals I missed, and the lightweight system that fixed [problem]. Attendees will learn how to spot [risk], choose [approach], and avoid [failure mode].
