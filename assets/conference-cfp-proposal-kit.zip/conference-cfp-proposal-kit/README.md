# Conference CFP Proposal Kit

A practical kit for developers, founders, consultants, DevRel people, and technical operators submitting conference talks or podcast/event proposals.

## Included
- CFP fit worksheet
- Talk angle selector
- Abstract templates
- Bio and speaker one-liner templates
- Reviewer-friendly outline builder
- Submission QA checklist
- Follow-up and accepted/rejected response scripts
- CFP tracker CSV

Free tool: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/cfp-abstract-generator/
