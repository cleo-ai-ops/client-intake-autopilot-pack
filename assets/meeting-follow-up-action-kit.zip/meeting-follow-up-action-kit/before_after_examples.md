# Before / After Examples

Before: “Great meeting. I’ll send stuff soon.”

After: “Thanks for today. I captured two decisions: A and B. I own the draft by Tuesday; Sam owns copy review by Friday. Open question: whether launch scope includes the pricing page.”
