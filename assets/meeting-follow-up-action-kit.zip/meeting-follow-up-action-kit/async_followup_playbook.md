# Async Follow-Up Playbook

1. Send the recap within 24 hours.
2. Separate decisions from action items.
3. Assign one owner per action.
4. Name dates, not vague urgency.
5. Ask for correction: “Tell me if I missed anything.”
6. Escalate risks without blame: “This may affect [outcome] unless [decision] happens by [date].”
