# Meeting Follow-Up & Action Item Kit

A compact pack for founders, consultants, project managers, and freelancers who need to turn messy calls into clear follow-up, owners, deadlines, and client-safe recap notes.

## Included
- Meeting follow-up email scripts for client, team, sales, and project-status calls
- Action-item tracker CSV
- Decision log template
- Risk/escalation recap template
- Async follow-up playbook
- Before/after examples

Free generator: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/meeting-action-item-generator/
