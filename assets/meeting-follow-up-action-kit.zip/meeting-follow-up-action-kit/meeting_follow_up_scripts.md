# Meeting Follow-Up Scripts

## Client project recap
Subject: Recap + next steps from today

Hi [Name],

Thanks for the time today. My read of the decisions and next steps is below so nothing gets lost.

Decisions:
- [Decision 1]
- [Decision 2]

Action items:
- [Owner] — [Action] — due [date]
- [Owner] — [Action] — due [date]

Open questions / risks:
- [Question or risk]

I’ll move forward with [next step] unless anything above looks off.

Best,
[You]

## Sales/discovery recap
Subject: Recap from our call + useful next step

Hi [Name],

Good speaking today. Here’s what I heard: [pain / goal]. The constraint is [constraint], and the success measure is [measure].

Suggested next step: [specific next step].

If that matches your understanding, I can [action].
