# n8n Business Automation Workflow Pack

10 implementation-ready n8n workflow templates for common small-business automations. The pack is designed for a safe first win: import one workflow, run the included test data, verify the output, then connect real credentials.

## What's included
- 10 importable workflow JSON files in `workflows/`
- `TEST-DATA/` with webhook payloads and CSV/JSON fixtures
- `WORKFLOW-SETUP/` with per-workflow credentials, placeholders, free paths, and expected outputs
- `IMPORT-NOTES.md`, `FREE-LOCAL-PATHS.md`, and `TROUBLESHOOTING.md`
- A setup guide for moving from dry-run to production safely

## The 30-minute value path
1. Import one workflow.
2. Open its matching file in `WORKFLOW-SETUP/`.
3. Run the sample in `TEST-DATA/`.
4. Send output to yourself or a sandbox destination first.
5. Only then connect paid/provider APIs.

## Workflows
1. Lead Capture to CRM
2. Invoice Automation
3. Social Media Scheduler
4. Customer Onboarding Sequence
5. Support Ticket Router
6. Weekly Analytics Digest
7. Content Repurposer
8. Database Backup to Cloud/Local Storage
9. Client Project Status Checker
10. Email List Hygiene

## Important promise boundary
These are strong starter workflows, not magic one-click production deployments. n8n credentials, provider APIs, account permissions, and your business rules still need to be connected in your instance. The included test data and free paths are there so you can prove the workflow shape before risking live data.
