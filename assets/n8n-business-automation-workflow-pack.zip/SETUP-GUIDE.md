# n8n Business Automation Workflow Pack — setup guide

## Quick start
1. Choose one workflow from `workflows/`.
2. Read its matching page in `WORKFLOW-SETUP/`.
3. Import the JSON in n8n: **Workflows → Import from File**.
4. Create/select missing credentials.
5. Run the matching fixture from `TEST-DATA/`.
6. Inspect output and error path before activating.

## Recommended first workflows
- **Fastest no-paid-API test:** Support Ticket Router with keyword routing, Social Scheduler as a draft queue, or Lead Capture with local scoring.
- **Best client demo:** Lead Capture to CRM or Weekly Analytics Digest.
- **Most sensitive:** Database Backup and Invoice Automation. Test restore/payment sandbox first.

## Credential map
Stripe: workflows 2 and 4. Slack: 1, 5, 6, 8, 9, 10. Google Sheets: 2, 3, 4, 7, 10. OpenAI: optional in 5 and 7. AWS/GCS: optional in 8. GitHub/Jira: 9. Hunter/Clearbit/HubSpot: optional enrichment/CRM paths.

## Activation rules
- Never activate against live customer data until sample data passes.
- Disable write nodes for the first live-shaped run.
- Add an error notification destination.
- Store secrets in n8n credentials/environment variables, not directly in docs or code nodes.

See `IMPORT-NOTES.md`, `FREE-LOCAL-PATHS.md`, `TROUBLESHOOTING.md`, and `WORKFLOW-SETUP/` for the operational detail.
