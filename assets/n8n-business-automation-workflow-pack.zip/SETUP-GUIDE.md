# n8n Business Automation Workflow Pack — Setup Guide

## Quick Start

1. **Import a workflow**: In n8n, click the `+` button → "Import from File" → select any `.json` file from the `workflows/` folder.

2. **Configure credentials**: Each workflow uses specific n8n credentials. Set these up in n8n Settings → Credentials:
   - **Stripe** (workflows 1, 2, 4): API key from your Stripe dashboard
   - **Slack** (workflows 1, 5, 6, 8, 9, 10): Bot token from Slack API
   - **Google Sheets** (workflows 2, 3, 4): OAuth2 or service account
   - **OpenAI** (workflows 5, 7): API key from platform.openai.com
   - **AWS S3** (workflow 8): Access key + secret from AWS IAM
   - **SMTP/Email** (all email nodes): Your email provider's SMTP settings
   - **GitHub** (workflow 9): Personal access token
   - **Hunter.io** (workflow 10): API key from hunter.io
   - **Clearbit** (workflow 1): API key from clearbit.com

3. **Update placeholders**: Search for `YOUR_` in each workflow and replace with your actual values.

## Workflow Descriptions

### 1. Lead Capture to CRM
- **Trigger**: Webhook (POST to `/lead-capture`)
- **Flow**: Webhook → Clearbit enrichment → Score lead → Add to HubSpot CRM → If grade A, send Slack alert
- **Setup**: Create a HubSpot API key, Clearbit API key, and Slack bot token
- **Customize**: Edit the scoring logic in the "Score Lead" code node to match your ideal customer profile

### 2. Invoice Automation
- **Trigger**: Stripe webhook (`invoice.payment_succeeded`)
- **Flow**: Stripe → Get full invoice → Format data → Send receipt email + Log to Google Sheets
- **Setup**: Add your Stripe webhook endpoint in Stripe Dashboard → Webhooks

### 3. Social Media Scheduler
- **Trigger**: Manual or scheduled (run daily)
- **Flow**: Read approved posts from Google Sheets → Filter by today's date → Post to platform → Mark as posted
- **Setup**: Create a Google Sheet with columns: Platform, Content, ScheduledDate, Status, PostedAt

### 4. Customer Onboarding Sequence
- **Trigger**: Stripe checkout completion
- **Flow**: Get customer → Send welcome email + Log customer → Wait 3 days → Send follow-up
- **Setup**: Update email templates with your product links and onboarding resources

### 5. AI Support Ticket Router
- **Trigger**: Webhook (POST to `/support-ticket`)
- **Flow**: Webhook → AI classifies ticket → Parse → If urgent, Slack alert + Auto-reply to customer
- **Setup**: Customize categories and priorities in the AI prompt

### 6. Weekly Analytics Digest
- **Trigger**: Every Monday at 9am
- **Flow**: Pull Stripe data → Calculate metrics → Email digest
- **Setup**: Add your Stripe API credentials and team email

### 7. AI Content Repurposer
- **Trigger**: Manual or scheduled (check daily)
- **Flow**: Read RSS feed → Filter new posts → AI generates Twitter, LinkedIn, and video scripts → Queue in Google Sheets → Notify team
- **Setup**: Add your blog's RSS feed URL and OpenAI API key

### 8. Database Backup to Cloud
- **Trigger**: Every 6 hours
- **Flow**: Run pg_dump → Upload to S3 → Check result → Notify team
- **Setup**: Set environment variables: DB_HOST, DB_USER, DB_NAME. Configure AWS credentials.

### 9. Client Project Status Checker
- **Trigger**: Every Friday at 4pm
- **Flow**: Fetch GitHub issues → Summarize → Send status email
- **Setup**: Replace YOUR_ORG/YOUR_REPO with your GitHub repo path

### 10. Email List Hygiene
- **Trigger**: Every Sunday at 2am
- **Flow**: Fetch subscribers from Google Sheets → Verify with Hunter.io → Count undeliverable → Notify team
- **Setup**: Add Hunter.io API key and your subscriber spreadsheet

## Customization Tips

- **Scoring logic** (Workflow 1): Adjust weights and thresholds in the code node
- **Email templates** (All): Edit the text in email nodes for your brand voice
- **AI prompts** (Workflows 5, 7): Modify system prompts for your specific use cases
- **Schedules**: Change cron triggers to match your timing needs
- **Platform routing** (Workflow 3): Add more social platforms (Mastodon, Bluesky, etc.)

## Support

If you need help customizing these workflows for your business:
- Check the n8n community forum: https://community.n8n.io
- n8n documentation: https://docs.n8n.io

---

*Part of the n8n Business Automation Workflow Pack by Cleo Operations*
