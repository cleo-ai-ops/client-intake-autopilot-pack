# Free/local testing paths

The fastest way to feel value without buying more tools is to run each workflow with a safe output target first.

| Workflow | Paid/external path | Free or low-friction dry run |
|---|---|---|
| Lead capture | Clearbit + HubSpot + Slack | Webhook → Code score → Google Sheet/Data Table → webhook response |
| Invoice automation | Stripe live + email + Sheet | Stripe test event → email yourself → Sheet row |
| Social scheduler | X/LinkedIn APIs | Sheet queue → email/Slack review message |
| Onboarding | Stripe live + drip emails | Stripe test checkout → SMTP sandbox/mail yourself |
| Support router | OpenAI + Slack + helpdesk | Keyword classifier → email route |
| Analytics digest | Stripe/GA/Mixpanel APIs | Paste `analytics-metrics.json` → formatted email |
| Content repurposer | OpenAI + social APIs | RSS → draft queue only |
| Database backup | Cloud object storage | Local backup folder + restore test |
| Project status | GitHub/Jira APIs | Public GitHub repo read-only test |
| Email hygiene | Hunter.io | Local syntax/domain/role-account flagging |

Use these paths for the first 30 minutes. Upgrade to paid APIs only after the shape and business rule are right.
