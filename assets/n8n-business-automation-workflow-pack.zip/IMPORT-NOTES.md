# n8n import notes and version assumptions

These workflows are exported as importable n8n JSON templates. They are meant to be reviewed after import because every n8n instance stores credentials separately.

## Recommended import flow
1. Import one workflow at a time.
2. Open every red credential warning before running.
3. Disable write/action nodes during the first dry run if you are testing against real accounts.
4. Use the sample files in `TEST-DATA/` before connecting production data.
5. Rename credentials clearly: `Stripe Test`, `Slack Ops Alerts`, `Google Sheets Automation Log`.

## Common import warnings
- **Missing credentials**: expected. Create credentials in your n8n instance and select them on the node.
- **Webhook URL changed**: expected. Copy the URL from your imported workflow, not this documentation.
- **Node package/API mismatch**: update n8n first, or replace the provider node with an HTTP Request node using the same input/output fields.

## Safe activation rule
A workflow is not ready for live activation until one sample run has completed, one error path has been intentionally tested, and at least one output has been manually inspected.
