# n8n troubleshooting playbook

## Credential missing after import
Imported workflows reference node types, not your private credentials. Create the credential in **Settings → Credentials**, reopen the node, select the credential, and save.

## Webhook returns 404
Use the exact production or test webhook URL shown in your imported workflow. Test URLs work only while the workflow editor is listening; production URLs require the workflow to be active.

## Code node output is empty
Open the previous node output and confirm field names match the sample payload. If your form uses `company_name` instead of `company`, map it before the scoring/classification node.

## Provider API limit or paid wall
Switch to the documented free path first. Keep the provider node disabled until the workflow proves useful with sample data.

## Email sends to the wrong person
Before activation, hard-code your own inbox in all email nodes. Replace dynamic recipients only after the final dry run.

## Database backup fails
Run the `pg_dump` command manually on the same host/user as n8n. Confirm a restore from the generated file before trusting scheduled backups.
