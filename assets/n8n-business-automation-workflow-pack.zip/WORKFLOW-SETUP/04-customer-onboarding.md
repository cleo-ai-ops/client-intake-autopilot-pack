# Customer Onboarding Sequence — setup notes

## Import
1. Open n8n → **Workflows** → **Import from file**.
2. Select `workflows/04-customer-onboarding.json`.
3. Keep the workflow inactive until credentials and placeholders are reviewed.

## Test data
Use `TEST-DATA/stripe-invoice-payment-succeeded.json`. For webhook workflows, send it with:

```bash
curl -X POST "$N8N_WEBHOOK_URL" \
  -H "Content-Type: application/json" \
  --data @TEST-DATA/stripe-invoice-payment-succeeded.json
```

For sheet-based workflows, import the CSV into a sheet with the exact header row first.

## Required credentials
Stripe + SMTP + optional Slack. Start in sandbox/test mode where the provider supports it. Use least-privilege tokens and rotate any token pasted during testing.

## Low-friction/free path
Free path: use Stripe test events and SMTP sandbox/mail-to-self while validating sequence timing.

## Placeholders to search after import
- `YOUR_` values in URLs, emails, team names, spreadsheet IDs, repo names, or bucket names.
- Credential selectors on provider nodes.
- Email sender/from address and reply-to fields.
- Slack/channel IDs and escalation recipient addresses.

## Expected first successful run
- Trigger receives sample input or scheduled/manual run starts.
- Transform/code nodes produce normalized fields.
- External write nodes are either disabled for dry-run or point to a sandbox destination.
- Final notification/response clearly shows success or the exact missing credential.

## Production checklist
- Run with test data twice.
- Confirm no sample customer data remains in live nodes.
- Confirm error path sends a notification.
- Activate only after the first dry-run output matches your expected format.
