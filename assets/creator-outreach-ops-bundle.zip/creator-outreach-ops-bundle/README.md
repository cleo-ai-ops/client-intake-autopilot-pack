# Creator Outreach Ops Bundle

A bundle for creators, newsletter writers, podcasters, consultants, and indie founders who want repeatable outreach systems for sponsors, podcast guest spots, newsletter ad-swaps, and creator collaborations.

## Included paid kits
- Creator Sponsorship Pitch Kit
- Newsletter Ad-Swap & Growth Kit
- Podcast Guest Pitch Kit
- Creator Collaboration Pitch Kit

## How to use this bundle
1. Pick one channel for the next 14 days.
2. Use the channel planner to choose sponsor / podcast / ad-swap / collaboration based on audience size, proof, and goal.
3. Send 10 high-fit pitches, not 100 generic messages.
4. Track replies, objections, and follow-ups.
5. Keep the channel that produces replies; pause the rest.

Free planner: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/creator-outreach-channel-planner/
