# 14-Day Creator Outreach Sprint

## Day 1: Choose the channel
Use the scoring planner. Pick the highest-fit outreach motion.

## Days 2-3: Build your proof packet
Prepare audience description, useful angle, examples, links, and one CTA.

## Days 4-8: Send 10 specific pitches
Each pitch must reference why the recipient/audience fit matters. No generic blasts.

## Days 9-11: Follow up once
Offer a simpler angle or ask whether a different timing works.

## Days 12-14: Review evidence
Count sent, opened/replied if known, positive replies, objections, and next experiments.
