# Slide copy bank

## Problem headlines

- [ICP] is spending [hours/cost] every week on [broken workflow].
- The painful part is not [obvious task]; it is [hidden operational cost].
- Teams know [outcome] matters, but the current workflow makes it inconsistent.

## Solution headlines

- The fastest way for [ICP] to go from [input] to [valuable output].
- [Workflow] that feels like hiring an expert operator, not configuring another tool.
- Turn [messy input] into [trusted decision/output] in [time].

## Traction phrasing

Strong: “42 paying teams, €18k MRR, 68% activated in week one.”
Weak: “Lots of interest from potential users.”

Strong: “9 of 12 design partners use it weekly.”
Weak: “Customers love the concept.”

## Moat phrasing

- Our advantage compounds as each workflow creates [data/template/integration] that makes the next customer faster to activate.
- We are not competing on model access; we are competing on workflow ownership and buyer trust.

## Ask phrasing

- Raising €[amount] to reach [revenue/usage milestone] and prove [channel] before seed.
- This round buys [months] runway and funds [specific hires/builds], not vague growth.
