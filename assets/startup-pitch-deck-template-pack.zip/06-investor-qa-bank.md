# Investor Q&A bank

## Market and urgency

**Q: Why is this a venture-scale company?**
Strong answer: Start with bottom-up beachhead math, then explain expansion path and why the wedge leads to a larger platform.
Weak answer: “The TAM is huge.”

**Q: Why now?**
Strong answer: Name the external shift and show evidence buyers are changing behavior now.
Weak answer: “AI is hot.”

## Product and retention

**Q: What proves people need this repeatedly?**
Strong answer: activation, repeat usage, renewal, workflow frequency, or budget owner behavior.
Weak answer: signups without usage.

**Q: What is hardest to build?**
Strong answer: the domain workflow, trust layer, data model, integration depth, or distribution—not generic UI.

## GTM

**Q: How do you get the first 100 customers?**
Strong answer: named channel, specific list/community/partner path, conversion assumptions, and early evidence.

**Q: Who signs the check?**
Strong answer: buyer, user, budget, urgency, sales cycle.

## Competition

**Q: Why won’t incumbents add this?**
Strong answer: wedge is too narrow/low-ACV for them initially, but painful enough for the beachhead; speed and focus create adoption.

## Fundraise

**Q: What milestone does this round unlock?**
Strong answer: a fundable milestone: revenue, retention, channel proof, or technical proof.
Weak answer: “Build product and grow team.”
