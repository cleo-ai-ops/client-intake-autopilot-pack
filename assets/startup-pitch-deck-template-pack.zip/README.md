# Startup Pitch Deck Template Pack

A practical, investor-facing deck system for pre-seed and seed founders. This is not a graphic design theme; it is a premium content structure pack you can paste into Google Slides, PowerPoint, Figma, Pitch, or Canva.

## What is inside

- `01-master-12-slide-investor-deck.md` — slide-by-slide copy template with investor intent, proof bar, speaker notes, and common mistakes.
- `02-saas-seed-deck-example.md` — filled example for a B2B SaaS startup.
- `03-marketplace-preseed-deck-example.md` — filled example for a two-sided marketplace.
- `04-ai-product-deck-example.md` — filled example for an AI workflow product.
- `05-slide-copy-bank.md` — premium headline, metric, moat, traction, ask, and risk wording.
- `06-investor-qa-bank.md` — hard questions investors ask plus strong/weak answer patterns.
- `07-deck-review-scorecard.csv` — 100-point self-review before sending.
- `08-financial-model-starter.csv` — simple revenue and runway starter.
- `09-investor-outreach-scripts.md` — warm intro, cold email, follow-up, and post-meeting scripts.
- `10-design-system-notes.md` — layout, typography, chart, and visual hierarchy guidance.

## Fast path

1. Start with `01-master-12-slide-investor-deck.md`.
2. Pick the example closest to your business model.
3. Draft in plain text before opening slides.
4. Score with `07-deck-review-scorecard.csv`.
5. Only then make it visually polished.

## Quality rule

Every slide needs one job, one headline, one proof point, and one reason the investor should care now.
