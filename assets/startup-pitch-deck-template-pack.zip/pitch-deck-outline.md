# Startup Pitch Deck Template Pack — Contents

## 1. 12-Slide Pitch Deck Outline
- Problem Slide
- Solution Slide  
- Market Size (TAM/SAM/SOM)
- Business Model
- Traction / Metrics
- Product Demo / Screenshots
- Go-to-Market Strategy
- Team
- Competition / Positioning
- Financial Projections (3-year)
- The Ask (fundraise details)
- Contact / Next Steps

## 2. Slide-by-Slide Copy Templates
Each slide includes:
- Headline formula
- Body text template with [placeholders]
- Design tips (font size, layout, what to emphasize)
- What investors look for on this slide

## 3. Investor Q&A Cheat Sheet
- 25 most common investor questions
- Suggested answer frameworks
- Red flags to avoid

## 4. Pitch Deck Evaluation Checklist
- Self-review checklist before sending to investors
- 20-point scoring rubric
- Common pitch deck mistakes and how to fix them

## 5. Cold Email Template for Investors
- 3 email templates (warm intro, cold outreach, follow-up)
- Subject line variations
- When to send and how to follow up

## 6. Pitch Deck Example Prompts for AI
- ChatGPT prompts to generate market research, financials, and competitive analysis
- Prompts for creating slide copy from raw notes
