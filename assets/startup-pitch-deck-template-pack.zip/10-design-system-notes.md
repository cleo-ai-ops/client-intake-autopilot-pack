# Design system notes for a premium deck

## Layout

- One idea per slide.
- Use a strong headline that states the conclusion, not a label. “Support teams lose 6 hours/week to repeat replies” beats “Problem.”
- Keep body text under 45 words per slide when possible.
- Put proof near the claim it supports.

## Visual hierarchy

- Headline: 32–44pt.
- Key metric: 44–72pt.
- Body: 18–24pt.
- Footnotes/source: 9–12pt.

## Charts

Use charts only when the shape matters. Label the takeaway directly on the chart.

Good: “Activation rose from 22% to 41% after guided setup.”
Bad: unlabeled chart with tiny axes.

## Color

Pick one accent color. Use it for proof, key metrics, and callouts. Avoid rainbow charts unless categories require it.

## Screenshots

Crop aggressively. Annotate the 1–2 UI elements that matter. Never show a full busy dashboard without guidance.
