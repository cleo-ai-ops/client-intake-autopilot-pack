# Master 12-slide investor deck template

Use this as your content skeleton. Replace bracketed copy. Keep each slide visually simple.

## 1. Cover

**Headline:** [Company] helps [specific customer] achieve [valuable outcome] without [painful old way].

**Subline:** [Category] for [ICP] • [Stage] • [Location/market if relevant]

**Proof bar:** [MRR/users/pilots/waitlist/customer logos/launch date]

**Speaker note:** Investors should know what you do, who it is for, and why you have earned the meeting within 10 seconds.

**Avoid:** vague slogans like “the future of work.”

## 2. Problem

**Headline:** [ICP] loses [time/money/revenue/risk] because [current workflow is broken].

Show 3 concrete pain points:

1. [Pain with measurable cost]
2. [Pain with emotional/operational friction]
3. [Pain with current workaround]

**Proof:** customer quote, survey number, screenshots, workflow map, or market data.

**Investor test:** Is this painful enough to budget for?

## 3. Current alternatives

**Headline:** Existing options force teams to choose between [bad tradeoff A] and [bad tradeoff B].

Table:

| Alternative | Why buyers use it | Where it fails |
|---|---|---|
| Spreadsheet/manual | Cheap, flexible | Error-prone, invisible, slow |
| Legacy tool | Accepted by procurement | Heavy setup, poor UX |
| Horizontal AI/tool | Easy to try | Not workflow-specific |

## 4. Solution

**Headline:** [Company] turns [painful workflow] into [simple new workflow].

3-step product story:

1. Connect/import [input]
2. [Product action]
3. Get [output/result]

Include one product screenshot/mockup. If no screenshot, use a workflow diagram.

## 5. Why now

**Headline:** The market is shifting now because [timing change].

Choose 2–3:

- regulatory change
- platform/API change
- AI/automation unlock
- buyer behavior shift
- budget moving into category
- old solution becoming too expensive/slow

**Proof:** cite credible signals, not hype.

## 6. Market

**Headline:** We start with [reachable beachhead] and expand into [larger market].

Bottom-up sizing:

- Beachhead customers: [number]
- Annual contract / monthly price: [amount]
- Initial serviceable market: [customers × price]
- Expansion path: [adjacent segment]

**Avoid:** giant top-down TAM with no go-to-market connection.

## 7. Business model

**Headline:** We charge [buyer] [price] for [unit of value].

Include:

- pricing today
- expansion/upsell path
- gross margin expectation
- sales motion: self-serve / founder-led / sales-led

## 8. Traction

**Headline:** Early users are showing [specific pull].

Good traction examples:

- revenue: MRR, paid pilots, expansion
- usage: activation, weekly active teams, retained cohorts
- demand: qualified pipeline, LOIs, waitlist with ICP quality
- proof: case study, testimonial, before/after metric

Table:

| Metric | Current | 30/60/90-day trend | Why it matters |
|---|---:|---:|---|

## 9. Go-to-market

**Headline:** We acquire [ICP] through [repeatable channel] because [behavior].

Include:

- initial wedge channel
- proof it works or why founder has access
- sales cycle
- CAC assumption
- first 10/100 customers plan

## 10. Competition and moat

**Headline:** We win by being [specific wedge], not by being bigger.

Positioning grid axes:

- X-axis: [workflow-specific ↔ generic]
- Y-axis: [fast/self-serve ↔ enterprise-heavy]

Moat candidates:

- proprietary workflow data
- distribution/community
- integrations
- switching costs
- specialized UX
- domain expertise

## 11. Team

**Headline:** This team has unusual insight into [problem/market/channel].

For each founder:

- role
- relevant proof
- unfair insight/access

If solo founder: show advisor/contractor gaps honestly.

## 12. Ask and milestones

**Headline:** Raising [amount] to reach [milestone] in [timeframe].

Use-of-funds table:

| Use | % | Outcome |
|---|---:|---|
| Product | 40% | [ship/scale milestone] |
| GTM | 35% | [pipeline/revenue milestone] |
| Ops/other | 25% | [runway/team milestone] |

Close with the next fundable milestone, not generic “growth.”
