# Investor outreach scripts

## Warm intro request

Subject: Intro to [Investor]?

Hi [Name] — quick ask. We’re building [one-line company] and I noticed [Investor] has backed [relevant company/category].

Current proof: [traction]. We’re raising [amount] to reach [milestone].

Would you be comfortable introducing us if I send a tight forwardable blurb?

## Forwardable blurb

[Company] helps [ICP] [outcome] without [old painful workflow]. We have [traction/proof] and are raising [amount] to reach [milestone]. Given your interest in [theme], I thought this might be relevant.

Deck: [link]

## Cold investor email

Subject: [Company] — [traction] in [category]

Hi [Investor],

I’m [Founder], building [Company]: [specific outcome for ICP].

Why now: [market shift].

Early proof:
- [metric 1]
- [metric 2]
- [customer/usage proof]

We’re raising [amount] to [milestone]. Worth a 20-minute conversation next week?

## Post-meeting follow-up

Thanks again for the conversation. Based on your questions, the key points are:

1. [Concern] → [answer/proof]
2. [Concern] → [answer/proof]
3. [Next milestone] → [timeline]

I’ll send [specific follow-up] by [date].
