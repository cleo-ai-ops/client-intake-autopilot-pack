# Startup Pitch Deck Template Pack

## 12-Slide Pitch Deck Outline with Copy Templates

---

### Slide 1: Title / Hook
**Headline formula:** "[Company Name] — [One-line description of what you do]"
**Template:** `"[Name] helps [target user] [solve problem] by [unique approach]"`
**Design tip:** Clean logo, minimal text. Your name and one sentence. That's it.

### Slide 2: The Problem
**Headline:** "[Target users] struggle with [specific problem]"
**Body template:**
- "Today, [target users] deal with [pain point 1]"
- "This leads to [quantified negative outcome]"  
- "The current solutions ([competitor types]) fail because [specific gap]"
**What investors want:** Can you articulate the pain clearly? Do you understand who feels it most?

### Slide 3: The Solution
**Headline:** "[Product Name] — [How you solve it]"
**Body template:**
- "We built [product] to [solve the problem]"
- "Unlike [existing solutions], we [key differentiator]"
- "Our approach: [1-2 sentence technical/business moat]"
**What investors want:** Is this actually different? Is it 10x better or just 10% better?

### Slide 4: Market Size
**Headline:** "A [size] market growing at [rate]% annually"
**Template:**
- TAM (Total Addressable Market): "$[X]B — [broad market description]"
- SAM (Serviceable Addressable Market): "$[X]B — [your specific segment]"
- SOM (Serviceable Obtainable Market): "$[X]M — [realistic capture in 3-5 years]"
**Source tips:** Reference credible sources (market reports, analyst data). Show your math.

### Slide 5: Business Model
**Headline:** "How we make money"
**Template:**
- "We charge [pricing model — subscription/transaction/freemium]"
- "Average revenue per customer: $[X]/[time period]"
- "Unit economics: CAC $[X], LTV $[X], payback [X] months"
**What investors want:** Clear path to revenue. Reasonable unit economics for the stage.

### Slide 6: Traction / Metrics
**Headline:** "[Key metric] growing [X]% [time period]"
**Template:**
- "[X] users / customers"
- "$[X] ARR / MRR"
- "[X]% month-over-month growth"
- "[Notable customer/partnership/logos]"
**What investors want:** Proof people want this. Growth rate matters more than absolute numbers at early stage.

### Slide 7: Product
**Headline:** "How it works"
**Include:** 2-3 screenshots or a simple flow diagram
**Template caption:** "Step 1: [Action]. Step 2: [Action]. Step 3: [Result]."
**Design tip:** Don't try to show everything. Pick the most impressive flow.

### Slide 8: Go-to-Market Strategy
**Headline:** "Reaching [target customer] through [channels]"
**Template:**
- "Channel 1: [Specific tactic] — expected CAC $[X]"
- "Channel 2: [Specific tactic] — expected CAC $[X]"  
- "Channel 3: [Specific tactic] — expected CAC $[X]"
- "Unfair advantage: [Why you can reach them better/cheaper]"

### Slide 9: Team
**Headline:** "Built by [relevant experience]"
**Template per person:**
- "[Name] — [Role]. Previously [relevant company/achievement]. [Domain expertise]."
**What investors want:** Why is THIS team uniquely qualified? Show relevant domain expertise.

### Slide 10: Competition / Positioning
**Format:** 2x2 matrix or feature comparison table
**Template axes:** 
- X-axis: "[Dimension 1 — e.g., Price]"
- Y-axis: "[Dimension 2 — e.g., Ease of Use]"
**Place yourself in the top-right (or wherever makes sense)**
**List competitors:** "[Competitor 1]", "[Competitor 2]", "[Competitor 3]"
**Your differentiators:** "[Advantage 1]", "[Advantage 2]", "[Advantage 3]"

### Slide 11: Financial Projections
**Headline:** "Path to $[X]M ARR by [Year]"
**Template table:**
| Metric | Year 1 | Year 2 | Year 3 |
|--------|--------|--------|--------|
| Revenue | $[X] | $[X] | $[X] |
| Customers | [X] | [X] | [X] |
| Expenses | $[X] | $[X] | $[X] |
| Burn | $[X]/mo | $[X]/mo | — |

### Slide 12: The Ask
**Headline:** "Raising $[X]M to [achieve specific milestone]"
**Template:**
- "Raising: $[X]M [seed/pre-seed/Series A]"
- "Use of funds: [X]% product, [X]% sales, [X]% hiring"
- "Runway: [X] months"
- "Next milestone: [Specific measurable goal]"
- "Contact: [email]"

---

## 25 Most Common Investor Questions

1. What's the biggest risk to your business?
2. Why now? Why hasn't this been built before?
3. What happens if [big company] enters your market?
4. How do you acquire customers?
5. What's your churn rate and why?
6. How big can this become?
7. What's your moat / defensibility?
8. Why are you the right team to build this?
9. What's your CAC and how does it scale?
10. What's the biggest mistake you've made so far?
11. How do you think about pricing?
12. What's your 12-month plan with this funding?
13. What does success look like in 3 years?
14. How do you plan to use the funds?
15. What's your burn rate?
16. Who are your biggest competitors and how are you different?
17. What's your retention / engagement like?
18. Can you explain the product in one sentence?
19. What traction do you have?
20. What's your go-to-market strategy?
21. How did you arrive at your valuation?
22. What's your target market and why?
23. What's the status of your IP / technology?
24. How do you plan to scale the team?
25. What are the key assumptions in your model?

### Answer Framework
For each question:
1. **Acknowledge** — Show you understand the concern
2. **Data point** — Support with a specific number or fact
3. **Forward look** — Connect to your plan/traction
4. **Avoid:** Vague answers, ignoring the question, or over-promising

---

## Pitch Deck Evaluation Checklist (20 points)

Score each 1-5:
- [ ] Problem is clearly stated and relatable
- [ ] Solution directly addresses the problem
- [ ] Market size is credible and well-sourced
- [ ] Business model is clear and realistic
- [ ] Traction metrics are presented honestly
- [ ] Product demo/screenshots are clear
- [ ] Go-to-market strategy is specific (not "we'll do SEO")
- [ ] Team has relevant domain expertise
- [ ] Competition is acknowledged (not "no competitors")
- [ ] Financial projections are grounded in assumptions
- [ ] The ask is specific with clear use of funds
- [ ] Deck tells a coherent story from start to finish
- [ ] Slides are readable (no walls of text)
- [ ] Design is professional and consistent
- [ ] Key numbers are highlighted and easy to find
- [ ] No more than 12-15 slides total
- [ ] Includes appendix for deep dives
- [ ] Font size ≥ 24pt on all slides
- [ ] Each slide makes ONE clear point
- [ ] Deck works as a standalone read (no presenter needed)

**Scoring:** 80+ = strong draft with fewer obvious gaps | 60-79 = needs polish | Below 60 = major revision needed

---

## Cold Email Templates for Investors

### Template 1: Warm Intro Follow-up
**Subject:** Following up on [Mutual Contact]'s intro — [Company Name]

Hi [Name],

[Mutual Contact] suggested I reach out. I'm building [Company Name] — we [one sentence description].

We're currently [traction metric — e.g., "$10K MRR growing 20% MoM"] and raising a [round type] to [specific milestone].

Would you be open to a 15-minute call this week? Happy to send the deck in advance.

Best,
[Name]

### Template 2: Cold Outreach
**Subject:** [Company Name] — [Impressive metric or insight]

Hi [Name],

I noticed your investment in [their portfolio company in similar space]. 

I'm building [Company Name], which [one sentence]. We've [traction]. The market is [size] and growing because [trend].

I'd love to share what we're building. Are you open to a quick call?

[Link to deck]

Best,
[Name]

### Template 3: Follow-up After Sending Deck
**Subject:** Re: [Company Name] deck — quick question

Hi [Name],

Sharing the deck as promised [link]. Three highlights:

1. [Traction metric]
2. [Market opportunity]
3. [Team strength]

Would love to hear your thoughts. Free for a call [specific times]?

Best,
[Name]

---

## AI Prompts for Pitch Deck Creation

### Market Research Prompt
"I'm building a [type of company] that [solves X problem] for [target customer]. Help me estimate the TAM, SAM, and SOM. Provide specific data sources, industry reports, and bottom-up calculations. Show your math."

### Competitive Analysis Prompt  
"Analyze the competitive landscape for [product category]. List the top 10 players, their pricing, target segments, strengths, and weaknesses. Create a positioning matrix with dimensions [X] and [Y]. Suggest where my company — [description] — would fit."

### Financial Projections Prompt
"Create a 3-year financial projection for a SaaS startup with [pricing], [current customers], and [growth rate]. Include: revenue, COGS, gross margin, operating expenses by category, net income, and key SaaS metrics (MRR, churn, LTV, CAC). Show monthly for Year 1 and quarterly for Years 2-3."

### Slide Copy Prompt
"I'm creating a pitch deck slide about [topic]. My key points are: [list points]. Write compelling, concise slide copy with: a headline (under 10 words), 3-4 bullet points (under 15 words each), and a speaker note explaining the key takeaway for investors."
