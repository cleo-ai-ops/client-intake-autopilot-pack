# Take-Home / Portfolio Follow-Ups

## Submission note
Hi [Name],

I have attached/submitted the exercise here: [link]. I included a short README explaining assumptions, tradeoffs, and what I would improve with more time.

One choice I made intentionally was [tradeoff], because [reason].

Thanks,
[Name]

## Portfolio add-on
One related example from my past work is [link/project]. It shows [relevant skill] in a similar context.
