# Offer-Stage Clarification Questions

- What would success look like in the first 90 days?
- Who will I work with most closely?
- What are the main risks or constraints around this role?
- How are priorities decided when everything feels urgent?
- What support is available for onboarding?
- Can you walk me through compensation, benefits, and review timing?
