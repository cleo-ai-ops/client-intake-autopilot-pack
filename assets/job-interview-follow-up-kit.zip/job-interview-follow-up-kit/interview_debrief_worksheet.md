# Interview Debrief Worksheet

Complete this within 20 minutes after the interview.

- Role / company:
- Interviewers and roles:
- Main problems the team is trying to solve:
- 2 specific details they mentioned:
- Your strongest matching experience:
- Concern or gap to address gently:
- Next step / timing they shared:

Use these notes to make the follow-up specific instead of generic.
