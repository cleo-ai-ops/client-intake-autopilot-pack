# Job Interview Follow-Up Kit

A compact job-seeker pack for sending useful, specific interview follow-ups without sounding desperate or generic.

## Included
- Interview debrief worksheet
- Same-day thank-you email templates
- Multi-interviewer follow-up scripts
- Take-home / portfolio follow-up templates
- Recruiter check-in and no-response scripts
- Offer-stage clarification questions
- Follow-up tracker CSV

Free tool: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/interview-follow-up-email-generator/
