# Multi-Interviewer Follow-Ups

Send a different note to each person. Reuse structure, not the exact same content.

- Recruiter: confirm timing and enthusiasm.
- Hiring manager: connect to business/problem outcome.
- Peer: reference collaboration or workflow detail.
- Technical interviewer: reference technical discussion or tradeoff.

Avoid: long essays, compensation pressure, correcting every answer, or sounding like a template.
