# Recruiter Check-In Scripts

## After expected timeline passes
Hi [Name],

I hope you are well. I wanted to check in on the [Role] process. I am still interested, especially after learning more about [specific team/problem].

Is there any updated timing for next steps?

Best,
[Name]

## If you have another process moving
Hi [Name],

Quick timing note: another process may move to final stages soon, but [Company] remains very interesting to me because [specific reason]. Is there an updated timeline I should keep in mind?
