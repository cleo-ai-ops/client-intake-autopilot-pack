# Same-Day Thank-You Templates

## Hiring manager
Subject: Thank you — [Role] conversation

Hi [Name],

Thank you for taking the time today. I enjoyed learning more about [specific team/problem]. The part about [specific detail] stood out because it connects closely with my experience [brief proof].

I am excited about the possibility of helping with [outcome]. Happy to send anything else that would be useful as you compare candidates.

Best,
[Name]

## Technical interviewer
Subject: Thanks for the technical discussion

Hi [Name],

Thanks for the conversation today. I appreciated the discussion around [technical topic]. After thinking about [question/challenge], I would approach it by [short, humble clarification if useful].

Thanks again,
[Name]
