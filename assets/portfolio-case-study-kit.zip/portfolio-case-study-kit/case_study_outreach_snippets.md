# Outreach Snippets

## Past client
I wrote up a short, permission-safe case study of the work we did together. I kept private details out and focused on the process and outcomes. Would you be comfortable with me publishing this version?

## Prospect follow-up
This project is close to the problem you described. The case study shows how I approached the constraints and what changed after delivery: [link]
