# Publish QA Checklist

- The first paragraph says who the work helped and what changed.
- Your role is specific.
- Constraints are named.
- Proof is honest and permission-safe.
- The case study is skimmable.
- CTA matches the type of work you want more of.
