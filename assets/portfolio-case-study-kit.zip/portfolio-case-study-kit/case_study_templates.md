# Case Study Templates

## Freelancer service case study
Problem → Context → Approach → Deliverables → Result → What I would do next.

## Job seeker project case study
Goal → Constraints → Technical/product decisions → Final artifact → What I learned → Role fit.

## Consultant case study
Business trigger → Diagnosis → Intervention → Adoption → Evidence → Next opportunity.
