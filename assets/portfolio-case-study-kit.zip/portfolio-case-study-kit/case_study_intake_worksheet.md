# Case Study Intake Worksheet

- Project/client type:
- Audience reading this case study:
- Original problem or trigger:
- Constraints: time, budget, tech, stakeholders, compliance:
- Your exact role and decisions:
- What changed after the work:
- Proof you can safely show:
- Proof you cannot show publicly:
- One sentence version of the story:
