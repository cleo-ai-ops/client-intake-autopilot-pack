# Visual Asset Checklist

- One hero screenshot or diagram
- Before/after flow or process map
- 2–4 annotated screenshots
- Quote or testimonial if permission-safe
- Metrics/proof box with cautious wording
- Link to artifact, demo, repo, or anonymized sample when possible
