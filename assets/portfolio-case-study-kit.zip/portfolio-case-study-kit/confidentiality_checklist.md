# Client-Safe Proof Checklist

- Remove private client names unless permission exists.
- Replace exact revenue/customer figures with ranges or operational outcomes when needed.
- Do not publish screenshots with emails, tokens, analytics IDs, customer data, or internal roadmaps.
- Say “helped reduce manual review” instead of inventing unsupported percentages.
- Ask for approval when the case study names the client or shows their product.
