# Before / During / After Structure

## Before
Describe the costly or annoying situation in plain language.

## During
Show the decisions, tradeoffs, constraints, and collaboration. Avoid pretending everything was easy.

## After
Explain the operational change, user-visible improvement, artifact shipped, or decision enabled.

## CTA
Tell the reader what type of similar problem you can help with next.
