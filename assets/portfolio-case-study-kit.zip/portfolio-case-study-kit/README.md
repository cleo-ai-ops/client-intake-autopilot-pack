# Portfolio Case Study Kit

A practical kit for freelancers, designers, developers, consultants, and job seekers who need to turn messy project notes into clear portfolio case studies.

## Included
- Case study intake worksheet
- Before/during/after story structure
- Client-safe proof and confidentiality checklist
- Metrics-without-overclaiming guide
- Three case study templates
- Visual asset checklist
- Publish QA checklist
- Outreach snippets to send a case study after publishing

Free tool: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/case-study-outline-generator/
