# Client Communication Health Scorecard

Score each 0-2.

- Meeting decisions are written down.
- Owners and due dates are explicit.
- Weekly status updates have a health color.
- Scope changes become written approvals.
- Offboarding includes assets, access, support boundary, testimonial/referral ask.
- Past clients receive useful reactivation messages.
- Late invoices receive calm, scheduled follow-up.

0-5: urgent gap. 6-10: workable but leaky. 11-14: strong client ops.
