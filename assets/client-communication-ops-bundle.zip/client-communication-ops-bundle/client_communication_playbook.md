# Client Communication Playbook

## The operating rhythm
1. After every meeting: send decisions, owners, dates, and open risks.
2. Every week: send green/yellow/red project health.
3. When scope changes: name the tradeoff and ask for approval before doing extra work.
4. At handoff: transfer assets, set support boundaries, and ask for proof/testimonial while the win is fresh.
5. When revenue is stuck: reactivate quiet clients and follow up on overdue invoices calmly.

## The rule
Clients should never have to guess: what happened, what is next, who owns it, what is at risk, and what decision is needed.
