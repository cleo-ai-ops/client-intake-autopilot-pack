# Start Here

Pick the moment you are in:

- A meeting just ended -> Meeting Follow-Up & Action Item Kit
- A project is mid-flight -> Weekly Client Status Report Kit
- Client asks for more work -> Project Change Order Kit
- Project is ending -> Client Offboarding & Handoff Kit
- Need proof -> Client Testimonial Request Kit / Portfolio Case Study Kit
- Need warm revenue -> Client Reactivation Email Kit
- Invoice is late -> Late Invoice Rescue Kit

Use one script today. Do not rebuild your whole client process at once.
