# First Status Update Templates

## Investigating
We are investigating an issue affecting [feature/service]. Some customers may see [observable symptom].

We are checking [system area] now and will post the next update by [time]. If you are affected, [workaround/no action needed].

## Identified
We have identified the cause of the issue affecting [feature/service] and are working on [mitigation/fix].

Current impact: [impact]. Next update by [time].

## Monitoring
A fix has been applied and we are monitoring recovery. Customers should now see [expected improvement].

We will confirm once the system has remained stable for [time window].
