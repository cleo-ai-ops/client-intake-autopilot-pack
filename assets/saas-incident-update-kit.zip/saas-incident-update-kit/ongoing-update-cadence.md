# Ongoing Update Cadence

## 30-minute update
We are still working on [issue]. Since the last update, we have [what changed]. Impact remains [same/changed]. Next update by [time].

## 60-minute update
We know this is disruptive. Current status: [plain language]. Our team is focused on [current action]. Workaround: [workaround or none]. Next update by [time].

## 120-minute update
This issue has lasted longer than expected. We are continuing to [action] and will share a fuller explanation after resolution. Current impact: [impact]. Next update by [time].
