# Incident Severity & Message Map

## SEV1: major outage or data-risk uncertainty
Goal: acknowledge fast, give a next-update time, avoid speculation.
Use: status page + in-app banner + direct customer email for affected accounts.

## SEV2: degraded feature or queue delay
Goal: state impact, workaround, and next update.
Use: status page and support macros.

## SEV3: minor interruption / partial delay
Goal: reduce duplicate tickets and document resolution.
Use: status page or support macro.

## Message rules
- Say what is affected, who is affected, what users can do now, and when the next update will arrive.
- Do not claim root cause until verified.
- Do not promise exact fix times unless engineering has high confidence.
- Keep every update timestamped.
