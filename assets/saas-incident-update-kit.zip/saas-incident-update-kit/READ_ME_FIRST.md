# SaaS Incident Update Kit

A calm, practical communication kit for solo SaaS founders and small teams during customer-facing incidents. It helps you publish clear status updates, support replies, and a short post-incident follow-up without sounding evasive or overpromising.

## Buyer hypothesis
Small SaaS teams often know the technical fix but freeze on customer communication during outages, degraded performance, failed email/webhook queues, billing glitches, or data import delays. They need ready-to-adapt updates that reduce support load and preserve trust.

## Included
- Incident severity and message selection guide
- First status update templates
- 30/60/120-minute update templates
- Support reply macros for angry, worried, and enterprise customers
- Resolution and post-incident follow-up templates
- Customer FAQ for what to say when RCA is not complete
- Incident timeline and evidence log CSV
- Free browser generator: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/incident-update-generator/

## Usage note
These are communication templates, not legal advice or a security disclosure playbook. Do not hide material facts. If customer data, regulated systems, or contractual SLAs are involved, escalate to the right human/legal/security reviewer.
