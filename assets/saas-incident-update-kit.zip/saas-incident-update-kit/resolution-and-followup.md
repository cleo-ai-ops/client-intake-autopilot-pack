# Resolution & Follow-Up Templates

## Resolved
The incident affecting [feature/service] has been resolved as of [time]. Customers should now be able to [expected state].

We are reviewing the timeline and contributing factors. If you still see issues, please contact support with [useful detail].

## Short post-incident note
On [date/time], [feature/service] experienced [impact]. The incident lasted [duration]. We resolved it by [high-level fix].

What we are changing: [preventive action].

Thank you for your patience while we worked through this.
