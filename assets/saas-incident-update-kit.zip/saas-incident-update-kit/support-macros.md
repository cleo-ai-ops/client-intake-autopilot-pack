# Support Macros

## Angry customer
You are right to be frustrated. We are actively working on the incident affecting [feature]. I do not want to guess at a fix time, but the next public update will be posted by [time]. I will also attach your ticket to the incident so we can follow up when it is resolved.

## Enterprise / stakeholder request
Current confirmed impact: [impact]. Current action: [action]. Next update: [time]. We will provide a post-incident summary once the incident is resolved and the timeline has been reviewed.

## Data concern
At this point, we have [confirmed/not confirmed] evidence of data loss or unauthorized access. We are treating the investigation carefully and will update you as soon as we have verified information.
