# 04 — Retainer Renewal Rate Email

Subject: Renewal options for [month/quarter]

Hi [Name],

Your current retainer renews on [date], so I wanted to send options early.

## Option 1 — Continue current support
Includes: [deliverables / response time / meetings]
New monthly rate: [new rate]

## Option 2 — Focused support
Includes: [reduced deliverables]
Monthly rate: [lower rate]

## Option 3 — Project-only
We pause the retainer and quote future work as fixed-scope projects.

My recommendation is Option [X] because [reason tied to their goals]. If you confirm by [date], I’ll reserve capacity for the next cycle.

Best,
[Your name]
