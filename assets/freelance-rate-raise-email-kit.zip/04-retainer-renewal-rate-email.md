# Retainer Renewal Rate Email

Subject: Retainer renewal for [month/quarter]

Hi [Name],

As we renew the retainer for [period], I’m updating the monthly fee to [new retainer].

The new retainer includes:
- [deliverable/support]
- [deliverable/support]
- [response time or meeting cadence]

This change would begin on [date]. If you’re happy to continue, I’ll send the renewal invoice/agreement.

If the new retainer is not the right fit, I can outline a lighter support option at [lower scope/fee].

Thanks,
[Your name]
