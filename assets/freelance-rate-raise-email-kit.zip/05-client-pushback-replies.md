# 05 — Client Pushback Replies

## “Can you keep the old rate?”
I understand the question. I’m not able to keep the old rate for the same scope after [date]. What I can do is reduce the scope to fit [old budget] or continue the current scope at [new rate].

## “This is too expensive.”
Totally fair if the new rate does not fit your budget. The best options are: narrow the scope to the highest-value work, schedule a final transition month, or pause until the budget matches the support needed.

## “We need approval.”
Of course. The key details for approval are: current scope, updated scope/rate, effective date, and business reason. I can hold capacity until [date]; after that I may need to release the slot.

## “Can we do one more month at the old price?”
I can do that only if we use it as a transition month with a reduced scope: [specific reduced scope]. The full scope moves to [new rate] from [date].

## “Another freelancer is cheaper.”
That may be the right choice if price is the main constraint. My rate reflects [specific value/process/reliability]. If you want to continue with that level of support, the new rate is [rate].

## “Why is it increasing?”
Because the work now requires [reason], and my current pricing has moved to match the level of value, demand, and responsibility involved. I wanted to give advance notice so you can decide cleanly.
