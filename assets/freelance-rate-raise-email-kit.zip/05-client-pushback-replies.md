# Client Pushback Replies

## “Can you keep the old rate?”
Thanks for asking. I’m not able to keep the previous rate for the current scope, but I can reduce the scope to match the old budget if that helps.

## “This is more than we expected.”
I understand. The reason I’m giving notice now is so you have time to decide. The options are the updated scope at [new rate], or a smaller scope at [current/lower budget].

## “Can we wait until next quarter?”
I can keep the current rate until [date]. After that, the updated rate would apply if we continue.

## “Another freelancer charges less.”
That makes sense. If budget is the main priority, they may be a better fit. If you’d like to continue with my approach and level of support, the updated rate is [rate].
