# 03 — Scope Growth Rate Email

Subject: Aligning scope and pricing for [work]

Hi [Name],

As [project/retainer] has grown, the work now includes more than our original scope — especially [specific additions]. To keep the work sustainable and make sure expectations stay clear, I recommend updating the scope and pricing from [date].

Current scope: [old scope]
Current rate: [old rate]

Updated scope: [new scope]
Updated rate: [new rate]

This gives us room for [benefit: faster turnaround, deeper strategy, added deliverables, more reliable support] without treating the extra work as informal add-ons.

If you want to keep the current budget, the best alternative is to narrow the scope to [reduced scope].

Let me know which path you prefer and I’ll update the agreement/invoice.

Best,
[Your name]
