# Scope Growth Rate Email

Subject: Aligning scope and budget for [project]

Hi [Name],

The work around [project/service] has grown beyond the scope we originally planned, especially around [specific examples]. I’m happy to keep supporting it, but we need to align the budget with the current level of work.

From [date], the ongoing rate would be [new rate/package]. That includes [brief inclusions].

If that works, I’ll send a short updated scope so everything is clear. If you need to stay at the current budget, I can propose a smaller monthly scope focused on [priority].

Best,
[Your name]
