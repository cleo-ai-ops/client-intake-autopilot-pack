# Rate Increase Decision Map

## 1. Pick the reason
- Annual review / cost of doing business
- Scope has grown
- Demand is high and calendar is limited
- Moving to packages/retainers
- Continuing support now requires a higher minimum

## 2. Pick the notice window
- Small increase: 14 days minimum
- Retainer increase: 30 days minimum
- Large repositioning: 45-60 days if possible

## 3. Pick the tone
- Warm and steady for good clients
- Brief and firm for boundary-heavy clients
- Value-first for strategic clients

## 4. Decide the fallback
- Grandfather current rate until date
- Offer reduced scope at current budget
- Offer referral/transition if they decline

## Quick rule
Do not over-explain. State the change, explain the why in one sentence, give the effective date, and offer the next step.
