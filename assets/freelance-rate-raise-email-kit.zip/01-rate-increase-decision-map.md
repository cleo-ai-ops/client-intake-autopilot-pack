# 01 — Rate Increase Decision Map

## Step 1: Choose the client type
- **A: Healthy client** — pays on time, respects scope, good relationship.
- **B: Scope-growth client** — originally small, now using more of your time/skill.
- **C: Legacy low-rate client** — good but below current floor.
- **D: Problem client** — late pay, scope creep, stressful communication.

## Step 2: Choose the move
| Client type | Recommended move | Notice | Tone |
|---|---|---:|---|
| A | Warm rate update | 30 days | appreciative, confident |
| B | Re-scope + rate update | before next work block | operational, specific |
| C | New floor + transition option | 30–60 days | clear, respectful |
| D | Increase sharply or sunset | immediate/new cycle | firm, brief |

## Step 3: Decide the amount
- If demand is strong and calendar is full: +20–40%.
- If correcting legacy pricing: move to current minimum, not a tiny apology raise.
- If scope expanded: price the new scope, not the old task list.
- If you are afraid to send it to every client, start with the clearest 3.

## Step 4: Offer options without discounting yourself
Good options:
- continue at new rate
- reduce scope to fit old budget
- book a final transition month
- move to project-based pricing

Bad options:
- “Pay whatever works”
- “I can keep the old rate if needed”
- apologizing for normal business pricing
