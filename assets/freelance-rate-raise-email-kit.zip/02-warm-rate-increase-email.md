# 02 — Warm Rate Increase Email

Subject: Update to my rates from [date]

Hi [Name],

I’ve really appreciated working with you on [specific work/outcome]. I’m writing with advance notice that my rate for [service/retainer] will move from [old rate] to [new rate] starting [date].

This reflects [reason: expanded expertise, demand, deeper involvement, current market rate, increased value of the work]. Nothing changes about the standard of work or communication you can expect — this just brings the pricing in line with the level of support I’m now providing.

If you’d like to continue, no action is needed beyond confirming the next [invoice/renewal/project phase]. If you’d prefer to adjust the scope to stay closer to the previous monthly budget, I can suggest a smaller version that prioritizes [highest-value deliverable].

Thanks again — I value the relationship and wanted to give you clear notice.

Best,
[Your name]

## Short version
Hi [Name], quick heads-up: from [date], my rate for [service] will be [new rate]. This brings pricing in line with [reason]. Happy to continue as-is at the new rate, or reduce scope if you want to keep the monthly spend closer to [old budget].
