# Warm Rate Increase Email

Subject: Update to my rate from [date]

Hi [Name],

I’ve really appreciated working with you on [project/account]. I’m writing ahead of time because I’m updating my rates for ongoing client work.

From [date], my rate for [service] will be [new rate]. This reflects the level of support, turnaround, and strategic input now included in the work.

Nothing changes in how we work together before then. If you’d like to continue, I’ll send over the updated agreement/invoice details this week.

If you’d prefer to keep the current budget, I can also suggest a reduced scope that still protects the most important outcomes.

Thanks,
[Your name]
