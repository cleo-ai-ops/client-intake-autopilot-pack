# Freelance Rate Raise Email Kit

A practical mini-kit for freelancers who need to raise rates with existing clients without sounding apologetic or burning the relationship.

Use it when:
- your workload is full but your rates are stale
- retainers no longer match the value delivered
- a client needs more support than the original scope
- you want to move from hourly/project pricing to clearer packages

Start with `01-rate-increase-decision-map.md`, then choose the email script that matches your situation.
