# Freelance Rate Raise Email Kit

Use this to raise rates without sounding apologetic, surprising good clients, or creating avoidable churn.

## 20-minute workflow
1. Read `01-rate-increase-decision-map.md` and choose the scenario.
2. Pick the matching email: warm client, scope growth, or retainer renewal.
3. Use `05-client-pushback-replies.md` for likely objections.
4. Log each client in `06-rate-change-tracker.csv`.

## Important principle
A rate increase is not a confession that you were undercharging. It is a business update tied to capacity, value, and clearer scope.

## Recommended notice
- Project work: before the next proposal or new phase.
- Retainers: 30–60 days before renewal.
- Legacy hourly clients: before the next billing cycle, with a clean transition option.
