---
name: Agent-ready feature task
about: A scoped feature brief for an AI coding agent
title: "[Feature]: "
labels: feature, agent-ready
---

## Goal

## User impact

## Files/areas likely involved

## Constraints / red lines

## Acceptance criteria
- [ ]

## Verification command
`...`
