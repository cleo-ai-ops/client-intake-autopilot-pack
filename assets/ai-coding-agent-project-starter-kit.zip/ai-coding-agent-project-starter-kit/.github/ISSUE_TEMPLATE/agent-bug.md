---
name: Agent-ready bug report
about: A clear bug task for an AI coding agent
title: "[Bug]: "
labels: bug, agent-ready
---

## Expected behavior

## Actual behavior

## Steps to reproduce
1.

## Suspected area

## Acceptance criteria
- [ ]

## Verification command
`...`
