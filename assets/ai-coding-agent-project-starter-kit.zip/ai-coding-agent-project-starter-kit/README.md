# AI Coding Agent Project Starter Kit

A practical project-control pack for developers using Claude Code, Cursor, Codex, OpenClaw, or other AI coding agents.

## Buyer hypothesis
Solo developers, indie hackers, and small engineering teams are increasingly handing real codebases to AI agents, but many projects lack clear instructions, repo rules, safety limits, handoff notes, and review checklists. They want copy-paste structure that reduces broken changes and context loss.

## What's inside
- `AGENTS.md` project instruction template
- `CLAUDE.md` / AI coding assistant context template
- Cursor rules / agent rules template
- Safe command policy for local agents
- Product requirements prompt pack
- Bugfix and refactor task briefs
- Pull request review checklist for AI-generated code
- Repository handoff checklist
- GitHub issue templates for agent-ready work
- Lightweight architecture decision record template

## Quick start
1. Copy `AGENTS.md` into your repo root.
2. Fill in stack, test commands, deployment rules, and red lines.
3. Add the GitHub issue templates under `.github/ISSUE_TEMPLATE/`.
4. Paste the task brief into your coding agent before major changes.
5. Use the PR checklist before merging AI-generated code.
