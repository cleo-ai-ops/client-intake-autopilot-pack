# AI Coding Agent Project Starter Kit

A practical operating system for developers using Claude Code, Cursor, Codex, OpenClaw, or other coding agents on real repositories.

## What's inside
- Project instruction templates: `AGENTS.md`, `CLAUDE.md`, Cursor rules
- Filled examples for `saas-nextjs`, `python-cli`, and `node-api`
- Agent task briefs for feature, bugfix, refactor, tests, and docs work
- `command-safety-matrix.md` with allow/ask/deny command guidance
- `pr-security-rubric.md` for reviewing AI-generated code
- `platform-onboarding.md` for Claude Code, Cursor, Codex, and OpenClaw
- `demo-repo-tree.md` showing exact file placement
- ADR, handoff, prompt, and PR checklist templates

## 20-minute setup
1. Copy `AGENTS.md` into your repo root.
2. Copy `command-safety-matrix.md` and `pr-security-rubric.md` into `docs/agent/`.
3. Add `CLAUDE.md` or `.cursor/rules/project-rules.mdc` only for tools you use.
4. Pick a task brief from `task-briefs/` and fill the goal/paths/acceptance criteria.
5. Ask the agent to inspect, plan, edit, verify, and stop at the listed red lines.

## Promise boundary
This pack reduces ambiguity and risk; it does not replace code review, security review, or production ownership. Treat agents as fast junior collaborators with strict operating rules.
