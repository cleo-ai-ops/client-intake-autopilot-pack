# Command safety matrix for coding agents

Use this policy to decide what an agent may run without interrupting you.

| Category | Examples | Default | Reason |
|---|---|---:|---|
| Read-only inspection | `ls`, `find`, `rg`, `cat`, `git diff`, `npm test -- --help` | Allow | Needed for context and reversible. |
| Local verification | `npm test`, `pytest`, `go test ./...`, `npm run typecheck` | Allow | Non-destructive proof of correctness. |
| Dependency install | `npm install`, `pip install`, `brew install` | Ask | Changes lockfiles/system and may use network. |
| File generation inside repo | codegen, docs build, migrations generation | Ask | Often reversible but can create noisy changes. |
| Database migrations | `prisma migrate deploy`, `rails db:migrate` | Ask | Can alter persistent data. |
| Deletion/cleanup | `rm -rf`, dropping tables, deleting buckets | Deny unless explicitly approved | High blast radius. |
| Secrets/auth | reading `.env`, printing tokens, changing IAM | Deny/ask with redaction | Protect credentials. |
| Deployment/release | `vercel --prod`, `kubectl apply`, package publish | Ask | External side effects. |
| Payments/billing | Stripe product edits, refunds, price changes | Deny unless human directs exact action | Financial impact. |

## Copy-paste rule for AGENTS.md
Agents may run read-only commands and local tests. They must ask before installing packages, changing lockfiles, running migrations, deploying, publishing, deleting data, or touching secrets. They must never print credentials.
