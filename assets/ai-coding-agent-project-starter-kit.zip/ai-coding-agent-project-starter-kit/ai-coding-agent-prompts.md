# AI Coding Agent Prompt Pack

## Feature implementation brief
You are implementing [feature]. First inspect the relevant files and identify the smallest safe change. Preserve existing patterns. Add/update tests if the repo has tests. Run [test command]. Summarize changed files and risks.

## Bugfix brief
Fix this bug: [bug]. Reproduce or identify likely cause before editing. Avoid broad refactors. Add a regression test if practical. Run [verification].

## Refactor brief
Refactor [area] to improve [goal] without changing behavior. Keep commits/checkpoints small. Run tests before and after if possible.

## Code review prompt
Review this diff for correctness, security, edge cases, test coverage, and unnecessary complexity. Prioritize issues that could break production.
