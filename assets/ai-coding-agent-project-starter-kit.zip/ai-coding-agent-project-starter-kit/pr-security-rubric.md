# PR and security review rubric for AI-generated code

## Correctness
- Does the change solve the requested problem and no larger one?
- Are edge cases handled: empty input, invalid auth, timeout, partial failure, retry?
- Are errors actionable for users/operators?

## Tests
- Is there at least one regression test for the changed behavior?
- Do tests fail without the change?
- Are mocks realistic enough to catch schema/contract drift?

## Security/data
- No secrets in code, logs, screenshots, fixtures, or test snapshots.
- Authz checks happen server-side, not only in UI.
- User input is validated before database writes, shell calls, and third-party API calls.
- PII is minimized in logs and analytics.
- File uploads have size/type limits and safe storage paths.

## Payments/billing
- Webhooks verify signatures.
- Price IDs and product IDs are environment variables.
- Subscription state changes are idempotent.
- Refund/cancel flows do not grant unintended access.

## Maintainability
- Small diff, clear naming, no unrelated rewrites.
- Existing project conventions followed.
- New dependencies are justified.
- Rollback path is obvious.

## Merge decision
- **Approve:** all high-risk checks pass and tests run.
- **Request changes:** correctness/security/test gap exists.
- **Escalate:** payment, auth, data deletion, production deployment, or unclear user impact.
