# Agent task brief: Improve structure while preserving behavior

## Goal
[Write one sentence. Example: Add CSV export for invoices from the billing page.]

## Repo context
- Stack: [Next.js / Python / Rails / etc.]
- Relevant files: [paths]
- Existing commands: [test/typecheck/lint]

## Constraints
- Keep the diff focused; do not redesign unrelated code.
- Follow `AGENTS.md` and `command-safety-matrix.md`.
- Ask before installs, migrations, deployments, or destructive commands.

## Acceptance criteria
- [ ] User-visible behavior works.
- [ ] Regression or coverage test added where practical.
- [ ] Error/empty/loading states considered.
- [ ] Security/privacy implications reviewed.
- [ ] Final answer includes files changed and verification run.

## Stop conditions
Stop and ask if the task requires credentials, production data, payment changes, deleting data, or an unclear product decision.
