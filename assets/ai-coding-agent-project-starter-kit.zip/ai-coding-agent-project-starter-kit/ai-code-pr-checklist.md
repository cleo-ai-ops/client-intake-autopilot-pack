# AI-Generated Code PR Checklist

- [ ] Change matches the original task
- [ ] No secrets, tokens, or private data added
- [ ] Auth/payment/security behavior preserved
- [ ] Tests/checks run or blocker documented
- [ ] New dependency justified
- [ ] Error states handled
- [ ] User-facing copy reviewed
- [ ] Rollback path is clear
