# Platform onboarding: Claude Code, Cursor, Codex, OpenClaw

## Universal setup
1. Add `AGENTS.md` to repo root.
2. Add tool-specific files only if you use that tool (`CLAUDE.md`, `.cursor/rules`, etc.).
3. Paste `command-safety-matrix.md` into your agent instructions or link to it.
4. Create one small issue using a task brief before asking for broad refactors.

## Claude Code
- Put persistent project rules in `CLAUDE.md` and repo rules in `AGENTS.md`.
- Start with: “Read AGENTS.md and CLAUDE.md, inspect the repo, then propose a plan before edits.”
- Ask Claude to run the smallest relevant test before final output.

## Cursor
- Put stable rules in `.cursor/rules/project-rules.mdc`.
- Keep rules short: stack, commands, red lines, code style, and review checklist.
- Use Composer/chat for task briefs; do not rely on vague “fix this whole app” prompts.

## Codex / terminal coding agents
- Require a plan for multi-file changes.
- Allow read-only and test commands; require approval for installs, migrations, deployment, and deletion.
- Ask for a final diff summary plus exact verification run.

## OpenClaw / autonomous agents
- Give a clear working directory, deliverable, and stop condition.
- Include external side-effect boundaries: no spending, no publishing, no deleting, no credential disclosure.
- Ask for artifacts and evidence, not progress updates.
