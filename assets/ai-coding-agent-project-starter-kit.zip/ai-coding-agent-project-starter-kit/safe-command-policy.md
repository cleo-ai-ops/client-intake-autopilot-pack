# Safe Command Policy for AI Coding Agents

## Usually safe
- Read files, grep/search, list directories
- Run tests, typechecks, linters, builds
- Start local dev servers only when needed

## Ask first
- Deleting files or branches
- Database migrations against non-local databases
- Changing auth, payment, or permission logic
- Installing new global tools

## Never without explicit approval
- Spending money or creating paid infrastructure
- Posting credentials or secrets
- Disabling security checks
- Force pushing shared branches
