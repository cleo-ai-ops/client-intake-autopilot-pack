# Repository Handoff Checklist

Fill this once per repo so AI agents and new contributors stop losing context.

- Product purpose:
- Main users:
- Critical flows:
- Local setup:
- Test commands:
- Deploy process:
- Environment variables, names only:
- Common failure modes:
- Files/directories to avoid touching casually:
- Where decisions are documented:
