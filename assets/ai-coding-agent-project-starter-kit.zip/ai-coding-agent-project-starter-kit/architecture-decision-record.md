# Architecture Decision Record

## Decision

## Context

## Options considered

## Consequences

## Revisit when
