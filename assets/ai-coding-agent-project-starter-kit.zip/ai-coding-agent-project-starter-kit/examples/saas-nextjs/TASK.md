# Example agent task for Next.js SaaS

Implement one small improvement: add validation and a regression test around a user input path. Before editing, inspect relevant files and propose a 3-step plan. After editing, run the smallest available verification command and summarize the diff.
