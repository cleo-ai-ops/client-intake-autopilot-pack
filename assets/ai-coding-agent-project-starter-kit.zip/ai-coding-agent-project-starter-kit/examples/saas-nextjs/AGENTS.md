# AGENTS.md — filled example for Next.js SaaS

## Project
Next.js SaaS example using AI agents for small, reviewable changes.

## Commands
- Install: ask before running dependency installs.
- Test: run the narrowest relevant test first, then full suite if available.
- Lint/typecheck: run if configured.

## Coding rules
- Prefer surgical edits over rewrites.
- Keep user data and secrets out of logs.
- Preserve public API behavior unless the task explicitly changes it.

## Red lines
- Do not deploy, publish, migrate production DBs, delete data, or touch billing without explicit human approval.
- Do not read or print `.env` values.
