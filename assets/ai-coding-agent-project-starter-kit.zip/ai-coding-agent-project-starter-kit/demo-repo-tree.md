# Demo repo tree and file placement

```text
my-saas-app/
  AGENTS.md                         # universal project rules
  CLAUDE.md                         # Claude-specific context
  .cursor/rules/project-rules.mdc   # Cursor-specific rules
  .github/ISSUE_TEMPLATE/
    agent-feature.md
    agent-bug.md
  docs/adr/
    0001-template.md
  docs/agent/
    command-safety-matrix.md
    pr-security-rubric.md
    repo-handoff-checklist.md
```

## Minimum useful install
If you only copy three files, copy:
1. `AGENTS.md`
2. `command-safety-matrix.md`
3. `pr-security-rubric.md`

Then add one task brief from `task-briefs/` for each agent job.
