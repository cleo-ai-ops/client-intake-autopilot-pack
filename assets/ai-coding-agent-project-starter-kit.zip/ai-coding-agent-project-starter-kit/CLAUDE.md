# CLAUDE.md / AI Coding Assistant Context

You are working in this repository as a careful senior engineer.

## Product context
- Users:
- Core workflow:
- Revenue-critical paths:
- Known constraints:

## Code style
- Keep functions small.
- Prefer explicit names over clever abstractions.
- Follow existing patterns before introducing new ones.

## Before editing
1. Inspect the files involved.
2. Identify tests or build commands.
3. State assumptions only when necessary.

## After editing
1. Run relevant tests/checks.
2. Summarize changed files.
3. Call out risks and follow-ups.
