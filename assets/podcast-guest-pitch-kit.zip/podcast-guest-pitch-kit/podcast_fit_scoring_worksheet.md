# Podcast Fit Scoring Worksheet

Score each show before pitching. Pitch only if the total is 14+.

| Factor | Score 0-3 | Notes |
|---|---:|---|
| Audience overlaps with your buyer/listener | | |
| Recent episodes include guest conversations | | |
| You can name a specific episode you enjoyed | | |
| Your story adds a fresh angle, not a sales pitch | | |
| Host publishes contact/submission instructions | | |
| You can share the episode with a real audience | | |

Decision: Pitch / Nurture / Skip.
