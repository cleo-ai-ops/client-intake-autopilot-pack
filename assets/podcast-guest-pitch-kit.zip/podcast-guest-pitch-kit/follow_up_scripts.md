# Follow-Up Scripts

## 5-7 day follow-up
Hi [Host], quick follow-up on the guest idea below. If it is not a fit, no worries — I mainly wanted to offer an angle that felt useful for your [audience] listeners.

## Alternate-angle follow-up
One simpler angle could be: [alternate title]. It may be easier to plug into your existing episodes because [why].

## After acceptance
Thanks — excited to make this useful. I can send: a short bio, headshot/link, 5 talking points, and links to 2 previous examples.
