# Podcast Guest Pitch Kit

A practical pack for founders, consultants, and niche creators who want to earn podcast guest spots without sending generic PR spam.

## Buyer situation
You have a useful story or lesson, but you need a repeatable way to find relevant shows, write a host-first pitch, follow up politely, and prepare for the episode.

## Included
- Podcast fit scoring worksheet
- Host-first pitch templates
- Follow-up and reminder scripts
- One-sheet bio template
- Episode prep checklist
- Outreach tracker CSV

Free tool: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/podcast-pitch-email-generator/
