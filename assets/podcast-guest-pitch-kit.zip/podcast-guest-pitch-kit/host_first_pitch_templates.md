# Host-First Pitch Templates

## Template 1: Useful episode angle
Subject: Guest idea for [Podcast]: [specific outcome]

Hi [Host],

I listened to your episode with [Guest/Topic] and liked the part about [specific note].

A possible episode angle for your audience: **[angle]** — how [audience] can [specific result] without [common bad approach].

I can bring:
1. [specific lesson/story]
2. [concrete framework]
3. [mistake or contrarian point]

No pressure if it is not a fit. If useful, I can send a short one-sheet and 3 sample talking points.

Best,
[Name]

## Template 2: Founder lesson
Subject: Potential guest: what we learned from [specific experience]

Hi [Host],

Your show seems to care about practical, non-fluffy lessons for [audience]. I could share a grounded breakdown of [experience], including what worked, what failed, and what I would do differently.

Suggested title: [title]
Audience takeaway: [takeaway]

Would this be worth a short look?
