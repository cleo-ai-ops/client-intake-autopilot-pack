# Episode Prep Checklist

- Re-listen to one recent episode and note host style.
- Prepare 3 stories, each under 2 minutes.
- Prepare one practical framework listeners can use immediately.
- Write a non-pushy call-to-action.
- Confirm recording time, timezone, software, mic, and backup contact.
- After recording: send thank-you, links, and promo assets.
