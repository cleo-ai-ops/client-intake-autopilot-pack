# Guest One-Sheet Template

**Name:** [Name]
**Short bio:** [2 sentences]
**Audience fit:** I help [audience] with [problem].
**Suggested episode titles:**
- [Title 1]
- [Title 2]
- [Title 3]

**Talking points:**
1. [Specific story]
2. [Framework]
3. [Practical checklist]
4. [Common mistake]
5. [Takeaway]

**Links:** website, LinkedIn, previous interviews, social proof.
