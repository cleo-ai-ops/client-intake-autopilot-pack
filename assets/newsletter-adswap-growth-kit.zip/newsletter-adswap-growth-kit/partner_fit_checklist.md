# Partner Fit Checklist

Score each potential swap partner from 0-2 on each line. Prioritize 8+ scores.

- Audience overlap: same buyer/reader problem, not merely same broad topic
- Similar list size: within roughly 0.5x-3x of your list
- Trust fit: their tone would not confuse your readers
- Offer clarity: both newsletters can describe why readers should subscribe
- Placement quality: comparable location in email, not buried at the bottom
- Measurement path: both sides can track clicks/subscribers

Red flags: scraped lists, unclear audience, generic crypto/AI/business blasts, no past issues visible, or a partner who refuses basic placement details.
