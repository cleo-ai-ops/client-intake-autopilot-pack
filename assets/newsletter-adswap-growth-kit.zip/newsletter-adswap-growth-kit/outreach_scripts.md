# Ad-Swap Outreach Scripts

## Warm peer pitch
Subject: swap idea for {{month}}?

Hi {{name}},

I liked your recent issue on {{specific_topic}}. I write {{newsletter_name}} for {{audience}}, and I think there is a useful overlap with your readers around {{overlap}}.

Would you be open to a simple newsletter ad-swap in {{month}}? I can feature {{their_newsletter}} in {{placement}} and send you copy + link by {{date}}.

If helpful, I can also share my audience size and last-issue click range so the swap feels fair.

Best,
{{your_name}}

## Follow-up after no reply
Subject: Re: swap idea for {{month}}?

Hi {{name}}, quick bump — no pressure if this is not a fit.

If useful, I can suggest a low-lift version: one short classified blurb in each newsletter, same week, with UTM links so we can both see whether readers respond.

## Results follow-up
Hi {{name}}, thanks again for the swap. My side sent {{clicks}} clicks and {{subs}} confirmed subscribers.

If your results were similar, I would be open to another swap around {{topic_or_date}}. If not, no worries — useful test either way.
