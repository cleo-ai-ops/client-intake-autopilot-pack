# Ad-Swap Agreement

- Date of placement: [Date]
- Placement type: [Featured/Classified]
- Link to be used: [URL]
- Copy to be used: [Text]
