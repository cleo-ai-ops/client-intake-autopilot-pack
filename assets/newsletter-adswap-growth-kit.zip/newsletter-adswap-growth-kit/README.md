# Newsletter Ad-Swap & Growth Kit

A practical ad-swap system for newsletter writers with small, specific audiences who want subscriber growth without paid ads.

## Buyer hypothesis
Newsletter writers, solo creators, and niche media operators often know peer newsletters but avoid outreach because swaps feel vague and hard to track. A compact system with scripts, fit rules, a tracker, and simple metrics can help them run 3-5 partner swaps this month.

## What's included
- Partner-fit checklist so swaps are audience-aligned, not random
- Outreach scripts for warm, peer, and cold partner asks
- Ad copy templates for classified, sponsor-style, and dedicated swap blurbs
- Swap calendar and tracking CSV
- Follow-up and results-review scripts
- Mini playbook for avoiding mismatched or low-quality swaps

Free tool: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/newsletter-adswap-outreach-generator/
Paid page: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/newsletter-adswap-growth-kit/
