# Ad Copy Templates

## Classified blurb
{{Newsletter}} helps {{audience}} solve {{problem}} with {{format}} every {{frequency}}. If you want {{outcome}}, subscribe here: {{link}}

## Sponsor-style blurb
This week's reader recommendation is {{Newsletter}}, a practical newsletter for {{audience}}. Start with their issue on {{specific_issue}} if you care about {{reader_problem}}: {{link}}

## Dedicated swap intro
I only share newsletters when I think they are genuinely useful for this audience. {{Newsletter}} is worth checking out if you are working on {{topic}} because {{reason}}.
