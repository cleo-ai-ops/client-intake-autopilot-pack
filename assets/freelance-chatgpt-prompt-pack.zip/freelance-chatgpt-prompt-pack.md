# ChatGPT Prompt Pack for Freelancers
## 50+ Ready-to-Use Prompts

---

# Category 1: Client Acquisition

## Prompt 1: Cold Outreach Email
```
You are a professional freelancer specializing in [YOUR NICHE]. Write a cold outreach email to a potential client in the [TARGET INDUSTRY] industry.

Context:
- My name: [YOUR NAME]
- My specific expertise: [YOUR EXPERTISE]
- Their company: [COMPANY NAME]
- What I noticed about their business: [OBSERVATION]
- The specific problem I can solve: [PROBLEM]

Requirements:
- Keep it under 150 words
- Lead with the problem, not my credentials
- Include one specific example of how I've solved this before
- End with a clear, low-pressure call to action
- Tone: professional but conversational, not salesy
- Do NOT use phrases like "I hope this email finds you well" or "synergy"
```

## Prompt 2: Follow-Up Email (No Reply)
```
Write a follow-up email to a cold outreach I sent [NUMBER] days ago. The original email was about [TOPIC].

Context:
- Recipient's name: [NAME]
- Their role: [ROLE]
- My original value proposition: [VALUE PROP]

Requirements:
- Acknowledge they're busy
- Add one new piece of value (a relevant insight, stat, or resource)
- Keep it under 100 words
- Make the CTA easier than the first email (e.g., "worth a quick reply?")
- Tone: warm, not desperate
```

## Prompt 3: LinkedIn Connection Message
```
Write a LinkedIn connection request message for a [TARGET ROLE] at a [INDUSTRY] company.

Context:
- Why I want to connect: [REASON]
- Shared connection or interest: [COMMONALITY]
- My niche: [YOUR NICHE]

Requirements:
- Under 300 characters (LinkedIn limit)
- Reference something specific from their profile or company
- No pitch — just a genuine reason to connect
- Tone: friendly and curious
```

## Prompt 4: Referral Request Email
```
Write an email to a past client asking for referrals.

Context:
- Client's name: [NAME]
- Project we completed: [PROJECT DESCRIPTION]
- Result or impact: [RESULT]
- My ideal next client: [IDEAL CLIENT DESCRIPTION]
- My niche: [YOUR NICHE]

Requirements:
- Start with genuine appreciation for the past project
- Be specific about the type of client I'm looking for
- Make it easy: offer a short blurb they can forward
- Include a soft incentive (discount, bonus, or priority booking)
- Keep it under 200 words
- Tone: warm, grateful, not transactional
```

## Prompt 5: Upwork/Freelance Platform Proposal
```
Write a proposal for this freelance platform job posting:

JOB POSTING:
[PASTE JOB POSTING HERE]

MY QUALIFICATIONS:
- Years of experience: [YEARS]
- Relevant projects: [BRIEF DESCRIPTIONS]
- My unique approach: [WHAT MAKES YOU DIFFERENT]

Requirements:
- First sentence must directly address their biggest pain point
- Show I read the entire posting (reference specific details)
- Include 2-3 relevant examples, not generic claims
- Propose a clear next step (call, sample, or specific question)
- Keep it under 250 words
- Tone: confident and specific, not desperate or generic
```

## Prompt 6: Networking Event Follow-Up
```
Write a follow-up email to someone I met at [EVENT NAME].

Context:
- Their name: [NAME]
- Their role: [ROLE]
- What we discussed: [TOPIC]
- Something specific I found interesting: [DETAIL]
- How I might help them: [OFFER]

Requirements:
- Reference our specific conversation (not generic)
- Offer value before asking for anything
- Suggest a concrete next step (coffee, call, resource share)
- Keep it under 150 words
- Tone: genuine and professional
```

## Prompt 7: Guest Post / Collaboration Pitch
```
Write a pitch email to propose a guest post or content collaboration with [TARGET WEBSITE/PUBLICATION].

Context:
- Their audience: [AUDIENCE DESCRIPTION]
- My expertise: [YOUR EXPERTISE]
- Proposed topic: [TOPIC]
- Why this topic fits their audience: [REASON]
- My credentials: [BRIEF CREDENTIALS]

Requirements:
- Lead with why this benefits THEIR audience
- Include a working title and 3-4 bullet points of what the piece would cover
- Reference 1-2 of their existing pieces and how mine extends the conversation
- Keep it under 200 words
- Tone: respectful of their time and editorial standards
```

## Prompt 8: Partnership Outreach
```
Write an outreach email proposing a partnership with a complementary service provider.

Context:
- Their service: [THEIR SERVICE]
- My service: [YOUR SERVICE]
- How our services complement: [OVERLAP]
- Potential joint offering: [IDEA]
- Their audience: [AUDIENCE]

Requirements:
- Focus on mutual benefit, not just what I get
- Propose something specific and actionable
- Include a clear, low-commitment next step
- Keep it under 200 words
- Tone: collaborative and professional
```

---

# Category 2: Discovery & Intake

## Prompt 9: Client Intake Questionnaire
```
Create a client intake questionnaire for a [YOUR NICHE] freelancer.

Context:
- My services: [SERVICES]
- Typical project size: [SIZE/DURATION]
- Common client types: [CLIENT TYPES]
- Key info I need before starting: [WHAT YOU NEED]

Requirements:
- Maximum 10 questions
- Mix of multiple choice, short answer, and one open-ended question
- Include questions about budget range, timeline, and decision-making process
- Order from easy to more detailed questions
- Add a friendly intro paragraph explaining why I'm asking
```

## Prompt 10: Discovery Call Script
```
Write a discovery call script/outline for a [YOUR NICHE] freelancer meeting with a potential [CLIENT TYPE] client.

Context:
- My services: [SERVICES]
- Typical problems clients come to me with: [COMMON PROBLEMS]
- What I need to learn on the call: [KEY QUESTIONS]
- My process after the call: [NEXT STEPS]

Requirements:
- Structure: 1) Rapport building (2 min) 2) Their situation (10 min) 3) Their goals (5 min) 4) My approach overview (5 min) 5) Next steps (3 min)
- Include specific questions to ask at each stage
- Add transition phrases between sections
- Include a section on how to handle "what's your rate?" if asked early
- Add red flags to watch for during the call
```

## Prompt 11: Project Brief Template
```
Create a project brief template for a [PROJECT TYPE] project.

Context:
- Client industry: [INDUSTRY]
- Typical deliverables: [DELIVERABLES]
- Project duration: [DURATION]
- Key stakeholders: [WHO'S INVOLVED]

Requirements:
- Sections: Background, Objectives, Scope, Deliverables, Timeline, Budget, Success Metrics, Communication Plan
- Each section should have 2-3 guiding questions
- Include a sign-off section for client approval
- Keep it to 1-2 pages when filled
```

## Prompt 12: Scope Confirmation Email
```
Write an email confirming the project scope after a discovery call.

Context:
- Client name: [NAME]
- Project: [PROJECT DESCRIPTION]
- What was agreed on the call: [AGREED ITEMS]
- What was explicitly excluded: [EXCLUSIONS]
- Next steps: [NEXT STEPS]

Requirements:
- Restate the scope clearly with bullet points
- Explicitly state what's NOT included (to prevent scope creep)
- Confirm timeline and next steps
- Ask them to reply confirming or flagging any changes
- Keep it professional but warm
```

## Prompt 13: Client Onboarding Welcome Email
```
Write a client onboarding/welcome email for a new [PROJECT TYPE] client.

Context:
- Client name: [NAME]
- Project: [PROJECT]
- Start date: [DATE]
- What I need from them to begin: [REQUIREMENTS]
- How we'll communicate: [TOOLS/FREQUENCY]

Requirements:
- Express genuine excitement about the project
- Clearly list what I need from them (with deadlines for each)
- Explain how the project will progress (brief timeline)
- Set communication expectations (response times, preferred channels)
- Include a "first milestone" they can look forward to
```

## Prompt 14: Pre-Project Questionnaire for Specific Deliverable
```
Create a pre-project questionnaire for a client who wants [SPECIFIC DELIVERABLE].

Context:
- Deliverable: [DELIVERABLE]
- Client's industry: [INDUSTRY]
- What I need to know to start: [KEY REQUIREMENTS]
- Common issues with this type of project: [KNOWN ISSUES]

Requirements:
- 8-12 questions specific to this deliverable
- Include brand/voice questions
- Include technical requirements questions
- Add a "anything else?" open-ended final question
- Order from general to specific
```

## Prompt 15: Competitor Research Brief
```
Create a brief for researching a client's competitors as part of a [PROJECT TYPE] project.

Context:
- Client's business: [BUSINESS DESCRIPTION]
- Their industry: [INDUSTRY]
- Known competitors: [COMPETITORS]
- What the client wants to understand: [RESEARCH GOALS]

Requirements:
- List 5 key areas to analyze for each competitor
- Include what to look for in their messaging, pricing, and positioning
- Provide a simple scoring/rating framework
- Include a summary template for presenting findings to the client
```

---

# Category 3: Pricing & Proposals

## Prompt 16: Value-Based Pricing Breakdown
```
Help me calculate a value-based price for a [PROJECT TYPE] project.

Context:
- What the client's business does: [BUSINESS]
- The problem I'm solving: [PROBLEM]
- How much this problem costs them (estimate): [COST OF PROBLEM]
- Expected outcome of my work: [OUTCOME]
- Estimated value of that outcome: [VALUE]
- My time estimate: [HOURS]
- My minimum hourly rate: [RATE]

Requirements:
- Show me 3 pricing tiers (basic, recommended, premium)
- Each tier should be justified by the value it delivers, not my time
- The recommended tier should be the obvious best choice
- Include what's in each tier and what's excluded
- Calculate the ROI the client gets at each tier
```

## Prompt 17: Proposal Email
```
Write a proposal email for a [PROJECT TYPE] project.

Context:
- Client name: [NAME]
- Their problem: [PROBLEM]
- My proposed solution: [SOLUTION]
- Investment: [PRICE]
- Timeline: [TIMELINE]
- Key deliverables: [DELIVERABLES]
- What makes my approach different: [DIFFERENTIATOR]

Requirements:
- Structure: 1) Recap their situation 2) Proposed solution 3) Investment and ROI 4) Process and timeline 5) Next step
- Focus on outcomes and value, not features and hours
- Include one relevant case study or example
- Make the CTA clear and time-bound
- Keep the entire email under 400 words
```

## Prompt 18: Rate Increase Email to Existing Client
```
Write an email informing an existing client of a rate increase.

Context:
- Client name: [NAME]
- Current rate: [CURRENT RATE]
- New rate: [NEW RATE]
- When it takes effect: [DATE]
- Reason: [REASON — e.g., increased scope, market rates, added expertise]
- How long we've worked together: [DURATION]

Requirements:
- Frame it positively (not apologetic)
- Reference the value I've delivered and will continue to deliver
- Give at least 30 days notice
- Grandfather current projects at the old rate
- Offer to discuss if they have concerns
- Tone: confident, professional, warm
```

## Prompt 19: "Your Rate Is Too High" Response
```
Write a response to a client who said my rate is too high.

Context:
- Client's objection: [EXACT WORDS IF POSSIBLE]
- My quoted rate: [RATE]
- The value I provide: [VALUE]
- What cheaper alternatives typically deliver: [MARKET CONTEXT]
- My minimum acceptable rate: [MINIMUM]

Requirements:
- Acknowledge their concern without being defensive
- Reframe from cost to value/ROI
- If room to negotiate, offer alternatives (reduced scope, phased approach, payment plan) NOT a lower rate for the same work
- If no room, politely stand firm and explain why
- End with a clear next step
- Keep it under 200 words
```

## Prompt 20: Project Pricing Calculator
```
Help me estimate the total project price for [PROJECT DESCRIPTION].

Context:
- Estimated hours: [HOURS]
- My target hourly rate: [RATE]
- Client's budget range (if known): [BUDGET]
- Project complexity (1-10): [COMPLEXITY]
- Rush timeline: [YES/NO]
- Revisions expected: [NUMBER]
- Project type: [TYPE]

Requirements:
- Calculate a base price from hours × rate
- Add a complexity multiplier (1.0 to 1.5)
- Add a rush fee if applicable (15-25%)
- Add a revision buffer (10-20%)
- Present as a single project fee, not hourly
- Show me the math so I can explain it if asked
- Suggest a "walk away" minimum price
```

## Prompt 21: Tiered Pricing Proposal
```
Create a 3-tier pricing proposal for [SERVICE DESCRIPTION].

Context:
- What I offer: [CORE SERVICE]
- My ideal scope: [IDEAL SCOPE]
- What I could remove for a lower tier: [REDUCED SCOPE]
- What I could add for a premium tier: [PREMIUM ADDITIONS]
- Target price range: [RANGE]

Requirements:
- Name each tier creatively (not "basic/pro/enterprise")
- The middle tier should be the recommended one
- Each tier should have 4-6 clear bullet points
- Show the price per deliverable, not per hour
- Include a "most popular" or "recommended" badge on the middle tier
```

## Prompt 22: Retainer Proposal
```
Write a retainer proposal for a client who wants ongoing [SERVICE TYPE] support.

Context:
- Client's ongoing needs: [NEEDS]
- Estimated monthly hours: [HOURS]
- My monthly retainer rate: [RATE]
- What's included: [INCLUDED]
- What's not included: [EXCLUDED]
- Communication expectations: [COMMS]

Requirements:
- Explain the retainer value vs. project-based pricing
- Define scope boundaries clearly
- Include how extra work beyond retainer is handled
- Set a minimum commitment period (e.g., 3 months)
- Include a monthly review/adjustment clause
- Present as an investment in consistency and priority
```

## Prompt 23: Payment Terms Email
```
Write an email outlining payment terms for a new project.

Context:
- Total project fee: [FEE]
- Payment structure: [e.g., 50% upfront, 50% on completion]
- Payment methods accepted: [METHODS]
- Late payment policy: [POLICY]
- Client name: [NAME]

Requirements:
- Be clear and professional, not apologetic about asking for money
- Explain the payment milestones and what triggers each payment
- Include when and how invoices will be sent
- Mention late payment terms matter-of-factly
- Keep it brief — this is operational, not a negotiation
```

---

# Category 4: Scope Management

## Prompt 24: Scope Definition Document
```
Create a scope definition document for a [PROJECT TYPE] project.

Context:
- Client: [CLIENT DESCRIPTION]
- Project goal: [GOAL]
- Key deliverables: [DELIVERABLES]
- Known constraints: [CONSTRAINTS]

Requirements:
- Sections: Project Overview, In Scope (with details), Out of Scope (explicit), Assumptions, Dependencies, Change Request Process
- The "Out of Scope" section should list at least 5 common things people might assume are included
- The Change Request Process should explain how scope changes are priced and approved
- Use clear, non-technical language the client can sign off on
```

## Prompt 25: Scope Creep Pushback Email (Gentle)
```
Write a gentle but firm email pushing back on scope creep.

Context:
- Client name: [NAME]
- Original agreed scope: [SCOPE]
- What they're asking for now: [NEW REQUEST]
- How far along the project is: [PROGRESS]
- My relationship with them: [RELATIONSHIP STATUS]

Requirements:
- Acknowledge the request positively first
- Explain that this is beyond the agreed scope (reference the original agreement)
- Offer two options: 1) Handle it as a change request with additional cost/timeline, or 2) Include it in a future phase
- Do NOT say "that's not my job" or "you didn't pay for that"
- Keep it warm — this is a collaboration, not a confrontation
- Under 200 words
```

## Prompt 26: Change Request Template
```
Create a change request form for freelance projects.

Context:
- My services: [SERVICES]
- How I handle out-of-scope work: [APPROACH]
- Typical additional cost range: [RANGE]

Requirements:
- Fields: Change description, Reason for change, Impact on timeline, Impact on budget, Client approval (signature/date)
- Include a brief explanation of my change request process
- Keep it to one page
- Make it clear that work doesn't start until the change request is approved
```

## Prompt 27: Project Completion & Handoff Email
```
Write a project completion and handoff email.

Context:
- Client name: [NAME]
- Project: [PROJECT]
- Final deliverables: [DELIVERABLES]
- Where assets are located: [LOCATION]
- Any remaining items: [REMAINING]
- Warranty/support period: [SUPPORT]

Requirements:
- Celebrate the completion
- List all deliverables clearly
- Explain where everything is and how to access it
- Outline any remaining items with deadlines
- Explain post-project support terms
- Ask for feedback and/or a testimonial
- Suggest next steps or additional services if relevant
```

## Prompt 28: Project Check-In Email
```
Write a weekly project check-in email.

Context:
- Client name: [NAME]
- Project: [PROJECT]
- This week's completed tasks: [COMPLETED]
- Next week's planned tasks: [PLANNED]
- Any blockers or questions: [BLOCKERS]
- Overall progress: [X]% complete

Requirements:
- Keep it scannable — use bullet points
- Lead with progress, not problems
- If there are blockers, propose solutions not just complaints
- Include a clear "what I need from you" section if applicable
- Keep it under 200 words
- Tone: professional, proactive, confident
```

## Prompt 29: Project Delay Notification
```
Write an email notifying a client of a project delay.

Context:
- Client name: [NAME]
- Project: [PROJECT]
- What's delayed: [DELAYED ITEM]
- Reason: [REASON]
- New expected completion: [NEW DATE]
- Impact on overall timeline: [IMPACT]

Requirements:
- Own the delay without over-apologizing
- Explain the reason briefly and honestly
- Present the new timeline clearly
- Explain what I'm doing to prevent further delays
- Offer something to offset the inconvenience if appropriate
- Keep it under 200 words
```

## Prompt 30: Scope Extension Proposal
```
Write an email proposing a scope extension mid-project.

Context:
- Client name: [NAME]
- Current project: [PROJECT]
- Additional work identified: [ADDITIONAL WORK]
- Why it makes sense to do it now: [REASON]
- Estimated additional cost: [COST]
- Impact on timeline: [TIMELINE IMPACT]

Requirements:
- Frame it as an opportunity, not an upsell
- Explain why doing this now is better than later
- Be transparent about cost and timeline impact
- Make it easy to say yes or no
- Keep it under 200 words
```

---

# Category 5: Client Communication

## Prompt 31: Weekly Progress Report
```
Create a weekly progress report template for [PROJECT TYPE] projects.

Context:
- Client's communication style: [STYLE]
- Key metrics they care about: [METRICS]
- Reporting cadence: weekly
- Project management tool: [TOOL]

Requirements:
- Sections: Summary, Completed This Week, In Progress, Blocked/At Risk, Next Week Preview, Action Items for Client
- Use bullet points — no paragraphs
- Include a traffic light status (green/yellow/red) for overall project health
- Keep it under one page
- Include a "reply with questions" CTA
```

## Prompt 32: Difficult Client Conversation Email
```
Write an email addressing a difficult situation with a client.

Context:
- Client name: [NAME]
- The situation: [SITUATION — e.g., they're consistently late providing feedback, they're rude in communications, they're asking for free work]
- How long we've worked together: [DURATION]
- My desired outcome: [DESIRED OUTCOME]
- My boundary: [BOUNDARY]

Requirements:
- Be direct but not confrontational
- Use "I" statements, not "you" accusations
- State the impact of the situation on the project
- Propose a clear solution
- Be willing to walk away if boundaries aren't respected
- Under 250 words
```

## Prompt 33: Delivering Bad News
```
Write an email delivering bad news to a client about their project.

Context:
- Client name: [NAME]
- The bad news: [NEWS — e.g., a feature can't be delivered, a deadline will be missed, a third-party integration failed]
- Impact on the project: [IMPACT]
- My proposed solution: [SOLUTION]
- Alternative options: [ALTERNATIVES]

Requirements:
- Lead with the news — don't bury it
- Explain what happened without making excuses
- Present the solution before the client asks "so what now?"
- If it's my fault, take responsibility briefly and move to the fix
- Keep it under 250 words
```

## Prompt 34: Testimonial Request Email
```
Write an email asking a past client for a testimonial.

Context:
- Client name: [NAME]
- Project completed: [PROJECT]
- Project outcome: [OUTCOME]
- Time since project: [TIME]
- Where the testimonial will be used: [PLATFORM]

Requirements:
- Start with genuine appreciation for the working relationship
- Reference the specific project and its success
- Make the ask easy — offer to draft something they can edit
- Give them an out (no pressure)
- Keep it under 150 words
- Include a suggested testimonial format or questions they can answer
```

## Prompt 35: Referral Thank You Email
```
Write a thank-you email for a client who referred me to someone.

Context:
- Client name: [NAME]
- Who they referred: [REFERRAL NAME]
- The referral's project need: [NEED]
- My thank-you gesture: [GESTURE — discount, gift card, etc.]

Requirements:
- Express genuine gratitude
- Acknowledge that referrals are the highest compliment
- Let them know the outcome (or that I'll follow up)
- If offering a thank-you gesture, mention it naturally
- Keep it under 150 words
```

## Prompt 36: Re-Engagement Email (Cold Client)
```
Write an email to re-engage a past client I haven't heard from in a while.

Context:
- Client name: [NAME]
- Last project: [PROJECT]
- Time since last contact: [TIME]
- New offering or update: [UPDATE]
- Why I think they'd be interested: [REASON]

Requirements:
- Don't be pushy or desperate
- Lead with value — share something genuinely useful
- Briefly mention the new offering as context, not a hard pitch
- Ask a simple question to restart the conversation
- Keep it under 150 words
- Tone: warm, like reaching out to an old colleague
```

## Prompt 37: Conflict Resolution Email
```
Write an email to resolve a disagreement or conflict with a client.

Context:
- Client name: [NAME]
- The disagreement: [ISSUE]
- My perspective: [YOUR SIDE]
- Their perspective: [THEIR SIDE — if known]
- My ideal resolution: [RESOLUTION]
- What I'm willing to compromise on: [COMPROMISE]

Requirements:
- Acknowledge their perspective first
- State my perspective calmly and factually
- Focus on the project outcome, not who's "right"
- Propose a specific resolution
- Be willing to compromise on something
- Keep it under 300 words
```

## Prompt 38: Post-Project Feedback Request
```
Write a post-project feedback request email.

Context:
- Client name: [NAME]
- Project: [PROJECT]
- What went well: [SUCCESSES]
- What could have been better: [AREAS FOR IMPROVEMENT]

Requirements:
- Frame it as wanting to improve my service
- Ask 3-5 specific questions (not just "how was it?")
- Make it clear their honest feedback helps me get better
- Offer a quick option (reply with 1-2 sentences) or a longer option
- Keep it under 200 words
```

---

# Category 6: Marketing & Content

## Prompt 39: Case Study from Completed Project
```
Write a case study from a completed freelance project.

Context:
- Client industry: [INDUSTRY]
- Problem they had: [PROBLEM]
- My approach: [APPROACH]
- Solution delivered: [SOLUTION]
- Results/outcomes: [RESULTS]
- Timeline: [TIMELINE]

Requirements:
- Structure: Challenge → Approach → Solution → Results
- Write in third person about "the client" (anonymize if needed)
- Include specific numbers or metrics where possible
- Keep it under 500 words
- End with a soft CTA related to my services
- Tone: professional and results-focused
```

## Prompt 40: Blog Post Idea Generator
```
Generate 10 blog post ideas for a [YOUR NICHE] freelancer.

Context:
- My expertise: [EXPERTISE]
- My target client: [TARGET CLIENT]
- Common questions I get: [QUESTIONS]
- Industry trends I'm seeing: [TRENDS]
- Content goal: [GOAL — SEO, thought leadership, client education]

Requirements:
- Each idea should include: Working title, target keyword, brief outline (3-5 points)
- Mix of how-to, opinion, and case study formats
- At least 3 should address common client objections
- Include search intent for each (informational, commercial, etc.)
```

## Prompt 41: Social Media Content Calendar
```
Create a one-week social media content calendar for a [NICHE] freelancer.

Context:
- Platforms: [PLATFORMS]
- My voice: [VOICE — e.g., witty, authoritative, educational]
- Key message this week: [MESSAGE]
- Content pillars: [PILLARS — e.g., education, behind-the-scenes, social proof, tips]

Requirements:
- One post per day for each platform
- Each post: hook (first line), body, CTA, suggested hashtags
- Mix of formats: tips, questions, stories, carousels, threads
- Include one engagement-focused post (not promotional)
- Include one soft promotional post
```

## Prompt 42: Newsletter Content
```
Write a newsletter issue for my freelance business subscribers.

Context:
- My niche: [NICHE]
- This month's topic: [TOPIC]
- Key insight to share: [INSIGHT]
- Something I learned recently: [LEARNING]
- A resource to recommend: [RESOURCE]

Requirements:
- Structure: Personal opener → Main insight → Practical tip → Resource → Soft CTA
- Write in first person, conversational tone
- Include one actionable takeaway the reader can implement today
- Keep the main content under 400 words
- End with a question that encourages replies
```

## Prompt 43: Portfolio Project Description
```
Write a portfolio project description for my website.

Context:
- Project type: [TYPE]
- Client industry: [INDUSTRY]
- Problem: [PROBLEM]
- My role: [ROLE]
- Deliverables: [DELIVERABLES]
- Results: [RESULTS]
- Tools used: [TOOLS]

Requirements:
- Start with a one-sentence summary
- Include: Challenge, Solution, Results format
- Use specific numbers where possible
- Keep it under 200 words
- End with what I'd do differently (shows growth mindset)
```

## Prompt 44: Service Page Copy
```
Write website copy for a service page offering [SERVICE].

Context:
- Service: [DETAILED SERVICE DESCRIPTION]
- Who it's for: [TARGET CLIENT]
- What they struggle with: [PAIN POINTS]
- How I deliver it: [PROCESS]
- Investment range: [RANGE]
- What makes me different: [DIFFERENTIATOR]

Requirements:
- Structure: Hero section (headline + subhead), Pain points section, What's included, Process overview, Testimonial placeholder, FAQ (3 questions), CTA
- Write in the client's language, not industry jargon
- Focus on outcomes, not features
- Include a guarantee or risk reversal element
```

## Prompt 45: About Page Copy
```
Write an About page for my freelance business website.

Context:
- My name: [NAME]
- My niche: [NICHE]
- Years of experience: [YEARS]
- Why I do this work: [MOTIVATION]
- My approach: [APPROACH]
- Fun fact: [FACT]

Requirements:
- Write in first person
- Start with WHY, not credentials
- Include a relatable moment or turning point
- Connect my experience to how it helps clients
- Keep it under 300 words
- End with a CTA to get in touch
```

## Prompt 46: Free Lead Magnet Outline
```
Create an outline for a free lead magnet (PDF/download) to attract [TARGET CLIENT].

Context:
- My niche: [NICHE]
- The biggest pain point I solve: [PAIN POINT]
- What I want to sell after they download: [PAID PRODUCT]
- Lead magnet format: [FORMAT — checklist, template, guide, calculator]

Requirements:
- Must deliver immediate value (usable in under 30 minutes)
- Directly related to the paid product (natural upgrade path)
- Include 3-5 actionable items, not just theory
- Add a "want the full system?" CTA to the paid product
- Keep the outline detailed enough to execute in 2-3 hours
```

---

# Category 7: Business Operations

## Prompt 47: Standard Operating Procedure
```
Create a Standard Operating Procedure (SOP) for [PROCESS].

Context:
- Process: [PROCESS NAME]
- Steps I currently follow (rough): [ROUGH STEPS]
- Tools involved: [TOOLS]
- Who else might follow this: [TEAM/FUTURE VA]

Requirements:
- Write step-by-step with numbered instructions
- Include screenshots placeholders for key steps
- Add estimated time for each step
- Include a troubleshooting section for common issues
- Add a "when to escalate" section
- Keep it under 2 pages
```

## Prompt 48: Freelance Contract Clause Generator
```
Generate key contract clauses for a freelance [PROJECT TYPE] agreement.

Context:
- Service type: [SERVICE]
- Typical project: [TYPICAL PROJECT]
- Common issues I've had: [ISSUES — e.g., late payment, scope creep, IP disputes]
- Payment terms: [TERMS]

Requirements:
- Generate clauses for: Scope of Work, Payment Terms, Intellectual Property, Revisions, Termination, Confidentiality, Limitation of Liability
- Use plain English, not dense legal jargon
- Each clause should be 2-4 sentences
- Note: "This is not legal advice. Have a lawyer review before use."
```

## Prompt 49: Invoice Follow-Up Email (Overdue)
```
Write an invoice follow-up email for an overdue payment.

Context:
- Client name: [NAME]
- Invoice number: [NUMBER]
- Amount due: [AMOUNT]
- Days overdue: [DAYS]
- Previous communication: [PREVIOUS FOLLOW-UPS]
- Late fee policy: [POLICY]

Requirements:
- Be firm but professional
- Reference the invoice number and amount
- If first follow-up: gentle reminder
- If second follow-up: mention late fees
- If third follow-up: state next steps (pause work, collection)
- Always include how to pay
- Keep it under 150 words
```

## Prompt 50: Freelancing FAQ Page
```
Create an FAQ section for my freelance business website.

Context:
- My services: [SERVICES]
- My niche: [NICHE]
- Common questions clients ask: [QUESTIONS]
- Common objections: [OBJECTIONS]
- My process: [PROCESS]

Requirements:
- 8-10 questions and answers
- Mix of practical questions (pricing, timeline, process) and trust-building questions (experience, guarantees)
- Each answer: 2-4 sentences max
- Write answers in my voice: [VOICE]
- Include at least one question that addresses a common fear or hesitation
```

## Prompt 51: End-of-Year Business Review
```
Create a template for my freelance business end-of-year review.

Context:
- My services: [SERVICES]
- Revenue this year: [REVENUE]
- Number of clients: [CLIENTS]
- Biggest wins: [WINS]
- Biggest challenges: [CHALLENGES]
- Goals for next year: [GOALS]

Requirements:
- Sections: Revenue & Financials, Client Analysis, Marketing Review, Operations Review, Lessons Learned, Goals for Next Year
- Include prompts/questions for each section
- Add a "what to stop doing" section
- Include a "what to start doing" section
- Keep it actionable, not just reflective
```

## Prompt 52: Client Offboarding Process
```
Create a client offboarding checklist/process.

Context:
- My services: [SERVICES]
- Typical deliverables: [DELIVERABLES]
- Post-project support I offer: [SUPPORT]
- How I ask for referrals/testimonials: [APPROACH]

Requirements:
- Steps from project completion to archive
- Include: final deliverables handoff, accounts/access cleanup, testimonial request, referral ask, feedback collection, future project discussion, CRM/archive update
- Add a timeline (what to do on day 1, day 7, day 30 post-project)
- Include email templates for each touchpoint
```

---

# Bonus: 10 Advanced Prompt Patterns

## Pattern 1: The Refinement Loop
```
First, generate [OUTPUT]. Then critique it for [CRITERIA]. 
Rewrite addressing the critique. Then critique again. 
Repeat until the output scores 9/10 on: clarity, persuasiveness, and actionability.
```

## Pattern 2: The Perspective Shift
```
Write [OUTPUT] from three perspectives:
1. A senior consultant with 20 years of experience (authoritative, measured)
2. A startup founder (direct, urgent, no-nonsense)
3. A friendly mentor (warm, encouraging, uses stories)
Then combine the best elements of all three into a final version.
```

## Pattern 3: The Anti-Pattern
```
First, show me the WORST possible version of [OUTPUT]. 
Include every cliché, buzzword, and mistake. 
Now explain why each element is bad. 
Then write the best version, avoiding every mistake you identified.
```

## Pattern 4: The Decision Framework
```
I need to decide between [OPTION A] and [OPTION B].

For each option, analyze:
- Short-term impact (next 30 days)
- Long-term impact (next 12 months)
- Risk level (1-10)
- Effort required (1-10)
- Alignment with my goal of [GOAL]

Then give me a recommendation with your reasoning.
```

## Pattern 5: The Expert Interview
```
I want you to act as a [ROLE] with [SPECIFIC EXPERTISE].

Ask me 5 questions, one at a time, to understand my situation.
After each answer, ask a follow-up question that digs deeper.
After all 5 questions, provide your expert recommendation based on everything I've shared.
```

## Pattern 6: The Before/After
```
Show me a "before" version of [OUTPUT] that represents what a typical freelancer would write.
Then show me the "after" version that a top 1% freelancer would write.
Explain the key differences and why the "after" version works better.
```

## Pattern 7: The Constraint Challenge
```
Write [OUTPUT] with these constraints:
- Maximum [WORD COUNT] words
- No adjectives in the first paragraph
- Must include exactly one question
- Must use at least one specific number or statistic
- Cannot use these words: [BANNED WORDS]
Constraints breed creativity. Go.
```

## Pattern 8: The Audience Translator
```
Take this [CONTENT] and rewrite it for 3 different audiences:
1. A CEO who has 30 seconds and only cares about ROI
2. A technical manager who wants to see the methodology
3. A junior team member who needs step-by-step instructions
Same message, three different expressions.
```

## Pattern 9: The Iteration Expander
```
Write a one-sentence version of [MESSAGE].
Now a one-paragraph version.
Now a one-page version.
Now a full proposal version.
Each expansion should add depth without losing the core message.
```

## Pattern 10: The Objection Pre-Handler
```
I'm pitching [OFFER] to [AUDIENCE].

List the top 7 objections they would have.
For each objection:
- Why they think it (root cause)
- A one-sentence reframe
- A proof point or evidence I could use
Then write the pitch incorporating these objection handlers naturally.
```

---

# Prompt Refinement Cheat Sheet

When a prompt gives weak results, fix it by adding:

1. **Be specific about output format**: "Write as bullet points" / "Use this structure: A, B, C" / "Maximum 200 words"
2. **Add constraints**: "Don't use these words: ___" / "Must include a number" / "Write at a 6th grade reading level"
3. **Specify the audience**: "Write for a CEO, not a marketer" / "The reader has 30 seconds"
4. **Give examples**: "Here's an example of what I want: ___" / "Make it sound like this: ___"
5. **Define success criteria**: "The output is successful if a busy executive would reply to it"
6. **Ask for reasoning**: "Explain why you chose each word" / "Rate your confidence for each section"
7. **Iterate**: "Make it 50% shorter" / "Make it more conversational" / "Add more specific details"
8. **Role-play**: "You are a senior copywriter who has written for Nike and Apple"
9. **Add context**: "The reader just had a bad experience with ___" / "This is for someone who is skeptical of ___"
10. **Request alternatives**: "Give me 3 versions: conservative, moderate, and bold"

---

*Built by Cleo. For freelancers who take their business seriously.*
