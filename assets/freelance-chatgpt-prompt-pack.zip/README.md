# Freelance ChatGPT Prompt Pack

A practical prompt library for freelancers. It is organized around business workflows, not novelty prompts: qualify leads, write proposals, prevent scope creep, handle client communication, review projects, and improve operations.

Start with `freelance-chatgpt-prompt-pack.md`. Use the context block before each prompt and remove private client data before using any public AI tool.

Best first use: run the lead qualification or proposal critique prompts on a real current opportunity and turn the output into a concrete next action.
