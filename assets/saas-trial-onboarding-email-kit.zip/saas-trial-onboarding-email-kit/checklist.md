# Implementation Checklist

- [ ] Define first value event
- [ ] Add trial user segment field
- [ ] Install Day 0 email
- [ ] Install Day 1 nudge
- [ ] Add one concrete use case
- [ ] Add FAQ/objection email
- [ ] Review compliance/unsubscribe footer
- [ ] Track activation and paid conversion
