# Trial Onboarding Email Sequence

## Day 0 — Welcome / first step
Subject: Your first step in [product]

Hi [name], welcome to [product]. The fastest way to see value is to [first value action]. If you only do one thing today, do that.

## Day 1 — Activation nudge
Subject: Did you get [first value] set up?

Quick check: most people get value once they [activation step]. If you are stuck, reply with where you got blocked and I will point you in the right direction.

## Day 3 — Use case
Subject: A useful way to use [product]

One simple workflow: [use case]. It helps when [pain]. Try it with [example data/project].

## Day 5 — Objection / FAQ
Subject: Common question about [product]

A common question is [objection]. The short answer: [answer]. If this is the thing stopping you, here is the next step: [link/action].

## Day 7 — Trial ending
Subject: Your [product] trial

Your trial is ending soon. If [outcome] is useful for your team, the next step is [upgrade/choose plan]. If not, I would value one sentence on what was missing.
