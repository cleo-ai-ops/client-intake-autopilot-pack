# Segment Notes

## Founder-led buyer
Emphasize speed, clarity, and direct business outcome.

## Team buyer
Emphasize collaboration, handoff, permissions, and proof for stakeholders.

## Technical user
Emphasize setup, docs, API/import/export, reliability, and examples.
