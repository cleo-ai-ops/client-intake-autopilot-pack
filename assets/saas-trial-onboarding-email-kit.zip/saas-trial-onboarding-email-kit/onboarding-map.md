# Trial Onboarding Map

1. Signup intent: what did the user expect to solve?
2. First value event: the smallest action that proves the product works.
3. Main blocker: setup, confusion, trust, missing data, team buy-in, price.
4. Email goal by day:
   - Day 0: confirm promise and first step
   - Day 1: remove setup friction
   - Day 3: show one relevant use case
   - Day 5: answer common objections
   - Day 7: summarize value and next step
