# SaaS Trial Onboarding Email Kit

A practical lifecycle email kit for solo SaaS founders who get trial signups but struggle to move users to first value before the trial expires.

## Buyer hypothesis
Small SaaS teams often have no onboarding marketer. Better first-week emails and activation prompts can help users understand value without adding heavy automation software.

## Included
- Trial onboarding map
- Day 0 welcome email
- Day 1 activation nudge
- Day 3 use-case email
- Day 5 objection/FAQ email
- Day 7 trial ending email
- Segment notes for founder-led, team, and technical users
- A/B test log CSV
- Free email generator: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/trial-onboarding-email-generator/

## Safe-use note
Use these as clear onboarding prompts, not spam. Only email people who opted into your trial and include your normal unsubscribe/compliance footer.
