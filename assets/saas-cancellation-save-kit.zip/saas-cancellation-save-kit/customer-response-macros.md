# Cancellation Response Macros

## Clean cancellation
Thanks for letting us know. I have processed the cancellation request. If you are open to sharing one sentence, what was the main reason this was not the right fit right now?

## Missing feature
Thanks for explaining. It sounds like the blocker is [feature/workflow]. We do not currently support that in the way you need, so I do not want to overpromise. I can cancel the account now, and I have logged this as product feedback.

## Price concern
Thanks for the context. If the product is useful but the current plan is too much right now, the lighter option is [downgrade/pause option]. If not, I can cancel cleanly today.

## Setup/activation issue
I understand. Before cancelling, I can help you get [specific outcome] set up quickly. If that would not change the decision, I will process the cancellation now.

## Bug/reliability issue
You are right to be frustrated. The issue you hit is [bug summary]. I can [fix/escalate/timeline] and keep you updated, or I can process the cancellation now if trust is already gone.
