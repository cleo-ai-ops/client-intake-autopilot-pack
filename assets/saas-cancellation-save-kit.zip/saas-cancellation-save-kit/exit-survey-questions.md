# Exit Survey Questions

Ask only one or two.

- What was the main reason you cancelled?
- What were you hoping the product would do better?
- What tool or workaround are you using instead?
- Was there a point where you expected value but did not get it?
- What would have made this worth keeping?
