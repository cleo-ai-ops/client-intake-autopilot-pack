# Save Offer Decision Tree

1. Is the customer angry or blocked by a bug?
   - Acknowledge, fix/escalate if possible, do not discount first.
2. Is the customer confused or under-activated?
   - Offer a quick setup/help path.
3. Is the issue price?
   - Offer downgrade/pause only if it preserves trust and fits your pricing.
4. Is the product a bad fit or project ended?
   - Cancel cleanly and ask one learning question.
5. Is there no clear reason?
   - Ask a short exit question, then process cancellation.
