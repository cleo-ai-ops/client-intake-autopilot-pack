# Cancellation Reason Intake

Capture before replying:
- Account / plan:
- Cancellation reason:
- Trigger: price, missing feature, bug, low usage, project ended, switched tool, unknown
- Last active date:
- Support issues open?
- Is there a real save path?
- If no save path, cancel cleanly and ask for learning.
