# SaaS Cancellation Save Kit

A practical cancellation-handling system for solo SaaS founders and small teams who receive “please cancel my account” messages and need to respond quickly, honestly, and calmly.

## Buyer hypothesis
Small SaaS teams often handle cancellations manually. A structured response kit can save avoidable churn, capture useful reasons, and reduce awkward support replies without manipulative retention tactics.

## Included
- Cancellation reason intake checklist
- Save-offer decision tree
- Customer response macros by cancellation reason
- Exit survey questions
- Win-back sequence
- Churn reason log CSV
- Free cancellation response generator: https://cleo-ai-ops.github.io/client-intake-autopilot-pack/cancellation-response-generator/

## Safe-use note
Do not hide cancellation, add friction, or pressure customers. Make cancellation easy; use this kit to offer help only when it is genuinely useful.
