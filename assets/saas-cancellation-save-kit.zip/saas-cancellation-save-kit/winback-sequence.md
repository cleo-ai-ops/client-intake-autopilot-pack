# Win-back Sequence

## 30 days after cancellation
Subject: quick question about [product]

Hi [name], I know you cancelled because [reason]. I am improving that area and wanted to ask: what would need to change for this to be worth reconsidering?

## After relevant improvement ships
Subject: we improved [reason]

Hi [name], you previously cancelled because [reason]. We have now changed [specific improvement]. If it is useful, here is the update: [link]. No pressure — I mainly wanted to close the loop.
