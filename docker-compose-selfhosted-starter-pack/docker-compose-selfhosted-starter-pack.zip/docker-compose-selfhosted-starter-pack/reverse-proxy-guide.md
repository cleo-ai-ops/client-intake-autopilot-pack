# Reverse Proxy Setup Guide

This guide covers setting up Traefik as a reverse proxy for your self-hosted services.

## Why a Reverse Proxy?

1. **Single entry point** — all services behind one IP, differentiated by subdomain
2. **Automatic SSL** — Let's Encrypt certificates renewed automatically
3. **Security** — centralize HTTPS termination and access control
4. **Convenience** — access services at `service.yourdomain.com` instead of `IP:port`

## Option A: Traefik (Recommended for Docker)

### Setup Steps

1. Create the Docker network:
```bash
docker network create proxy
```

2. Create `traefik/traefik.yml`:
```yaml
api:
  dashboard: true
  insecure: true  # Only for initial setup — restrict with auth

entryPoints:
  web:
    address: ":80"
    http:
      redirections:
        entryPoint:
          to: websecure
  websecure:
    address: ":443"

certificatesResolvers:
  letsencrypt:
    acme:
      email: admin@example.com
      storage: /data/acme.json
      tlsChallenge: {}

providers:
  docker:
    exposedByDefault: false
    network: proxy
  file:
    filename: /etc/traefik/dynamic.yml
```

3. Create `traefik/dynamic.yml`:
```yaml
http:
  middlewares:
    secure-headers:
      headers:
        sslRedirect: true
        stsSeconds: 31536000
        stsIncludeSubdomains: true
        stsPreload: true
        forceSTSHeader: true
        customFrameOptionsValue: "SAMEORIGIN"
        contentTypeNosniff: true
        browserXssFilter: true
        referrerPolicy: "strict-origin-when-cross-origin"
```

4. Start Traefik:
```bash
docker compose -f traefik.yml up -d
```

### Adding Services

Add these labels to any service's Docker Compose:
```yaml
labels:
  - "traefik.enable=true"
  - "traefik.http.routers.MYSERVICE.rule=Host(`MYSERVICE.${DOMAIN}`)"
  - "traefik.http.routers.MYSERVICE.entrypoints=websecure"
  - "traefik.http.routers.MYSERVICE.tls=true"
  - "traefik.http.services.MYSERVICE.loadbalancer.server.port=INTERNAL_PORT"
```

## Option B: Nginx Proxy Manager (Easier UI)

1. Start NPM with the `nginx-proxy-manager.yml` config
2. Visit `http://your-server:81`
3. Default login: `admin@example.com` / `changeme` — change immediately
4. Add Proxy Host for each service, pointing to `container-name:port`
5. Enable SSL with Let's Encrypt on each host

## DNS Setup

Point these subdomains to your server's public IP:
```
traefik    CNAME   your-server
portainer  CNAME   your-server
status     CNAME   your-server
vault      CNAME   your-server
cloud      CNAME   your-server
grafana    CNAME   your-server
```

Most registrars support wildcard DNS:
```
*.yourdomain.com  A  your.server.ip
```
