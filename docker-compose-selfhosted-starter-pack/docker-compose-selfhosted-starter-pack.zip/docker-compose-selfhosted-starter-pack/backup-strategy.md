# Backup Strategy for Self-Hosted Services

## The 3-2-1 Rule
- **3** copies of your data
- **2** different storage media
- **1** off-site copy

## Per-Service Backup Guide

### Critical (Backup Daily)
| Service | What to Backup | How |
|---------|---------------|-----|
| Vaultwarden | `/data` volume | `sqlite3 /data/db.sqlite3 ".backup /data/backup.sqlite3"` then copy |
| Nextcloud | DB + `/var/www/html/data` | `pg_dump` for DB + rsync for files |
| n8n | `/home/node/.n8n` | Stop container, tar the volume, restart |
| Pi-hole | `/etc/pihole` | `pihole -a -t` (teleporter backup) |

### Important (Backup Weekly)
| Service | What to Backup | How |
|---------|---------------|-----|
| Grafana | Grafana DB via API | `curl -s http://localhost:3000/api/admin/export` |
| Minio | Buckets | `mc mirror` to another location |
| Immich | DB + upload volume | `pg_dump` + rsync |

### Nice to Have (Backup Before Changes)
| Service | What to Backup | How |
|---------|---------------|-----|
| Portainer | `/data` volume | Stop, tar, restart |
| Traefik | Config + certs | Tar the data volume |
| Homepage | Config volume | Tar the volume |

## Automated Backup Script Template

```bash
#!/bin/bash
# backup.sh — Run via cron daily at 2 AM
BACKUP_DIR="/mnt/backup/$(date +%Y-%m-%d)"
mkdir -p "$BACKUP_DIR"

# Backup all Docker volumes
for volume in $(docker volume ls -q); do
  docker run --rm -v "$volume:/source" -v "$BACKUP_DIR:/backup" alpine \
    tar czf "/backup/${volume}.tar.gz" -C /source .
done

# Rotate backups older than 30 days
find /mnt/backup -maxdepth 1 -type d -mtime +30 -exec rm -rf {} +

echo "Backup completed: $(date)"
```

Add to crontab: `0 2 * * * /path/to/backup.sh >> /var/log/backup.log 2>&1`
