# Docker Compose Starter Pack for Self-Hosting

## What You Get

15 production-minded Docker Compose starter configurations for self-hosting the most popular services on your own server. Each config includes security hardening, resource limits, and Traefik/Nginx reverse proxy integration.

## Included Services

| # | Service | Purpose | Config |
|---|---------|---------|--------|
| 1 | **Portainer** | Container management UI | portainer.yml |
| 2 | **Uptime Kuma** | Uptime monitoring & alerts | uptime-kuma.yml |
| 3 | **Vaultwarden** | Password manager (Bitwarden-compatible) | vaultwarden.yml |
| 4 | **Pi-hole** | Network ad blocker & DNS | pi-hole.yml |
| 5 | **Nextcloud** | Cloud storage & collaboration | nextcloud.yml |
| 6 | **Jellyfin** | Media streaming server | jellyfin.yml |
| 7 | **Grafana + Prometheus** | System monitoring dashboards | monitoring.yml |
| 8 | **Traefik** | Reverse proxy with auto-SSL | traefik.yml |
| 9 | **Nginx Proxy Manager** | Alternative reverse proxy UI | nginx-proxy-manager.yml |
| 10 | **Wireguard Easy** | VPN server for remote access | wireguard.yml |
| 11 | **Immich** | Self-hosted Google Photos alternative | immich.yml |
| 12 | **Homepage** | Application dashboard | homepage.yml |
| 13 | **Tailscale Exit Node** | Mesh VPN exit node | tailscale.yml |
| 14 | **Minio** | S3-compatible object storage | minio.yml |
| 15 | **n8n** | Workflow automation | n8n.yml |

## Also Includes

- **`env-template`** — Template `.env` file with all variables documented
- **`security-checklist.md`** — 25-point hardening checklist for any self-hosted server
- **`backup-strategy.md`** — Recommended backup approaches for each service
- **`reverse-proxy-guide.md`** — How to set up Traefik or Nginx as a reverse proxy
- **`service-post-install-checks.md`** — Per-service validation after first boot
- **`firewall-tailscale-recipes.md`** — Safer exposure patterns for public vs private services
- **`upgrade-backup-restore-commands.md`** — Upgrade and rollback commands
- **`worked-example-domain-to-backup.md`** — Full domain → proxy → service → backup example

## Quick Start

1. Copy `env-template` to `.env` and fill in your values
2. Pick the services you want to run
3. `docker compose -f <service>.yml up -d`
4. Follow the security checklist

## Requirements

- A server (VPS, Raspberry Pi, old laptop, or dedicated machine)
- Docker and Docker Compose installed
- A domain name (optional but recommended for SSL)
- Basic command line familiarity

## Who This Is For

- Tech enthusiasts setting up their first homelab
- Privacy-focused people moving away from cloud services
- Small teams wanting self-hosted tools without vendor lock-in
- Anyone who wants production-minded starter configs without hours of research

## License

Personal use license. One purchase per user. Do not redistribute.
