# Upgrade, backup, and restore commands

## Upgrade a service
```bash
docker compose -f SERVICE.yml pull
docker compose -f SERVICE.yml up -d
docker compose -f SERVICE.yml logs --tail=100
```

## Snapshot before upgrade
```bash
mkdir -p backups/$(date +%F)
docker compose -f SERVICE.yml config > backups/$(date +%F)/SERVICE.compose.rendered.yml
# Copy named volumes with your preferred volume backup method before risky upgrades.
```

## Restore rule
A backup is not real until you have restored it once. For databases, restore to a temporary container or staging host before trusting the schedule.

## Rollback
Pin image versions before production-ish use. If an upgrade fails, set the previous tag, run `docker compose pull`, then `up -d`.
