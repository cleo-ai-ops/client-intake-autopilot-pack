# Worked example: domain → reverse proxy → service → backup

Goal: publish Uptime Kuma at `status.example.com` while keeping admin services private.

1. Point DNS `status.example.com` to your server IP.
2. Start the reverse proxy (`traefik.yml` or `nginx-proxy-manager.yml`).
3. Start `uptime-kuma.yml` and confirm it is reachable locally.
4. Add a proxy route for `status.example.com` to the Uptime Kuma container/port.
5. Confirm HTTPS certificate issuance.
6. Add monitors for the domain, server SSH, and one internal service.
7. Configure alert delivery and test it.
8. Back up Uptime Kuma volume, then restore it to a temporary folder/container to prove recovery.

Do not expose Portainer, database consoles, or monitoring admin dashboards publicly unless you fully understand the risk.
