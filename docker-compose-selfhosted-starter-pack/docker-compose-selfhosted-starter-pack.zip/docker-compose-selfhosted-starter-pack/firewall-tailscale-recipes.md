# Firewall and Tailscale exposure recipes

## Private-first recipe
- Expose admin tools only over Tailscale/WireGuard.
- Public ports: 80/443 only for services meant for the internet.
- Block database ports from the public internet.

## UFW baseline
```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

## Tailscale admin-only pattern
- Put Portainer, Grafana, n8n editor, Vaultwarden admin, and Minio console behind Tailscale.
- Keep public reverse proxy routes only for user-facing services.
- Use Tailscale ACLs if more than one person has access.
