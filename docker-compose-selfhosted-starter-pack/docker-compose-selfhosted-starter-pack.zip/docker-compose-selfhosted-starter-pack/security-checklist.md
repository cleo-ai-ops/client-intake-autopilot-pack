# Self-Hosted Server Security Checklist

Use this checklist before exposing any self-hosted service to the internet.

## Server Hardening (Do This First)
- [ ] **Change default SSH port** from 22 to a non-standard port
- [ ] **Disable root SSH login** — use a dedicated user with sudo
- [ ] **Disable password authentication** — SSH keys only
- [ ] **Install and configure fail2ban** — auto-ban failed login attempts
- [ ] **Enable unattended upgrades** — automatic security patches
- [ ] **Set up a firewall** (ufw or iptables) — only open needed ports
- [ ] **Disable unnecessary services** — reduce attack surface
- [ ] **Keep Docker images updated** — regularly pull latest images

## Network Security
- [ ] **Use a reverse proxy** (Traefik or Nginx) for all web services
- [ ] **Enable HTTPS everywhere** — Let's Encrypt via Traefik/NPM
- [ ] **Use non-standard ports** for admin interfaces
- [ ] **Set up DNS records** — use CNAME for subdomains
- [ ] **Consider Cloudflare** for DDoS protection and CDN (free tier)
- [ ] **Restrict Docker networks** — use internal networks for service-to-service

## Application Security
- [ ] **Change all default passwords** — every service, every time
- [ ] **Disable signups after initial setup** — especially Vaultwarden, Nextcloud
- [ ] **Use strong, unique passwords** — 16+ characters per service
- [ ] **Enable 2FA where available** — Portainer, Nextcloud, Grafana, etc.
- [ ] **Set `security_opt: no-new-privileges:true`** on all containers
- [ ] **Drop all capabilities** (`cap_drop: ALL`) and add only what's needed
- [ ] **Read-only mounts** (`:ro`) for config files that don't need writes
- [ ] **Set resource limits** to prevent any single service from consuming all resources

## Monitoring & Backup
- [ ] **Set up uptime monitoring** (Uptime Kuma) for all public services
- [ ] **Configure alerts** — Telegram, Discord, or email for downtime
- [ ] **Set up system monitoring** (Grafana + Prometheus) for resource tracking
- [ ] **Automate backups** — at least daily for databases and config
- [ ] **Test backup restoration** — untested backups aren't backups
- [ ] **Store backups off-site** — at least one copy on different hardware/location

## Privacy
- [ ] **Review what each service exposes** — check if it's accessible without auth
- [ ] **Use environment variables** for secrets — never hardcode in compose files
- [ ] **Don't expose Docker socket** unless absolutely necessary (Portainer needs it)
- [ ] **Restrict Traefik dashboard** — use basic auth, don't leave it open
