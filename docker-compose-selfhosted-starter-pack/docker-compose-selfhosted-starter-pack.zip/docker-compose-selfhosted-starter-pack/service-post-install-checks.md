# Per-service post-install checks

Run these after `docker compose -f <service>.yml up -d`.

| Service | Check |
|---|---|
| Portainer | Login works, admin password changed, exposed only over VPN/reverse proxy. |
| Uptime Kuma | Add one internal and one external monitor; test alert destination. |
| Vaultwarden | Admin token set, signups disabled unless needed, backup tested. |
| Pi-hole | DNS resolves, admin password changed, upstream DNS intentional. |
| Nextcloud | Cron/background jobs configured, trusted domains set, upload limit tested. |
| Jellyfin | Media paths mounted read-only where possible. |
| Grafana/Prometheus | Default passwords changed; scrape targets healthy. |
| Traefik/NPM | TLS cert issued; dashboard not public. |
| Wireguard/Tailscale | New device can connect; LAN access matches intent. |
| Immich | Upload a test photo; confirm database and library backups. |
| Minio | Root credentials changed; bucket policy not public unless intended. |
| n8n | Encryption key set; webhook URL correct; credentials not exported. |
