# Freelancer Business Systems Bundle

This bundle combines four operational products for freelancers and consultants:

1. **Client Intake Autopilot Pack** — form, scorecard, scripts, discovery agenda, scope boundaries, automation recipes.
2. **Freelance Lead Scoring Spreadsheet Kit** — spreadsheet template, formulas, scoring rules, examples, reply scripts, bonus n8n workflow.
3. **Freelance Rate Raise Email Kit** — decision map, rate increase scripts, pushback replies, tracking CSV.
4. **Micro-Product Launch Checklist** — QA and launch checklist for small paid products.

## Suggested implementation order
1. Install lead scoring first so bad-fit calls stop leaking time.
2. Add the intake form and reply scripts.
3. Review current clients with the rate raise kit.
4. Use the micro-product checklist for any future templates or guides you publish.

## First 60 minutes
- Import the lead scoring CSV.
- Copy the intake questions into your form.
- Save three email snippets: priority booking, clarify first, decline.
- Identify one legacy client for a rate review.
